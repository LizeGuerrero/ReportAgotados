-- Fase 1 · ITEMS — parte 2 de 7: items.activo y items.codigo_erp (código del ERP, único POR ORGANIZACIÓN)
-- Ejecutar en orden (01 → 07), UNA por vez. Si falla por bloqueo, espera unos segundos y repite SOLO esta parte
-- (es idempotente).
--
-- Idea: id_item sigue siendo la clave INTERNA (no cambia ninguna llave foránea). Lo que el usuario ve y lo que
-- trae el ERP pasa a ser codigo_erp. Así dos organizaciones pueden usar el mismo código sin chocar.

set lock_timeout = '5s';

alter table public.items add column if not exists activo boolean not null default true;
alter table public.items add column if not exists codigo_erp text;

comment on column public.items.iva is 'IVA de VENTA (viene del ERP), fracción 0..1. No es el IVA de compra: ese depende del proveedor.';
comment on column public.items.activo is 'false = inhabilitado (no se borra; conserva su historia).';
comment on column public.items.id_item is 'Clave INTERNA. Positivas desde items_id_seq; negativas = provisionales. Lo visible es codigo_erp.';
comment on column public.items.codigo_erp is 'Código del ítem en el ERP. Único por organización (sin distinguir mayúsculas). NULL solo en provisionales.';

-- Las claves internas nuevas arrancan en 10^12 para no cruzarse nunca con los id_item que ya existen (máximo actual ~902262).
do $$ begin
  if exists (select 1 from public.items where id_item >= 1000000000000) then
    raise exception 'Hay id_item >= 10^12: ajusta el inicio de items_id_seq antes de continuar';
  end if;
end $$;

create sequence if not exists public.items_id_seq
  start with 1000000000000 minvalue 1000000000000 increment by 1 no maxvalue cache 1;
revoke all on sequence public.items_id_seq from public, anon, authenticated;
grant usage, select on sequence public.items_id_seq to service_role;

-- Relleno: los ítems actuales conservan como código visible el mismo número que tenían.
update public.items set codigo_erp = id_item::text where not provisional and codigo_erp is null;

do $$ begin
  alter table public.items add constraint items_codigo_erp_chk check (
    (provisional and codigo_erp is null)
    or (not provisional and codigo_erp is not null and btrim(codigo_erp) <> ''));
exception when duplicate_object then null; end $$;

create unique index if not exists items_org_codigo_erp_uk
  on public.items (organizacion_id, lower(btrim(codigo_erp))) where codigo_erp is not null;
