-- =============================================================================
-- Extras del panel de administración:
--   1. Suspender / reactivar / retirar miembros
--   2. Sedes: listar, crear, editar y eliminar
--   3. Restablecer un rol base (Gerencia, Compras, Bodega, Comercial) a sus permisos originales
--   4. Historial de cambios (auditoría) de la organización
--
-- Aditiva: solo agrega una tabla, un índice, funciones y triggers. No cambia tablas, políticas
-- ni funciones existentes (los triggers son AFTER: no alteran lo que ya hacen las funciones).
-- Requiere haber aplicado antes: migracion_orgs_invitaciones.sql, parche_propietario.sql y
-- migracion_roles_dashboard.sql. Se puede correr más de una vez. Corre en una sola transacción.
-- =============================================================================
begin;

-- -----------------------------------------------------------------------------
-- 1. Estado de miembros
--    Importante: tiene_permiso() solo mira membresias.activo, así que suspender/retirar
--    también pone activo = false (si no, la persona conservaría sus permisos en la base).
-- -----------------------------------------------------------------------------
create or replace function public.cambiar_estado_miembro(p_membresia uuid, p_accion text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_m    public.membresias%rowtype;
  v_rol  text;
  v_prop uuid;
begin
  select * into v_m from public.membresias where id = p_membresia for update;
  if not found or not public.es_admin_org(v_m.organizacion_id) then
    raise exception 'Solo un administrador puede cambiar el estado de un miembro';
  end if;
  if p_accion is null or p_accion not in ('suspender', 'reactivar', 'retirar') then
    raise exception 'Acción no válida';
  end if;
  if v_m.usuario_id = auth.uid() then
    raise exception 'No puedes cambiar tu propio estado; pide a otro administrador';
  end if;

  select o.propietario_id into v_prop from public.organizaciones o where o.id = v_m.organizacion_id;
  if v_prop is not null and v_m.usuario_id = v_prop then
    raise exception 'El propietario de la organización no se puede suspender ni retirar';
  end if;

  select r.nombre into v_rol from public.roles r where r.id = v_m.rol_id;
  if v_rol = 'admin' and v_prop is not null and v_prop is distinct from auth.uid() then
    raise exception 'Solo el propietario puede suspender o retirar a otro administrador';
  end if;

  if v_m.estado_membresia = 'pendiente' then
    raise exception 'Las solicitudes pendientes se aceptan o se rechazan, no se suspenden';
  end if;

  if p_accion = 'reactivar' then
    if v_m.estado_membresia <> 'suspendida' then
      raise exception 'Solo se puede reactivar a un miembro suspendido';
    end if;
    update public.membresias set estado_membresia = 'activa', activo = true where id = v_m.id;
    return;
  end if;

  -- suspender / retirar
  if p_accion = 'suspender' and v_m.estado_membresia <> 'activa' then
    raise exception 'Solo se puede suspender a un miembro activo';
  end if;
  if p_accion = 'retirar' and v_m.estado_membresia not in ('activa', 'suspendida') then
    raise exception 'Este miembro ya no pertenece a la organización';
  end if;

  if v_rol = 'admin' and v_m.estado_membresia = 'activa' and not exists (
    select 1
    from public.membresias mm
    join public.roles rr on rr.id = mm.rol_id
    where mm.organizacion_id = v_m.organizacion_id
      and mm.id <> v_m.id
      and mm.activo and mm.estado_membresia = 'activa'
      and rr.nombre = 'admin'
  ) then
    raise exception 'La organización debe conservar al menos un administrador';
  end if;

  update public.membresias
     set estado_membresia = case p_accion when 'suspender' then 'suspendida' else 'retirada' end::public.estado_membresia_enum,
         activo = false
   where id = v_m.id;
end $$;

-- -----------------------------------------------------------------------------
-- 2. Sedes
-- -----------------------------------------------------------------------------
create or replace function public.listar_sedes_org(p_org uuid)
returns table (sede_id uuid, nombre text, ciudad text, miembros bigint, creada_en timestamptz)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede ver las sedes';
  end if;

  return query
  select s.id, s.nombre, s.ciudad,
         (select count(*) from public.membresias m
           where m.sede_id = s.id and m.estado_membresia in ('activa', 'suspendida')),
         s.created_at
  from public.sedes s
  where s.organizacion_id = p_org
  order by s.nombre;
end $$;

create or replace function public._validar_sede(p_org uuid, p_nombre text, p_ciudad text, p_excluir uuid)
returns void
language plpgsql
stable
set search_path = ''
as $$
begin
  if char_length(p_nombre) < 2 or char_length(p_nombre) > 60 then
    raise exception 'El nombre de la sede debe tener entre 2 y 60 caracteres';
  end if;
  if p_ciudad is not null and char_length(p_ciudad) > 60 then
    raise exception 'La ciudad no puede superar 60 caracteres';
  end if;
  if exists (
    select 1 from public.sedes s
     where s.organizacion_id = p_org
       and lower(s.nombre) = lower(p_nombre)
       and (p_excluir is null or s.id <> p_excluir)
  ) then
    raise exception 'Ya existe una sede con ese nombre en la organización';
  end if;
end $$;

create or replace function public.crear_sede(p_org uuid, p_nombre text, p_ciudad text default null)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_nombre text := btrim(coalesce(p_nombre, ''));
  v_ciudad text := nullif(btrim(coalesce(p_ciudad, '')), '');
  v_id     uuid;
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede crear sedes';
  end if;
  perform public._validar_sede(p_org, v_nombre, v_ciudad, null);

  insert into public.sedes (organizacion_id, nombre, ciudad)
  values (p_org, v_nombre, v_ciudad)
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.editar_sede(p_sede uuid, p_nombre text, p_ciudad text default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_s      public.sedes%rowtype;
  v_nombre text := btrim(coalesce(p_nombre, ''));
  v_ciudad text := nullif(btrim(coalesce(p_ciudad, '')), '');
begin
  select * into v_s from public.sedes where id = p_sede;
  if not found or not public.es_admin_org(v_s.organizacion_id) then
    raise exception 'Solo un administrador puede editar sedes';
  end if;
  perform public._validar_sede(v_s.organizacion_id, v_nombre, v_ciudad, p_sede);

  update public.sedes set nombre = v_nombre, ciudad = v_ciudad where id = p_sede;
end $$;

-- No se elimina una sede que alguien está usando. Si tiene registros de negocio asociados
-- (agotados, bodegas, órdenes...), la propia base de datos lo impide y se informa.
create or replace function public.eliminar_sede(p_sede uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_s public.sedes%rowtype;
begin
  select * into v_s from public.sedes where id = p_sede for update;
  if not found or not public.es_admin_org(v_s.organizacion_id) then
    raise exception 'Solo un administrador puede eliminar sedes';
  end if;
  if (select count(*) from public.sedes where organizacion_id = v_s.organizacion_id) <= 1 then
    raise exception 'La organización debe conservar al menos una sede';
  end if;
  if exists (
    select 1 from public.membresias
     where sede_id = p_sede and estado_membresia in ('activa', 'suspendida')
  ) then
    raise exception 'Hay miembros con esta sede asignada. Cámbiales la sede antes de eliminarla';
  end if;
  if exists (
    select 1 from public.invitaciones
     where sede_id = p_sede and estado = 'pendiente' and expira_en > now()
  ) then
    raise exception 'Hay invitaciones pendientes con esta sede. Cancélalas antes de eliminarla';
  end if;

  begin
    -- Referencias que ya no están en uso (solicitudes pendientes o retiradas, invitaciones cerradas)
    update public.membresias set sede_id = null where sede_id = p_sede;
    update public.invitaciones set sede_id = null where sede_id = p_sede;
    delete from public.sedes where id = p_sede;
  exception when foreign_key_violation then
    raise exception 'La sede tiene registros asociados (agotados, bodegas u órdenes) y no se puede eliminar';
  end;
end $$;

-- -----------------------------------------------------------------------------
-- 3. Restablecer un rol base a sus permisos originales
--    (misma matriz con la que crear_organizacion siembra cada organización nueva)
-- -----------------------------------------------------------------------------
create or replace function public._permisos_base(p_nombre text)
returns table (modulo text, ver boolean, crear boolean, editar boolean, eliminar boolean)
language sql
immutable
set search_path = ''
as $$
  select x.modulo, x.ver, x.crear, x.editar, x.eliminar
  from (values
    ('Bodega',    'Agotados',         true, false, true,  false),
    ('Bodega',    'Bodega',           true, true,  true,  false),
    ('Comercial', 'Agotados',         true, true,  true,  false),
    ('Comercial', 'reporte_agotados', true, true,  true,  false),
    ('Compras',   'Agotados',         true, false, false, false),
    ('Compras',   'Compras',          true, true,  true,  false),
    ('Compras',   'Items',            true, false, false, false),
    ('Compras',   'pedidos',          true, true,  true,  false),
    ('Compras',   'Proveedores',      true, true,  true,  false),
    ('Gerencia',  'Agotados',         true, false, true,  false),
    ('Gerencia',  'Bodega',           true, false, false, false),
    ('Gerencia',  'Compras',          true, false, false, false),
    ('Gerencia',  'Items',            true, false, false, false),
    ('Gerencia',  'Proveedores',      true, false, false, false)
  ) as x(rol, modulo, ver, crear, editar, eliminar)
  where x.rol = p_nombre
$$;

create or replace function public.restablecer_rol_base(p_rol uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_r public.roles%rowtype;
begin
  select * into v_r from public.roles where id = p_rol for update;
  if not found or v_r.organizacion_id is null or not public.es_admin_org(v_r.organizacion_id) then
    raise exception 'Solo un administrador puede restablecer roles';
  end if;
  if v_r.nombre not in ('Gerencia', 'Compras', 'Bodega', 'Comercial') then
    raise exception 'Solo se pueden restablecer los roles base: Gerencia, Compras, Bodega y Comercial';
  end if;

  delete from public.permisos_rol where rol_id = p_rol;
  insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
  select p_rol, mo.id, b.ver, b.crear, b.editar, b.eliminar
  from public._permisos_base(v_r.nombre) b
  join public.modulos mo on mo.nombre = b.modulo;
end $$;

-- -----------------------------------------------------------------------------
-- 4. Historial de cambios
-- -----------------------------------------------------------------------------
create table if not exists public.auditoria_org (
  id               bigint generated always as identity primary key,
  organizacion_id  uuid not null references public.organizaciones(id) on delete cascade,
  usuario_id       uuid,                       -- quien hizo el cambio (null = proceso del sistema)
  accion           text not null,              -- código corto, p. ej. rol_creado
  descripcion      text not null,              -- frase en tercera persona: 'creó el rol "X"'
  creada_en        timestamptz not null default now(),
  txid             bigint not null default txid_current(),
  clave            text                        -- agrupa filas de una misma transacción
);

create index if not exists auditoria_org_org_fecha_idx
  on public.auditoria_org (organizacion_id, creada_en desc);

alter table public.auditoria_org enable row level security;
revoke all on public.auditoria_org from anon, authenticated;
-- Sin políticas: nadie la lee ni la escribe directamente. Solo los triggers (que la escriben)
-- y listar_auditoria (que solo responde a admins de la organización).

create or replace function public._nombre_usuario(p_uid uuid)
returns text
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(
    nullif(btrim(coalesce(p.nombres, '') || ' ' || coalesce(p.apellidos, '')), ''),
    u.email::text,
    'Un usuario'
  )
  from (select 1) base
  left join public.profiles p on p.id = p_uid
  left join auth.users u on u.id = p_uid
$$;

create or replace function public._auditar(p_org uuid, p_accion text, p_desc text, p_clave text default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.auditoria_org (organizacion_id, usuario_id, accion, descripcion, clave)
  values (p_org, auth.uid(), p_accion, p_desc, p_clave);
exception when others then
  -- El historial es de apoyo: un fallo aquí no debe impedir el cambio que se está haciendo.
  raise warning 'No se pudo registrar el historial: %', sqlerrm;
end $$;

-- ¿La organización se está creando en esta misma transacción? (evita registrar ruido de la siembra)
create or replace function public._org_recien_creada(p_org uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.auditoria_org
     where txid = txid_current() and organizacion_id = p_org and accion = 'org_creada'
  )
$$;

-- ----- organizaciones
create or replace function public._trg_aud_organizaciones()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    perform public._auditar(new.id, 'org_creada', 'creó la organización "' || new.nombre || '"');
  elsif tg_op = 'UPDATE' then
    if new.nombre is distinct from old.nombre then
      perform public._auditar(new.id, 'org_renombrada',
        'cambió el nombre de la organización de "' || old.nombre || '" a "' || new.nombre || '"');
    end if;
    if new.propietario_id is distinct from old.propietario_id then
      perform public._auditar(new.id, 'propiedad_transferida',
        'transfirió la propiedad de la organización a ' || public._nombre_usuario(new.propietario_id));
    end if;
  end if;
  return null;
end $$;

drop trigger if exists aud_organizaciones on public.organizaciones;
create trigger aud_organizaciones
  after insert or update on public.organizaciones
  for each row execute function public._trg_aud_organizaciones();

-- ----- roles
create or replace function public._trg_aud_roles()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    if new.organizacion_id is not null and not public._org_recien_creada(new.organizacion_id) then
      perform public._auditar(new.organizacion_id, 'rol_creado', 'creó el rol "' || new.nombre || '"',
                              'rol:' || new.id);
    end if;
  elsif tg_op = 'UPDATE' then
    if new.organizacion_id is not null then
      if new.nombre is distinct from old.nombre then
        perform public._auditar(new.organizacion_id, 'rol_editado',
          'cambió el nombre del rol "' || old.nombre || '" a "' || new.nombre || '"');
      elsif new.descripcion is distinct from old.descripcion then
        perform public._auditar(new.organizacion_id, 'rol_editado',
          'cambió la descripción del rol "' || new.nombre || '"');
      end if;
    end if;
  elsif tg_op = 'DELETE' then
    if old.organizacion_id is not null then
      -- la baja de permisos que precede al borrado del rol no aporta: se descarta
      delete from public.auditoria_org where txid = txid_current() and clave = 'permisos:' || old.id;
      perform public._auditar(old.organizacion_id, 'rol_eliminado', 'eliminó el rol "' || old.nombre || '"');
    end if;
  end if;
  return null;
end $$;

drop trigger if exists aud_roles on public.roles;
create trigger aud_roles
  after insert or update or delete on public.roles
  for each row execute function public._trg_aud_roles();

-- ----- permisos_rol (una sola entrada por rol y transacción, aunque se reescriban varias filas)
create or replace function public._trg_aud_permisos()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_rol uuid := coalesce(new.rol_id, old.rol_id);
  v_r   record;
begin
  select r.id, r.nombre, r.organizacion_id into v_r from public.roles r where r.id = v_rol;
  if not found or v_r.organizacion_id is null then
    return null;
  end if;
  if public._org_recien_creada(v_r.organizacion_id) then
    return null;
  end if;
  if exists (
    select 1 from public.auditoria_org
     where txid = txid_current() and clave in ('permisos:' || v_rol, 'rol:' || v_rol)
  ) then
    return null;  -- ya registrado, o el rol se acaba de crear en esta transacción
  end if;
  perform public._auditar(v_r.organizacion_id, 'permisos_modificados',
    'modificó los permisos del rol "' || v_r.nombre || '"', 'permisos:' || v_rol);
  return null;
end $$;

drop trigger if exists aud_permisos on public.permisos_rol;
create trigger aud_permisos
  after insert or update or delete on public.permisos_rol
  for each row execute function public._trg_aud_permisos();

-- ----- sedes
create or replace function public._trg_aud_sedes()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    if not public._org_recien_creada(new.organizacion_id) then
      perform public._auditar(new.organizacion_id, 'sede_creada', 'creó la sede "' || new.nombre || '"');
    end if;
  elsif tg_op = 'UPDATE' then
    if new.nombre is distinct from old.nombre then
      perform public._auditar(new.organizacion_id, 'sede_editada',
        'cambió el nombre de la sede "' || old.nombre || '" a "' || new.nombre || '"');
    elsif new.ciudad is distinct from old.ciudad then
      perform public._auditar(new.organizacion_id, 'sede_editada',
        'cambió la ciudad de la sede "' || new.nombre || '"');
    end if;
  elsif tg_op = 'DELETE' then
    perform public._auditar(old.organizacion_id, 'sede_eliminada', 'eliminó la sede "' || old.nombre || '"');
  end if;
  return null;
end $$;

drop trigger if exists aud_sedes on public.sedes;
create trigger aud_sedes
  after insert or update or delete on public.sedes
  for each row execute function public._trg_aud_sedes();

-- ----- membresías
create or replace function public._trg_aud_membresias()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_quien text := public._nombre_usuario(new.usuario_id);
  v_rol   text;
  v_rol_o text;
  v_sede  text;
  v_sede_o text;
begin
  if public._org_recien_creada(new.organizacion_id) then
    return null;
  end if;

  select r.nombre into v_rol from public.roles r where r.id = new.rol_id;
  select s.nombre into v_sede from public.sedes s where s.id = new.sede_id;

  if tg_op = 'INSERT' then
    if new.estado_membresia = 'pendiente' then
      perform public._auditar(new.organizacion_id, 'solicitud_recibida', v_quien || ' solicitó unirse');
    else
      perform public._auditar(new.organizacion_id, 'miembro_agregado',
        'agregó a ' || v_quien || ' con el rol "' || coalesce(v_rol, '?') || '"');
    end if;
    return null;
  end if;

  -- UPDATE
  if new.estado_membresia is distinct from old.estado_membresia then
    if old.estado_membresia = 'pendiente' and new.estado_membresia = 'activa' then
      perform public._auditar(new.organizacion_id, 'solicitud_aceptada',
        'aceptó a ' || v_quien || ' con el rol "' || coalesce(v_rol, '?') || '"'
        || case when v_sede is not null then ' en la sede "' || v_sede || '"' else '' end);
    elsif old.estado_membresia = 'pendiente' and new.estado_membresia = 'retirada' then
      perform public._auditar(new.organizacion_id, 'solicitud_rechazada', 'rechazó la solicitud de ' || v_quien);
    elsif new.estado_membresia = 'suspendida' then
      perform public._auditar(new.organizacion_id, 'miembro_suspendido', 'suspendió a ' || v_quien);
    elsif old.estado_membresia = 'suspendida' and new.estado_membresia = 'activa' then
      perform public._auditar(new.organizacion_id, 'miembro_reactivado', 'reactivó a ' || v_quien);
    elsif new.estado_membresia = 'retirada' then
      perform public._auditar(new.organizacion_id, 'miembro_retirado', 'retiró a ' || v_quien);
    elsif old.estado_membresia = 'retirada' and new.estado_membresia = 'pendiente' then
      perform public._auditar(new.organizacion_id, 'solicitud_recibida', v_quien || ' volvió a solicitar unirse');
    elsif new.estado_membresia = 'activa' then
      perform public._auditar(new.organizacion_id, 'miembro_agregado',
        'incorporó a ' || v_quien || ' con el rol "' || coalesce(v_rol, '?') || '"');
    end if;
  elsif new.rol_id is distinct from old.rol_id then
    select r.nombre into v_rol_o from public.roles r where r.id = old.rol_id;
    perform public._auditar(new.organizacion_id, 'rol_cambiado',
      'cambió el rol de ' || v_quien || ' de "' || coalesce(v_rol_o, '?') || '" a "' || coalesce(v_rol, '?') || '"');
  elsif new.sede_id is distinct from old.sede_id then
    select s.nombre into v_sede_o from public.sedes s where s.id = old.sede_id;
    perform public._auditar(new.organizacion_id, 'sede_cambiada',
      'cambió la sede de ' || v_quien || ' de "' || coalesce(v_sede_o, 'sin sede') || '" a "' || coalesce(v_sede, 'sin sede') || '"');
  end if;
  return null;
end $$;

drop trigger if exists aud_membresias on public.membresias;
create trigger aud_membresias
  after insert or update on public.membresias
  for each row execute function public._trg_aud_membresias();

create or replace function public.listar_auditoria(p_org uuid, p_limite integer default 100)
returns table (id bigint, fecha timestamptz, usuario text, accion text, descripcion text)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede ver el historial';
  end if;

  return query
  select a.id, a.creada_en,
         case when a.usuario_id is null then 'Sistema' else public._nombre_usuario(a.usuario_id) end,
         a.accion, a.descripcion
  from public.auditoria_org a
  where a.organizacion_id = p_org
  order by a.creada_en desc, a.id desc
  limit greatest(1, least(coalesce(p_limite, 100), 500));
end $$;

-- -----------------------------------------------------------------------------
-- Permisos de ejecución (los privilegios por defecto del proyecto dan EXECUTE a anon)
-- -----------------------------------------------------------------------------
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname = any (array[
        'cambiar_estado_miembro', 'listar_sedes_org', '_validar_sede', 'crear_sede', 'editar_sede',
        'eliminar_sede', '_permisos_base', 'restablecer_rol_base', '_nombre_usuario', '_auditar',
        '_org_recien_creada', '_trg_aud_organizaciones', '_trg_aud_roles', '_trg_aud_permisos',
        '_trg_aud_sedes', '_trg_aud_membresias', 'listar_auditoria'
      ])
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    if f.proname in ('cambiar_estado_miembro', 'listar_sedes_org', 'crear_sede', 'editar_sede',
                     'eliminar_sede', 'restablecer_rol_base', 'listar_auditoria') then
      execute format('grant execute on function %s to authenticated', f.sig);
    end if;
  end loop;
end $$;

commit;
