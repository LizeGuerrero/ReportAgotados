-- Cuentas por pagar (CXP) · Fase 1: módulos de permisos, tabla de documentos y RPC de cartera.
-- Idempotente: se puede ejecutar más de una vez. No modifica nada de Pedidos ni de Auth.
-- OJO: si ya aplicaste la Fase 2 en tu base de Supabase, NO vuelvas a ejecutar este archivo allí
-- (dejaría funciones de la Fase 1 por encima de las de la Fase 2). Solo sirve para bases nuevas y para las pruebas.
begin;

-- 1. Módulos de permisos (aparecen solos en el editor de roles) ------------------------------
insert into public.modulos (nombre, descripcion) values
  ('cxp',       'Cuentas por pagar: cartera pendiente (ver, agregar manuales, anotar, eliminar manuales)'),
  ('cxp_pagos', 'Cuentas por pagar: pagos (ver pagados, marcar como pagado y reabrir)')
on conflict (nombre) do nothing;

-- Solo los administradores los reciben. Las organizaciones nuevas los reciben solas
-- (crear_organizacion da todos los módulos al rol admin).
insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
select r.id, mo.id, true, true, true, true
from public.roles r
cross join public.modulos mo
where r.nombre = 'admin' and r.organizacion_id is not null
  and mo.nombre in ('cxp', 'cxp_pagos')
on conflict (rol_id, modulo_id) do nothing;

-- 2. Tabla de documentos ----------------------------------------------------------------------
-- Una sola tabla para lo que viene del ERP (origen 'erp') y para lo que se escribe a mano ('manual').
create table if not exists public.cxp_documentos (
  id               uuid primary key default gen_random_uuid(),
  organizacion_id  uuid not null references public.organizaciones(id),
  origen           text not null default 'manual' check (origen in ('erp', 'manual')),
  -- Datos que se muestran
  empresa          text,
  tercero          text,                       -- NIT o cédula, sin puntos ni dígito de verificación
  nombre           text not null,
  cond_pago        text,
  docto_proveedor  text,                       -- número de la factura del proveedor
  docto_proveedor_norm text generated always as
    (nullif(upper(regexp_replace(coalesce(docto_proveedor, ''), '[^A-Za-z0-9]', '', 'g')), '')) stored,
  fecha_dcto       date,
  fecha_vcto       date,
  plazo            integer,
  -- Datos del ERP que no se muestran en la cartera (se llenan en la Fase 2)
  documento_erp    text,
  co_codigo        text,
  sede_id          uuid references public.sedes(id),
  detalle_erp      text,
  erp_raw          jsonb,
  -- Valores
  total_factura    numeric(16,2) not null,     -- ERP: saldo del ERP. Manual: lo que se digita
  anticipos        numeric(16,2) not null default 0,
  descuentos       numeric(16,2) not null default 0,
  retenciones      numeric(16,2) not null default 0,
  val_pagar        numeric(16,2) generated always as
    (total_factura - retenciones - anticipos - descuentos) stored,
  detalles         text,
  -- Estado
  estado           text not null default 'pendiente' check (estado in ('pendiente', 'pagado')),
  fecha_pago       timestamptz,
  pagado_por       uuid references public.profiles(id),
  creado_por       uuid references public.profiles(id),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  constraint cxp_valores_chk check (anticipos >= 0 and descuentos >= 0 and retenciones >= 0),
  constraint cxp_fechas_chk  check (fecha_dcto is null or fecha_vcto is null or fecha_vcto >= fecha_dcto),
  constraint cxp_erp_clave_chk check (origen <> 'erp' or (tercero is not null and documento_erp is not null)),
  constraint cxp_pago_chk check ((estado = 'pagado') = (fecha_pago is not null))
);

comment on table public.cxp_documentos is 'Cartera por pagar: filas del ERP (origen erp) y pendientes escritos a mano (origen manual).';
comment on column public.cxp_documentos.total_factura is 'ERP: saldo que trae el ERP. Manual: valor digitado. Es la base de val_pagar.';
comment on column public.cxp_documentos.val_pagar is 'total_factura - retenciones - anticipos - descuentos.';

create unique index if not exists cxp_documentos_erp_uk
  on public.cxp_documentos (organizacion_id, coalesce(empresa, ''), tercero, lower(btrim(documento_erp)))
  where origen = 'erp';
create index if not exists cxp_documentos_org_estado_idx
  on public.cxp_documentos (organizacion_id, estado, fecha_vcto);
create index if not exists cxp_documentos_cruce_idx
  on public.cxp_documentos (organizacion_id, tercero, docto_proveedor_norm)
  where docto_proveedor_norm is not null;

drop trigger if exists trg_cxp_documentos_updated_at on public.cxp_documentos;
create trigger trg_cxp_documentos_updated_at before update on public.cxp_documentos
  for each row execute function public.set_updated_at();

-- Historial de cambios (mismo mecanismo que ítems y proveedores)
drop trigger if exists trg_auditar_cxp_documentos on public.cxp_documentos;
create trigger trg_auditar_cxp_documentos after insert or delete or update on public.cxp_documentos
  for each row execute function public.auditar_cambio();

-- 3. Seguridad de la tabla ----------------------------------------------------------------------
-- Solo se lee con permiso; todo cambio pasa por las funciones de abajo.
alter table public.cxp_documentos enable row level security;
drop policy if exists cxp_documentos_select on public.cxp_documentos;
create policy cxp_documentos_select on public.cxp_documentos for select using (
  (estado = 'pendiente' and public.tiene_permiso(organizacion_id, 'cxp', 'ver'))
  or (estado = 'pagado' and public.tiene_permiso(organizacion_id, 'cxp_pagos', 'ver'))
);
revoke all on table public.cxp_documentos from anon;
revoke insert, update, delete on table public.cxp_documentos from authenticated;

-- 4. Funciones internas ---------------------------------------------------------------------------
create or replace function public._cxp_hoy() returns date
  language sql stable set search_path to ''
as $fn$ select (now() at time zone 'America/Bogota')::date $fn$;

-- Documento de un tercero: sin puntos ni espacios; "900123456-7" queda "900123456".
create or replace function public._cxp_nit(p_nit text) returns text
  language plpgsql immutable set search_path to ''
as $fn$
declare v text := upper(regexp_replace(btrim(coalesce(p_nit, '')), '[\s.]', '', 'g'));
begin
  if v = '' then return null; end if;
  if v ~ '^[0-9A-Z]+-[0-9]$' then v := split_part(v, '-', 1); end if;
  if v !~ '^[A-Z0-9]{3,20}$' then
    raise exception 'Documento del tercero no válido: de 3 a 20 letras o números (el dígito de verificación va después de un guion)';
  end if;
  return v;
end $fn$;

-- Filtro común de la cartera: lo usan el listado y los totales para que siempre coincidan.
create or replace function public._cxp_filtrar(
  p_org uuid, p_estado text, p_busqueda text, p_tercero text, p_nombre text, p_sede uuid, p_origen text
) returns setof public.cxp_documentos
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  if p_estado is null or p_estado not in ('pendiente', 'pagado') then raise exception 'Estado no válido'; end if;
  if p_estado = 'pagado' then
    perform public._exigir_permiso(p_org, 'cxp_pagos', 'ver');
  else
    perform public._exigir_permiso(p_org, 'cxp', 'ver');
  end if;
  if coalesce(p_origen, '') not in ('', 'erp', 'manual') then raise exception 'Origen no válido'; end if;
  if p_sede is not null and not exists (select 1 from public.sedes where id = p_sede and organizacion_id = p_org) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select d.*
  from public.cxp_documentos d
  where d.organizacion_id = p_org
    and d.estado = p_estado
    and (coalesce(p_origen, '') = '' or d.origen = p_origen)
    and (p_sede is null or d.sede_id = p_sede)
    and (nullif(btrim(p_tercero), '') is null or d.tercero = upper(btrim(p_tercero)))
    and (nullif(btrim(p_nombre), '') is null or lower(btrim(d.nombre)) = lower(btrim(p_nombre)))
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(d.nombre)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.tercero, '')) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.docto_proveedor, '')) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.documento_erp, '')) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(coalesce(d.detalle_erp, '') || ' ' || coalesce(d.detalles, ''))) like '%' || t.term || '%' escape '\'
      )
    );
end $fn$;

-- 5. Cartera: listado, totales y listas auxiliares ------------------------------------------------
drop function if exists public.cxp_listar(uuid, text, text, text, text, uuid, text, text, text, text, integer, integer);
create or replace function public.cxp_listar(
  p_org uuid,
  p_estado text default 'pendiente',
  p_busqueda text default null,
  p_tercero text default null,
  p_nombre text default null,
  p_sede uuid default null,
  p_origen text default null,
  p_vencimiento text default null,
  p_orden text default null,
  p_dir text default 'asc',
  p_limit integer default 50,
  p_offset integer default 0
) returns table (
  id uuid, origen text, empresa text, tercero text, nombre text, cond_pago text,
  docto_proveedor text, documento_erp text, fecha_dcto date, fecha_vcto date, plazo integer,
  dias_venc integer, vencido boolean, sede text, anticipos numeric, descuentos numeric,
  retenciones numeric, total_factura numeric, val_pagar numeric, detalles text, estado text,
  fecha_pago timestamptz, pagado_por text, total bigint
)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare
  v_hoy date := public._cxp_hoy();
  v_orden text := nullif(trim(p_orden), '');
  v_asc boolean;
begin
  if coalesce(p_vencimiento, '') not in ('', 'vencidos', 'por_vencer') then
    raise exception 'Filtro de vencimiento no válido';
  end if;
  if v_orden is not null and v_orden not in
     ('nombre', 'tercero', 'fecha_dcto', 'fecha_vcto', 'dias_venc', 'val_pagar', 'total_factura', 'fecha_pago') then
    raise exception 'Columna de orden no válida';
  end if;
  if coalesce(p_dir, 'asc') not in ('asc', 'desc') then raise exception 'Dirección de orden no válida'; end if;
  if v_orden is null then
    -- Sin orden elegido: pendientes, los más vencidos primero; pagados, los más recientes primero.
    v_orden := case when p_estado = 'pagado' then 'fecha_pago' else 'fecha_vcto' end;
    v_asc := p_estado <> 'pagado';
  else
    v_asc := coalesce(p_dir, 'asc') = 'asc';
  end if;

  return query
  with b as (
    select d.id, d.origen, d.empresa, d.tercero, d.nombre, d.cond_pago, d.docto_proveedor,
           d.documento_erp, d.fecha_dcto, d.fecha_vcto, d.plazo,
           greatest(0, v_hoy - d.fecha_vcto) as dias,
           (d.fecha_vcto is not null and d.fecha_vcto < v_hoy) as venc,
           s.nombre as sede_nombre, d.anticipos, d.descuentos, d.retenciones, d.total_factura,
           d.val_pagar, d.detalles, d.estado, d.fecha_pago,
           nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), '') as pagador
    from public._cxp_filtrar(p_org, p_estado, p_busqueda, p_tercero, p_nombre, p_sede, p_origen) d
    left join public.sedes s on s.id = d.sede_id
    left join public.profiles pu on pu.id = d.pagado_por
  )
  select b.id, b.origen, b.empresa, b.tercero, b.nombre, b.cond_pago, b.docto_proveedor,
         b.documento_erp, b.fecha_dcto, b.fecha_vcto, b.plazo, b.dias, b.venc, b.sede_nombre,
         b.anticipos, b.descuentos, b.retenciones, b.total_factura, b.val_pagar, b.detalles,
         b.estado, b.fecha_pago, b.pagador, count(*) over()
  from b
  where case coalesce(p_vencimiento, '')
          when 'vencidos' then b.venc
          when 'por_vencer' then not b.venc
          else true end
  order by
    case when v_asc then (case v_orden when 'nombre' then lower(b.nombre) when 'tercero' then b.tercero end) end asc nulls last,
    case when not v_asc then (case v_orden when 'nombre' then lower(b.nombre) when 'tercero' then b.tercero end) end desc nulls last,
    case when v_asc then (case v_orden when 'dias_venc' then b.dias::numeric when 'val_pagar' then b.val_pagar
                                       when 'total_factura' then b.total_factura end) end asc nulls last,
    case when not v_asc then (case v_orden when 'dias_venc' then b.dias::numeric when 'val_pagar' then b.val_pagar
                                           when 'total_factura' then b.total_factura end) end desc nulls last,
    case when v_asc then (case v_orden when 'fecha_dcto' then b.fecha_dcto::timestamptz
                                       when 'fecha_vcto' then b.fecha_vcto::timestamptz
                                       when 'fecha_pago' then b.fecha_pago end) end asc nulls last,
    case when not v_asc then (case v_orden when 'fecha_dcto' then b.fecha_dcto::timestamptz
                                           when 'fecha_vcto' then b.fecha_vcto::timestamptz
                                           when 'fecha_pago' then b.fecha_pago end) end desc nulls last,
    lower(b.nombre), b.id
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $fn$;

-- Totales con los mismos filtros del listado, SIN el de vencimiento (así las tarjetas
-- siguen mostrando los tres montos aunque se esté filtrando por uno de ellos).
create or replace function public.cxp_totales(
  p_org uuid,
  p_estado text default 'pendiente',
  p_busqueda text default null,
  p_tercero text default null,
  p_nombre text default null,
  p_sede uuid default null,
  p_origen text default null
) returns table (
  suma_total numeric, suma_vencido numeric, suma_por_vencer numeric,
  n_total bigint, n_vencido bigint, n_por_vencer bigint
)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_hoy date := public._cxp_hoy();
begin
  return query
  select coalesce(sum(d.val_pagar), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where d.fecha_vcto < v_hoy), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where not (d.fecha_vcto < v_hoy) or d.fecha_vcto is null), 0)::numeric,
         count(*),
         count(*) filter (where d.fecha_vcto < v_hoy),
         count(*) filter (where not (d.fecha_vcto < v_hoy) or d.fecha_vcto is null)
  from public._cxp_filtrar(p_org, p_estado, p_busqueda, p_tercero, p_nombre, p_sede, p_origen) d;
end $fn$;

-- Proveedores presentes en la cartera (para el filtro por proveedor).
create or replace function public.cxp_proveedores_filtro(p_org uuid, p_estado text default 'pendiente')
returns table (tercero text, nombre text, documentos integer)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
begin
  if p_estado is null or p_estado not in ('pendiente', 'pagado') then raise exception 'Estado no válido'; end if;
  if p_estado = 'pagado' then
    perform public._exigir_permiso(p_org, 'cxp_pagos', 'ver');
  else
    perform public._exigir_permiso(p_org, 'cxp', 'ver');
  end if;
  return query
  select d.tercero, (array_agg(d.nombre order by d.updated_at desc))[1], count(*)::int
  from public.cxp_documentos d
  where d.organizacion_id = p_org and d.estado = p_estado
  group by coalesce(d.tercero, 'n:' || lower(btrim(d.nombre))), d.tercero
  order by 2;
end $fn$;

-- Rellenado automático al escribir un pendiente: terceros ya vistos en la cartera
-- y proveedores del módulo Proveedores (se cruzan por número de documento).
create or replace function public.cxp_terceros(p_org uuid, p_busqueda text default null, p_limit integer default 8)
returns table (tercero text, nombre text, cond_pago text, fuente text)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_q text;
begin
  perform public._exigir_permiso(p_org, 'cxp', 'ver');
  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  if char_length(v_q) < 2 then return; end if;

  return query
  select x.tercero, x.nombre, x.cond_pago, x.fuente
  from (
    select distinct on (u.tercero) u.tercero, u.nombre, u.cond_pago, u.fuente, u.prio
    from (
      select d.tercero, d.nombre, d.cond_pago, 'cartera'::text as fuente, 1 as prio, d.updated_at as f
      from public.cxp_documentos d
      where d.organizacion_id = p_org and d.tercero is not null
      union all
      select pv.numero_documento, pv.nombre, null::text, 'proveedores'::text, 2, pv.created_at
      from public.proveedores pv
      where pv.organizacion_id = p_org
    ) u
    where extensions.unaccent(lower(u.nombre)) like '%' || v_q || '%' escape '\'
       or lower(u.tercero) like v_q || '%' escape '\'
    order by u.tercero, u.prio, u.f desc
  ) x
  order by x.nombre
  limit least(greatest(p_limit, 1), 20);
end $fn$;

create or replace function public.cxp_listar_sedes(p_org uuid)
returns table (id uuid, nombre text)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if not (public.tiene_permiso(p_org, 'cxp', 'ver') or public.tiene_permiso(p_org, 'cxp_pagos', 'ver')) then
    raise exception 'Sin permiso para ver cuentas por pagar';
  end if;
  return query select s.id, s.nombre from public.sedes s where s.organizacion_id = p_org order by s.nombre;
end $fn$;

-- 6. Cambios ------------------------------------------------------------------------------------------
create or replace function public.cxp_manual_crear(p_org uuid, p_datos jsonb) returns uuid
  language plpgsql security definer set search_path to ''
as $fn$
declare
  v_nombre text; v_tercero text; v_docto text; v_cond text; v_det text;
  v_dcto date; v_vcto date; v_total numeric; v_ant numeric; v_desc numeric; v_ret numeric;
  v_sede uuid; v_norm text; v_estado text; v_id uuid;
begin
  perform public._exigir_permiso(p_org, 'cxp', 'crear');
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;

  v_nombre := nullif(btrim(p_datos->>'nombre'), '');
  if v_nombre is null then raise exception 'Escribe el nombre del proveedor'; end if;
  if char_length(v_nombre) > 200 then raise exception 'El nombre no puede superar 200 caracteres'; end if;
  v_tercero := public._cxp_nit(p_datos->>'tercero');
  v_docto := nullif(btrim(p_datos->>'docto_proveedor'), '');
  if char_length(coalesce(v_docto, '')) > 100 then raise exception 'La factura no puede superar 100 caracteres'; end if;
  v_cond := nullif(btrim(p_datos->>'cond_pago'), '');
  if char_length(coalesce(v_cond, '')) > 60 then raise exception 'La condición de pago no puede superar 60 caracteres'; end if;
  v_det := nullif(btrim(p_datos->>'detalles'), '');
  if char_length(coalesce(v_det, '')) > 500 then raise exception 'Los detalles no pueden superar 500 caracteres'; end if;

  v_dcto := nullif(btrim(p_datos->>'fecha_dcto'), '')::date;
  v_vcto := nullif(btrim(p_datos->>'fecha_vcto'), '')::date;
  if v_vcto is null then raise exception 'Escribe la fecha de vencimiento'; end if;
  if v_dcto is not null and v_vcto < v_dcto then
    raise exception 'El vencimiento no puede ser anterior a la fecha del documento';
  end if;

  v_total := nullif(btrim(p_datos->>'total_factura'), '')::numeric;
  if v_total is null or v_total <= 0 then raise exception 'Escribe el total de la factura (mayor a 0)'; end if;
  v_ant  := coalesce(nullif(btrim(p_datos->>'anticipos'), '')::numeric, 0);
  v_desc := coalesce(nullif(btrim(p_datos->>'descuentos'), '')::numeric, 0);
  v_ret  := coalesce(nullif(btrim(p_datos->>'retenciones'), '')::numeric, 0);
  if v_ant < 0 or v_desc < 0 or v_ret < 0 then raise exception 'Anticipos, descuentos y retenciones no pueden ser negativos'; end if;
  if v_total - v_ant - v_desc - v_ret < 0 then raise exception 'Los anticipos, descuentos y retenciones superan el total'; end if;

  v_sede := nullif(btrim(p_datos->>'sede_id'), '')::uuid;
  if v_sede is not null and not exists (select 1 from public.sedes where id = v_sede and organizacion_id = p_org) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  v_norm := nullif(upper(regexp_replace(coalesce(v_docto, ''), '[^A-Za-z0-9]', '', 'g')), '');
  if v_tercero is not null and v_norm is not null then
    select x.estado into v_estado from public.cxp_documentos x
     where x.organizacion_id = p_org and x.tercero = v_tercero and x.docto_proveedor_norm = v_norm limit 1;
    if found then
      raise exception 'Esa factura de este tercero ya está registrada (%)', v_estado;
    end if;
  end if;

  insert into public.cxp_documentos
    (organizacion_id, origen, tercero, nombre, cond_pago, docto_proveedor, fecha_dcto, fecha_vcto,
     plazo, sede_id, total_factura, anticipos, descuentos, retenciones, detalles, creado_por)
  values
    (p_org, 'manual', v_tercero, v_nombre, v_cond, v_docto, v_dcto, v_vcto,
     case when v_dcto is not null then v_vcto - v_dcto end, v_sede, v_total, v_ant, v_desc, v_ret, v_det, auth.uid())
  returning id into v_id;
  return v_id;
end $fn$;

-- Anotaciones (anticipos, descuentos, retenciones, detalles) en cualquier pendiente;
-- el resto de los datos solo en los manuales (los del ERP los trae la carga).
create or replace function public.cxp_actualizar(p_org uuid, p_id uuid, p_datos jsonb) returns void
  language plpgsql security definer set search_path to ''
as $fn$
declare
  v public.cxp_documentos%rowtype;
  v_ant numeric; v_desc numeric; v_ret numeric; v_det text;
  v_nombre text; v_tercero text; v_docto text; v_cond text; v_dcto date; v_vcto date;
  v_total numeric; v_sede uuid; v_norm text;
begin
  perform public._exigir_permiso(p_org, 'cxp', 'editar');
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;
  select * into v from public.cxp_documentos where id = p_id and organizacion_id = p_org for update;
  if not found then raise exception 'Documento no encontrado'; end if;
  if v.estado <> 'pendiente' then raise exception 'Un documento pagado no se puede editar: reábrelo primero'; end if;

  if v.origen = 'erp' and p_datos ?| array['nombre', 'tercero', 'docto_proveedor', 'cond_pago', 'fecha_dcto',
                                           'fecha_vcto', 'total_factura', 'sede_id'] then
    raise exception 'Los datos que vienen del ERP no se editan aquí: se actualizan con la carga del archivo';
  end if;

  v_ant  := case when p_datos ? 'anticipos'   then coalesce(nullif(btrim(p_datos->>'anticipos'), '')::numeric, 0)   else v.anticipos end;
  v_desc := case when p_datos ? 'descuentos'  then coalesce(nullif(btrim(p_datos->>'descuentos'), '')::numeric, 0)  else v.descuentos end;
  v_ret  := case when p_datos ? 'retenciones' then coalesce(nullif(btrim(p_datos->>'retenciones'), '')::numeric, 0) else v.retenciones end;
  v_det  := case when p_datos ? 'detalles'    then nullif(btrim(p_datos->>'detalles'), '') else v.detalles end;
  if v_ant < 0 or v_desc < 0 or v_ret < 0 then raise exception 'Anticipos, descuentos y retenciones no pueden ser negativos'; end if;
  if char_length(coalesce(v_det, '')) > 500 then raise exception 'Los detalles no pueden superar 500 caracteres'; end if;

  v_nombre  := case when p_datos ? 'nombre'          then nullif(btrim(p_datos->>'nombre'), '') else v.nombre end;
  v_tercero := case when p_datos ? 'tercero'         then public._cxp_nit(p_datos->>'tercero') else v.tercero end;
  v_docto   := case when p_datos ? 'docto_proveedor' then nullif(btrim(p_datos->>'docto_proveedor'), '') else v.docto_proveedor end;
  v_cond    := case when p_datos ? 'cond_pago'       then nullif(btrim(p_datos->>'cond_pago'), '') else v.cond_pago end;
  v_dcto    := case when p_datos ? 'fecha_dcto'      then nullif(btrim(p_datos->>'fecha_dcto'), '')::date else v.fecha_dcto end;
  v_vcto    := case when p_datos ? 'fecha_vcto'      then nullif(btrim(p_datos->>'fecha_vcto'), '')::date else v.fecha_vcto end;
  v_total   := case when p_datos ? 'total_factura'   then nullif(btrim(p_datos->>'total_factura'), '')::numeric else v.total_factura end;
  v_sede    := case when p_datos ? 'sede_id'         then nullif(btrim(p_datos->>'sede_id'), '')::uuid else v.sede_id end;

  if v_nombre is null then raise exception 'El nombre no puede quedar vacío'; end if;
  if char_length(v_nombre) > 200 then raise exception 'El nombre no puede superar 200 caracteres'; end if;
  if char_length(coalesce(v_docto, '')) > 100 then raise exception 'La factura no puede superar 100 caracteres'; end if;
  if char_length(coalesce(v_cond, '')) > 60 then raise exception 'La condición de pago no puede superar 60 caracteres'; end if;
  if v_vcto is null then raise exception 'Escribe la fecha de vencimiento'; end if;
  if v_dcto is not null and v_vcto < v_dcto then raise exception 'El vencimiento no puede ser anterior a la fecha del documento'; end if;
  if v_total is null or v_total <= 0 then raise exception 'Escribe el total de la factura (mayor a 0)'; end if;
  if v_total - v_ant - v_desc - v_ret < 0 then raise exception 'Los anticipos, descuentos y retenciones superan el total'; end if;
  if v_sede is not null and not exists (select 1 from public.sedes where id = v_sede and organizacion_id = p_org) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  v_norm := nullif(upper(regexp_replace(coalesce(v_docto, ''), '[^A-Za-z0-9]', '', 'g')), '');
  if v.origen = 'manual' and v_tercero is not null and v_norm is not null and exists (
    select 1 from public.cxp_documentos x
     where x.organizacion_id = p_org and x.id <> p_id and x.tercero = v_tercero and x.docto_proveedor_norm = v_norm
  ) then
    raise exception 'Esa factura de este tercero ya está registrada';
  end if;

  update public.cxp_documentos set
    anticipos = v_ant, descuentos = v_desc, retenciones = v_ret, detalles = v_det,
    nombre = v_nombre, tercero = v_tercero, docto_proveedor = v_docto, cond_pago = v_cond,
    fecha_dcto = v_dcto, fecha_vcto = v_vcto, total_factura = v_total, sede_id = v_sede,
    plazo = case when v.origen = 'manual' and v_dcto is not null then v_vcto - v_dcto
                 when v.origen = 'manual' then null else plazo end
  where id = p_id;
end $fn$;

create or replace function public.cxp_manual_eliminar(p_org uuid, p_id uuid) returns void
  language plpgsql security definer set search_path to ''
as $fn$
begin
  perform public._exigir_permiso(p_org, 'cxp', 'eliminar');
  delete from public.cxp_documentos
   where id = p_id and organizacion_id = p_org and origen = 'manual' and estado = 'pendiente';
  if not found then raise exception 'Solo se pueden eliminar pendientes manuales que no estén pagados'; end if;
end $fn$;

create or replace function public.cxp_marcar_pagado(p_org uuid, p_ids uuid[]) returns integer
  language plpgsql security definer set search_path to ''
as $fn$
declare v_n integer; v_esperados integer;
begin
  perform public._exigir_permiso(p_org, 'cxp_pagos', 'editar');
  if p_ids is null or cardinality(p_ids) = 0 then raise exception 'Selecciona al menos un documento'; end if;
  select count(distinct x) into v_esperados from unnest(p_ids) x;

  update public.cxp_documentos
     set estado = 'pagado', fecha_pago = now(), pagado_por = auth.uid()
   where organizacion_id = p_org and estado = 'pendiente' and id = any(p_ids);
  get diagnostics v_n = row_count;

  if v_n <> v_esperados then
    raise exception 'Algún documento ya estaba pagado o no existe; no se marcó ninguno';
  end if;
  return v_n;
end $fn$;

create or replace function public.cxp_reabrir(p_org uuid, p_id uuid) returns void
  language plpgsql security definer set search_path to ''
as $fn$
begin
  perform public._exigir_permiso(p_org, 'cxp_pagos', 'editar');
  update public.cxp_documentos
     set estado = 'pendiente', fecha_pago = null, pagado_por = null
   where id = p_id and organizacion_id = p_org and estado = 'pagado';
  if not found then raise exception 'Ese documento no está pagado'; end if;
end $fn$;

-- 7. Permisos de ejecución: solo usuarios autenticados llaman a las funciones públicas ---------
do $do$
declare r record;
begin
  for r in
    select p.oid::regprocedure as f, p.proname
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and (p.proname like 'cxp\_%' escape '\' or p.proname like '\_cxp\_%' escape '\')
  loop
    execute format('revoke all on function %s from public, anon', r.f);
    if r.proname like 'cxp\_%' escape '\' then
      execute format('grant execute on function %s to authenticated', r.f);
    end if;
    execute format('grant execute on function %s to service_role', r.f);
  end loop;
end $do$;

commit;
