-- =============================================================================
-- Organizaciones, invitaciones, solicitudes y administración de miembros
--
-- 100 % aditiva: no borra ni renombra nada. No toca handle_new_user, tiene_permiso
-- ni ninguna RPC de Pedidos/Agotados. Lo único existente que se reemplaza es UNA
-- política (SELECT de public.roles); su reversa está al final del archivo.
--
-- Correr completo en el SQL Editor de Supabase (corre en una sola transacción:
-- si algo falla, no queda nada a medias).
-- =============================================================================
begin;

-- -----------------------------------------------------------------------------
-- 1. Columnas e índices únicos
-- -----------------------------------------------------------------------------
-- Identificación de la organización (NIT, CC u otra). Sirve para ubicarla; NO es
-- credencial de acceso. Nullable para no romper la organización que ya existe.
alter table public.organizaciones add column if not exists identificacion text;

create unique index if not exists organizaciones_identificacion_key
  on public.organizaciones (identificacion) where identificacion is not null;

-- Propietario = quien crea la organización. Su rol de admin no lo puede cambiar nadie y solo
-- él puede quitarle el rol de admin a otros admins. NULL = organización sin propietario
-- (anterior a esta migración): se comporta como antes.
alter table public.organizaciones
  add column if not exists propietario_id uuid references auth.users(id);

-- La cédula es un registro único (por tipo de documento).
create unique index if not exists profiles_documento_key
  on public.profiles (tipo_documento, numero_documento) where numero_documento is not null;

-- Un nombre de rol por organización, y UNA membresía por usuario y organización
-- (cambiar de rol = UPDATE de esa fila, nunca una fila nueva).
create unique index if not exists roles_org_nombre_key
  on public.roles (organizacion_id, nombre) where organizacion_id is not null;

create unique index if not exists membresias_usuario_org_key
  on public.membresias (usuario_id, organizacion_id);

-- -----------------------------------------------------------------------------
-- 2. Utilidades
-- -----------------------------------------------------------------------------
create or replace function public.normalizar_identificacion(p text)
returns text
language sql
immutable
set search_path = ''
as $$
  select nullif(upper(regexp_replace(coalesce(p, ''), '[\s.]', '', 'g')), '')
$$;

-- ¿El usuario autenticado es admin ACTIVO de esa organización? (el rol "admin"
-- es el de esa misma organización; igual criterio que la política existente
-- "solo admin edita la organización").
create or replace function public.es_admin_org(p_org uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.membresias m
    join public.roles r on r.id = m.rol_id
    where m.usuario_id = auth.uid()
      and m.organizacion_id = p_org
      and m.activo = true
      and m.estado_membresia = 'activa'
      and r.nombre = 'admin'
      and r.organizacion_id = p_org
  )
$$;

-- -----------------------------------------------------------------------------
-- 3. Invitaciones
-- -----------------------------------------------------------------------------
-- Solo se guarda el HASH del token (sha256). El token en claro existe únicamente
-- en el enlace que recibe la persona invitada.
create table if not exists public.invitaciones (
  id               uuid primary key default gen_random_uuid(),
  organizacion_id  uuid not null references public.organizaciones(id) on delete cascade,
  email            text not null,
  rol_id           uuid not null references public.roles(id) on delete restrict,
  sede_id          uuid references public.sedes(id),
  token_hash       text not null unique,
  estado           text not null default 'pendiente'
                   check (estado in ('pendiente', 'aceptada', 'rechazada', 'cancelada')),
  invitado_por     uuid not null references auth.users(id),
  aceptada_por     uuid references auth.users(id),
  creada_en        timestamptz not null default now(),
  expira_en        timestamptz not null,
  resuelta_en      timestamptz
);

-- 'vencida' no se guarda: se deduce de expira_en (ver listar_invitaciones).
create unique index if not exists invitaciones_pendiente_email_key
  on public.invitaciones (organizacion_id, lower(email)) where estado = 'pendiente';

alter table public.invitaciones enable row level security;
-- Sin políticas: ningún usuario toca esta tabla directamente. Todo pasa por las
-- funciones SECURITY DEFINER de abajo.
revoke all on public.invitaciones from anon, authenticated;

-- -----------------------------------------------------------------------------
-- 4. Crear organización (el creador queda como admin)
-- -----------------------------------------------------------------------------
create or replace function public.crear_organizacion(p_nombre text, p_identificacion text)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid    uuid := auth.uid();
  v_nombre text := btrim(coalesce(p_nombre, ''));
  v_ident  text := public.normalizar_identificacion(p_identificacion);
  v_base   text;
  v_slug   text;
  v_org    uuid;
  v_sede   uuid;
  v_admin  uuid;
begin
  if v_uid is null then raise exception 'No autenticado'; end if;
  if not exists (select 1 from public.profiles where id = v_uid and perfil_completo) then
    raise exception 'Completa tu perfil antes de crear una organización';
  end if;
  if char_length(v_nombre) < 3 or char_length(v_nombre) > 120 then
    raise exception 'El nombre de la organización debe tener entre 3 y 120 caracteres';
  end if;
  if v_ident is null or v_ident !~ '^[A-Z0-9-]{5,20}$' then
    raise exception 'Identificación no válida: 5 a 20 caracteres, solo letras, números o guion';
  end if;
  if exists (select 1 from public.organizaciones where identificacion = v_ident) then
    raise exception 'Ya existe una organización con esa identificación';
  end if;

  -- slug legible y único a partir del nombre
  v_base := regexp_replace(
    lower(translate(v_nombre, 'áéíóúüñÁÉÍÓÚÜÑ', 'aeiouunaeiouun')), '[^a-z0-9]+', '-', 'g');
  v_base := btrim(left(btrim(v_base, '-'), 40), '-');
  if v_base = '' then v_base := 'org'; end if;
  v_slug := v_base;
  while exists (select 1 from public.organizaciones where slug = v_slug) loop
    v_slug := v_base || '-' || substr(md5(random()::text || clock_timestamp()::text), 1, 4);
  end loop;

  begin
    insert into public.organizaciones (slug, nombre, identificacion, propietario_id)
    values (v_slug, v_nombre, v_ident, v_uid)
    returning id into v_org;
  exception when unique_violation then
    raise exception 'No se pudo crear la organización: la identificación o el nombre ya están en uso';
  end;

  insert into public.sedes (organizacion_id, nombre) values (v_org, 'Principal')
  returning id into v_sede;

  -- Roles base (mismos que la organización de referencia). "viewer" es el rol
  -- Predeterminado: queda SIN filas en permisos_rol, o sea sin acceso a módulos.
  insert into public.roles (nombre, organizacion_id, descripcion) values
    ('admin',     v_org, 'Administrador de la organización'),
    ('Gerencia',  v_org, null),
    ('Compras',   v_org, null),
    ('Bodega',    v_org, null),
    ('Comercial', v_org, null),
    ('viewer',    v_org, 'Predeterminado: sin acceso a módulos');

  -- admin: todos los módulos con todos los permisos
  insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
  select r.id, mo.id, true, true, true, true
  from public.roles r
  cross join public.modulos mo
  where r.organizacion_id = v_org and r.nombre = 'admin';

  -- demás roles: matriz de la organización de referencia
  insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
  select r.id, mo.id, x.ver, x.crear, x.editar, x.eliminar
  from (values
    ('Bodega',    'Agotados',         true, false, true,  false),
    ('Bodega',    'Bodega',           true, true,  true,  false),
    ('Comercial', 'Agotados',         true, true,  true,  false),
    ('Comercial', 'reporte_agotados', true, true,  true,  false),
    ('Compras',   'Agotados',         true, false, false, false),
    ('Compras',   'Compras',          true, true,  true,  false),
    ('Compras',   'Items',            true, false, false, false),
    ('Compras',   'pedidos',          true, true,  true,  false),
    ('Compras',   'Proveedores',      true, true,  true,  false),
    ('Gerencia',  'Agotados',         true, false, true,  false),
    ('Gerencia',  'Bodega',           true, false, false, false),
    ('Gerencia',  'Compras',          true, false, false, false),
    ('Gerencia',  'Items',            true, false, false, false),
    ('Gerencia',  'Proveedores',      true, false, false, false)
  ) as x(rol, modulo, ver, crear, editar, eliminar)
  join public.roles r on r.organizacion_id = v_org and r.nombre = x.rol
  join public.modulos mo on mo.nombre = x.modulo;

  select id into v_admin from public.roles where organizacion_id = v_org and nombre = 'admin';

  insert into public.membresias (usuario_id, organizacion_id, rol_id, estado_membresia, activo, sede_id)
  values (v_uid, v_org, v_admin, 'activa', true, v_sede);

  return v_slug;
end $$;

-- -----------------------------------------------------------------------------
-- 5. Invitaciones: crear, consultar, aceptar, rechazar, cancelar, listar
-- -----------------------------------------------------------------------------
-- El token lo genera el servidor (Next.js) y aquí solo llega su hash.
create or replace function public.crear_invitacion(
  p_org uuid, p_email text, p_rol uuid, p_sede uuid, p_token_hash text
) returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_email text := lower(btrim(coalesce(p_email, '')));
  v_id    uuid;
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede invitar personas';
  end if;
  if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' or char_length(v_email) > 254 then
    raise exception 'Correo no válido';
  end if;
  if p_token_hash is null or p_token_hash !~ '^[0-9a-f]{64}$' then
    raise exception 'Token no válido';
  end if;
  if not exists (select 1 from public.roles where id = p_rol and organizacion_id = p_org) then
    raise exception 'El rol no pertenece a esta organización';
  end if;
  if p_sede is not null
     and not exists (select 1 from public.sedes where id = p_sede and organizacion_id = p_org) then
    raise exception 'La sede no pertenece a esta organización';
  end if;
  if exists (
    select 1
    from public.membresias m
    join auth.users u on u.id = m.usuario_id
    where m.organizacion_id = p_org
      and m.estado_membresia = 'activa' and m.activo
      and lower(u.email) = v_email
  ) then
    raise exception 'Esa persona ya pertenece a la organización';
  end if;

  -- Reenviar = reemplazar: la invitación pendiente anterior a ese correo se cancela.
  update public.invitaciones
     set estado = 'cancelada', resuelta_en = now()
   where organizacion_id = p_org and lower(email) = v_email and estado = 'pendiente';

  insert into public.invitaciones (organizacion_id, email, rol_id, sede_id, token_hash, invitado_por, expira_en)
  values (p_org, v_email, p_rol, p_sede, p_token_hash, auth.uid(), now() + interval '7 days')
  returning id into v_id;

  return v_id;
end $$;

-- Pública (también para quien aún no inicia sesión): solo dice a qué organización
-- corresponde el enlace y a qué correo va dirigido. Quien tiene el token ya es
-- el destinatario; sin el token no se puede consultar nada.
create or replace function public.info_invitacion(p_token text)
returns table (organizacion text, email text, valida boolean, motivo text)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_inv    public.invitaciones%rowtype;
  v_nombre text;
  v_motivo text;
begin
  select * into v_inv from public.invitaciones
   where token_hash = encode(sha256(convert_to(coalesce(p_token, ''), 'UTF8')), 'hex');

  if not found then
    return query select null::text, null::text, false, 'no_existe'::text;
    return;
  end if;

  v_motivo := case
    when v_inv.estado <> 'pendiente' then v_inv.estado
    when v_inv.expira_en <= now() then 'vencida'
    else null
  end;

  select o.nombre into v_nombre from public.organizaciones o where o.id = v_inv.organizacion_id;

  return query select v_nombre,
                      case when v_motivo is null then v_inv.email else null end,
                      v_motivo is null,
                      v_motivo;
end $$;

create or replace function public.aceptar_invitacion(p_token text)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid  uuid := auth.uid();
  v_inv  public.invitaciones%rowtype;
  v_user record;
  v_slug text;
begin
  if v_uid is null then raise exception 'No autenticado'; end if;

  select * into v_inv from public.invitaciones
   where token_hash = encode(sha256(convert_to(coalesce(p_token, ''), 'UTF8')), 'hex')
   for update;
  if not found then raise exception 'La invitación no es válida'; end if;

  if v_inv.estado <> 'pendiente' then
    raise exception 'Esta invitación ya no está disponible (%)', v_inv.estado;
  end if;
  if v_inv.expira_en <= now() then
    raise exception 'La invitación venció. Pide al administrador que te envíe una nueva';
  end if;

  select u.email, u.email_confirmed_at into v_user from auth.users u where u.id = v_uid;
  if v_user.email_confirmed_at is null then
    raise exception 'Confirma tu correo antes de aceptar la invitación';
  end if;
  if lower(v_user.email) <> lower(v_inv.email) then
    raise exception 'Esta invitación fue enviada a otro correo';
  end if;

  if exists (
    select 1 from public.membresias
     where usuario_id = v_uid and organizacion_id = v_inv.organizacion_id
       and estado_membresia = 'activa' and activo
  ) then
    raise exception 'Ya perteneces a esta organización';
  end if;

  insert into public.membresias (usuario_id, organizacion_id, rol_id, estado_membresia, activo, sede_id, fecha_ingreso)
  values (v_uid, v_inv.organizacion_id, v_inv.rol_id, 'activa', true, v_inv.sede_id, now())
  on conflict (usuario_id, organizacion_id) do update
     set rol_id = excluded.rol_id,
         sede_id = excluded.sede_id,
         estado_membresia = 'activa',
         activo = true,
         fecha_ingreso = now();

  update public.invitaciones
     set estado = 'aceptada', aceptada_por = v_uid, resuelta_en = now()
   where id = v_inv.id;

  select o.slug into v_slug from public.organizaciones o where o.id = v_inv.organizacion_id;
  return v_slug;
end $$;

create or replace function public.rechazar_invitacion(p_token text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid  uuid := auth.uid();
  v_inv  public.invitaciones%rowtype;
  v_mail text;
begin
  if v_uid is null then raise exception 'No autenticado'; end if;

  select * into v_inv from public.invitaciones
   where token_hash = encode(sha256(convert_to(coalesce(p_token, ''), 'UTF8')), 'hex')
   for update;
  if not found or v_inv.estado <> 'pendiente' then
    raise exception 'La invitación no es válida';
  end if;

  select u.email into v_mail from auth.users u where u.id = v_uid;
  if lower(v_mail) <> lower(v_inv.email) then
    raise exception 'Esta invitación fue enviada a otro correo';
  end if;

  update public.invitaciones
     set estado = 'rechazada', resuelta_en = now()
   where id = v_inv.id;
end $$;

create or replace function public.cancelar_invitacion(p_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_org uuid;
begin
  select i.organizacion_id into v_org from public.invitaciones i where i.id = p_id;
  if v_org is null or not public.es_admin_org(v_org) then
    raise exception 'Solo un administrador puede cancelar invitaciones';
  end if;

  update public.invitaciones
     set estado = 'cancelada', resuelta_en = now()
   where id = p_id and estado = 'pendiente';
  if not found then raise exception 'La invitación ya no está pendiente'; end if;
end $$;

create or replace function public.listar_invitaciones(p_org uuid)
returns table (
  id uuid, email text, rol_id uuid, rol_nombre text, sede_nombre text,
  estado text, creada_en timestamptz, expira_en timestamptz, invitado_por_nombre text
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede ver las invitaciones';
  end if;

  return query
  select i.id, i.email, i.rol_id, r.nombre, s.nombre,
         case when i.estado = 'pendiente' and i.expira_en <= now() then 'vencida' else i.estado end,
         i.creada_en, i.expira_en,
         nullif(btrim(coalesce(p.nombres, '') || ' ' || coalesce(p.apellidos, '')), '')
  from public.invitaciones i
  join public.roles r on r.id = i.rol_id
  left join public.sedes s on s.id = i.sede_id
  left join public.profiles p on p.id = i.invitado_por
  where i.organizacion_id = p_org
  order by i.creada_en desc
  limit 200;
end $$;

-- -----------------------------------------------------------------------------
-- 6. Solicitudes de ingreso (usuario sin invitación)
-- -----------------------------------------------------------------------------
-- El identificador (NIT/slug) solo UBICA la organización. La solicitud queda
-- 'pendiente' con el rol Predeterminado (viewer, sin permisos): no da acceso a
-- nada hasta que un admin la acepte.
create or replace function public.solicitar_union(p_identificador text)
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid   uuid := auth.uid();
  v_texto text := btrim(coalesce(p_identificador, ''));
  v_ident text := public.normalizar_identificacion(p_identificador);
  v_org   record;
  v_rol   uuid;
  v_m     public.membresias%rowtype;
begin
  if v_uid is null then raise exception 'No autenticado'; end if;
  if not exists (select 1 from public.profiles where id = v_uid and perfil_completo) then
    raise exception 'Completa tu perfil antes de solicitar el ingreso';
  end if;
  if char_length(v_texto) < 3 then
    raise exception 'Escribe la identificación de la organización';
  end if;

  select o.id, o.nombre into v_org
    from public.organizaciones o
   where o.activo and (o.identificacion = v_ident or o.slug = lower(v_texto))
   limit 1;
  if not found then
    raise exception 'No encontramos una organización con ese identificador';
  end if;

  select r.id into v_rol from public.roles r
   where r.organizacion_id = v_org.id and r.nombre = 'viewer';
  if v_rol is null then
    raise exception 'Esta organización no recibe solicitudes por ahora';
  end if;

  select * into v_m from public.membresias
   where usuario_id = v_uid and organizacion_id = v_org.id for update;

  if found then
    if v_m.estado_membresia = 'activa' and v_m.activo then
      raise exception 'Ya perteneces a esta organización';
    elsif v_m.estado_membresia = 'pendiente' then
      raise exception 'Ya enviaste una solicitud a esta organización';
    elsif v_m.estado_membresia = 'suspendida' then
      raise exception 'Tu acceso a esta organización está suspendido. Contacta al administrador';
    end if;
  end if;

  if (select count(*) from public.membresias
       where usuario_id = v_uid and estado_membresia = 'pendiente') >= 3 then
    raise exception 'Tienes demasiadas solicitudes pendientes';
  end if;

  if found then
    update public.membresias
       set estado_membresia = 'pendiente', rol_id = v_rol, sede_id = null,
           activo = true, fecha_ingreso = now()
     where id = v_m.id;
  else
    insert into public.membresias (usuario_id, organizacion_id, rol_id, estado_membresia, activo)
    values (v_uid, v_org.id, v_rol, 'pendiente', true);
  end if;

  return v_org.nombre;
end $$;

-- Solicitudes pendientes del propio usuario (organizaciones no es legible para él
-- hasta que lo acepten, por eso se expone el nombre por aquí).
create or replace function public.mis_solicitudes()
returns table (organizacion text, fecha timestamptz)
language sql
stable
security definer
set search_path = ''
as $$
  select o.nombre, m.fecha_ingreso
  from public.membresias m
  join public.organizaciones o on o.id = m.organizacion_id
  where m.usuario_id = auth.uid() and m.estado_membresia = 'pendiente'
  order by m.fecha_ingreso desc
$$;

-- -----------------------------------------------------------------------------
-- 7. Administración de miembros
-- -----------------------------------------------------------------------------
create or replace function public.listar_miembros(p_org uuid)
returns table (
  membresia_id uuid, usuario_id uuid, nombres text, apellidos text, email text,
  tipo_documento text, numero_documento text, rol_id uuid, rol_nombre text,
  sede_id uuid, sede_nombre text, estado text, activo boolean, fecha_ingreso timestamptz
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede ver los miembros';
  end if;

  return query
  select m.id, m.usuario_id, p.nombres, p.apellidos, u.email::text,
         p.tipo_documento, p.numero_documento, m.rol_id, r.nombre,
         m.sede_id, s.nombre, m.estado_membresia::text, m.activo, m.fecha_ingreso
  from public.membresias m
  join public.roles r on r.id = m.rol_id
  left join public.profiles p on p.id = m.usuario_id
  left join auth.users u on u.id = m.usuario_id
  left join public.sedes s on s.id = m.sede_id
  where m.organizacion_id = p_org
    and m.estado_membresia <> 'retirada'
  order by (m.estado_membresia = 'pendiente') desc, m.fecha_ingreso;
end $$;

create or replace function public.resolver_solicitud(
  p_membresia uuid, p_aceptar boolean, p_rol uuid default null, p_sede uuid default null
) returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_m   public.membresias%rowtype;
  v_rol uuid;
begin
  select * into v_m from public.membresias where id = p_membresia for update;
  if not found or not public.es_admin_org(v_m.organizacion_id) then
    raise exception 'Solo un administrador puede resolver solicitudes';
  end if;
  if v_m.estado_membresia <> 'pendiente' then
    raise exception 'La solicitud ya fue resuelta';
  end if;

  if not p_aceptar then
    update public.membresias
       set estado_membresia = 'retirada', activo = false
     where id = v_m.id;
    return;
  end if;

  -- Sin rol elegido = Predeterminado (viewer)
  v_rol := coalesce(
    p_rol,
    (select r.id from public.roles r where r.organizacion_id = v_m.organizacion_id and r.nombre = 'viewer')
  );
  if v_rol is null
     or not exists (select 1 from public.roles where id = v_rol and organizacion_id = v_m.organizacion_id) then
    raise exception 'El rol no pertenece a esta organización';
  end if;
  if p_sede is not null
     and not exists (select 1 from public.sedes where id = p_sede and organizacion_id = v_m.organizacion_id) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  update public.membresias
     set estado_membresia = 'activa', rol_id = v_rol, sede_id = p_sede, activo = true
   where id = v_m.id;
end $$;

-- Cambia el rol (y opcionalmente la sede) de un miembro ACTIVO. Si p_sede es null,
-- la sede actual no se toca. Reglas:
--   · nadie cambia su propio rol (lo hace otro admin);
--   · nadie puede cambiar el rol del propietario de la organización;
--   · solo el propietario puede quitarle el rol de admin a otro admin (si la organización
--     tiene propietario);
--   · la organización siempre conserva al menos un admin activo.
create or replace function public.cambiar_rol_miembro(
  p_membresia uuid, p_rol uuid, p_sede uuid default null
) returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_m           public.membresias%rowtype;
  v_rol_actual  text;
  v_rol_nuevo   text;
  v_prop        uuid;
begin
  select * into v_m from public.membresias where id = p_membresia for update;
  if not found or not public.es_admin_org(v_m.organizacion_id) then
    raise exception 'Solo un administrador puede cambiar roles';
  end if;
  if v_m.usuario_id = auth.uid() and p_rol <> v_m.rol_id then
    raise exception 'No puedes cambiar tu propio rol; pide a otro administrador';
  end if;

  select o.propietario_id into v_prop from public.organizaciones o where o.id = v_m.organizacion_id;
  if v_prop is not null and v_m.usuario_id = v_prop and p_rol <> v_m.rol_id then
    raise exception 'El rol del propietario de la organización no se puede cambiar';
  end if;

  if v_m.estado_membresia <> 'activa' then
    raise exception 'Solo se puede cambiar el rol de miembros activos';
  end if;

  select r.nombre into v_rol_nuevo from public.roles r
   where r.id = p_rol and r.organizacion_id = v_m.organizacion_id;
  if v_rol_nuevo is null then
    raise exception 'El rol no pertenece a esta organización';
  end if;
  if p_sede is not null
     and not exists (select 1 from public.sedes where id = p_sede and organizacion_id = v_m.organizacion_id) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  select r.nombre into v_rol_actual from public.roles r where r.id = v_m.rol_id;
  if v_rol_actual = 'admin' and v_rol_nuevo <> 'admin' then
    if v_prop is not null and v_prop is distinct from auth.uid() then
      raise exception 'Solo el propietario puede quitar el rol de administrador';
    end if;
    if not exists (
      select 1
      from public.membresias mm
      join public.roles rr on rr.id = mm.rol_id
      where mm.organizacion_id = v_m.organizacion_id
        and mm.id <> v_m.id
        and mm.activo and mm.estado_membresia = 'activa'
        and rr.nombre = 'admin'
    ) then
      raise exception 'La organización debe conservar al menos un administrador';
    end if;
  end if;

  update public.membresias
     set rol_id = p_rol,
         sede_id = coalesce(p_sede, sede_id)
   where id = v_m.id;
end $$;

-- El propietario cede la propiedad a otro admin ACTIVO de la organización. Después de esto,
-- la persona anterior sigue siendo admin pero ya no tiene protección especial.
create or replace function public.transferir_propiedad(p_org uuid, p_nuevo uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_prop uuid;
begin
  select o.propietario_id into v_prop from public.organizaciones o where o.id = p_org for update;
  if v_prop is null or v_prop is distinct from auth.uid() then
    raise exception 'Solo el propietario puede transferir la propiedad';
  end if;
  if p_nuevo = v_prop then
    raise exception 'Ya eres el propietario de la organización';
  end if;
  if not exists (
    select 1
    from public.membresias m
    join public.roles r on r.id = m.rol_id
    where m.usuario_id = p_nuevo and m.organizacion_id = p_org
      and m.activo and m.estado_membresia = 'activa'
      and r.nombre = 'admin' and r.organizacion_id = p_org
  ) then
    raise exception 'La nueva persona propietaria debe ser administradora activa de la organización';
  end if;

  update public.organizaciones set propietario_id = p_nuevo where id = p_org;
end $$;

-- La política existente "solo admin edita la organización" permite a un admin actualizar
-- CUALQUIER columna desde el navegador. Este trigger impide que se cambie propietario_id así:
-- solo cambia por transferir_propiedad (que corre como dueño de la función, no como "authenticated").
create or replace function public.proteger_propietario()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.propietario_id is distinct from old.propietario_id
     and current_user in ('authenticated', 'anon') then
    raise exception 'El propietario solo se cambia con la función transferir_propiedad';
  end if;
  return new;
end $$;

drop trigger if exists organizaciones_proteger_propietario on public.organizaciones;
create trigger organizaciones_proteger_propietario
  before update on public.organizaciones
  for each row execute function public.proteger_propietario();

-- -----------------------------------------------------------------------------
-- 8. Permisos de ejecución
--    (los privilegios por defecto de este proyecto dan EXECUTE a anon; se quita)
-- -----------------------------------------------------------------------------
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname = any (array[
        'normalizar_identificacion', 'es_admin_org', 'crear_organizacion',
        'crear_invitacion', 'info_invitacion', 'aceptar_invitacion',
        'rechazar_invitacion', 'cancelar_invitacion', 'listar_invitaciones',
        'solicitar_union', 'mis_solicitudes', 'listar_miembros',
        'resolver_solicitud', 'cambiar_rol_miembro', 'transferir_propiedad'
      ])
  loop
    execute format('revoke all on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated', f.sig);
  end loop;
end $$;

-- Única excepción: consultar un enlace de invitación antes de iniciar sesión.
grant execute on function public.info_invitacion(text) to anon;

-- -----------------------------------------------------------------------------
-- 9. Política de public.roles: cada usuario ve el rol de su propia membresía;
--    el admin de una organización ve todos los roles de esa organización.
--    (Antes: cualquier usuario autenticado veía los roles de todas las organizaciones.)
-- -----------------------------------------------------------------------------
drop policy if exists "roles visibles para autenticados" on public.roles;
drop policy if exists "roles: el propio o admin de la organización" on public.roles;

create policy "roles: el propio o admin de la organización" on public.roles
  for select
  using (
    exists (
      select 1 from public.membresias m
       where m.usuario_id = auth.uid() and m.rol_id = roles.id
    )
    or public.es_admin_org(roles.organizacion_id)
  );

commit;

-- =============================================================================
-- REVERSA de la política de roles (solo si necesitas volver al estado anterior):
--
--   drop policy "roles: el propio o admin de la organización" on public.roles;
--   create policy "roles visibles para autenticados" on public.roles
--     for select using (auth.role() = 'authenticated');
--
-- Organizaciones que ya existían (p. ej. app-demo) quedan SIN propietario (propietario_id NULL)
-- y se comportan como antes. Para fijarlo, con el UUID de quien debe ser propietario:
--   update public.organizaciones set propietario_id = '<uuid-del-usuario>' where slug = 'app-demo';
--
-- Nota: la organización que ya existe (app-demo) tiene identificacion = NULL.
-- Para que se pueda encontrar por NIT/identificación:
--   update public.organizaciones set identificacion = '<NIT>' where slug = 'app-demo';
-- =============================================================================
