-- Fase 2 · PROVEEDORES — parte 1 de 3: columnas, documento único por organización, IVA de compra
-- Ejecutar DESPUÉS de las partes 01-07 de Ítems, UNA por vez. Idempotente: si falla por bloqueo, repite solo esta.
--
-- Idea (igual que con ítems): proveedores.id sigue siendo la clave INTERNA (no se tocan las llaves foráneas).
-- Lo visible pasa a ser (tipo_documento, numero_documento), único POR ORGANIZACIÓN.
-- El IVA de COMPRA vive aquí, separado del IVA de VENTA del ítem (items.iva).

set lock_timeout = '5s';

alter table public.proveedores add column if not exists tipo_documento   text not null default 'NIT';
alter table public.proveedores add column if not exists numero_documento text;
alter table public.proveedores add column if not exists cobra_iva        boolean not null default true;
alter table public.proveedores add column if not exists iva_compra       numeric(5,4) not null default 0.19;

comment on column public.proveedores.id is 'Clave INTERNA. Lo visible es (tipo_documento, numero_documento).';
comment on column public.proveedores.tipo_documento is 'NIT, CC, CE, PAS u OTRO.';
comment on column public.proveedores.numero_documento is 'Sin puntos, guiones ni dígito de verificación. Único por organización y tipo.';
comment on column public.proveedores.cobra_iva is 'Si el proveedor factura IVA (según su régimen tributario).';
comment on column public.proveedores.iva_compra is 'Tarifa de IVA de COMPRA, fracción 0..1 (predeterminado 0.19). Solo aplica si cobra_iva.';

-- Las claves internas nuevas arrancan en 10^12 para no cruzarse con los id actuales (que eran el NIT).
do $$ begin
  if exists (select 1 from public.proveedores where id >= 1000000000000) then
    raise exception 'Hay proveedores con id >= 10^12: ajusta el inicio de proveedores_id_seq antes de continuar';
  end if;
end $$;

create sequence if not exists public.proveedores_id_seq
  start with 1000000000000 minvalue 1000000000000 increment by 1 no maxvalue cache 1;
revoke all on sequence public.proveedores_id_seq from public, anon, authenticated;
grant usage, select on sequence public.proveedores_id_seq to service_role;
alter table public.proveedores alter column id set default nextval('public.proveedores_id_seq');

-- Relleno: los proveedores actuales quedan como NIT con el número que ya tenían como id.
update public.proveedores set numero_documento = id::text where numero_documento is null;
alter table public.proveedores alter column numero_documento set not null;

do $$ begin
  alter table public.proveedores add constraint proveedores_tipo_documento_chk
    check (tipo_documento in ('NIT', 'CC', 'CE', 'PAS', 'OTRO'));
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.proveedores add constraint proveedores_iva_compra_chk
    check (iva_compra >= 0 and iva_compra <= 1);
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.proveedores add constraint proveedores_numero_documento_chk
    check (btrim(numero_documento) <> '');
exception when duplicate_object then null; end $$;

create unique index if not exists proveedores_org_documento_uk
  on public.proveedores (organizacion_id, tipo_documento, lower(btrim(numero_documento)));

-- Historial de cambios (usa la misma función de auditoría que los ítems)
create index if not exists auditoria_registro_idx on public.auditoria (organizacion_id, tabla, registro, fecha desc);
drop trigger if exists trg_auditar_proveedores on public.proveedores;
create trigger trg_auditar_proveedores after insert or update or delete on public.proveedores
  for each row execute function public.auditar_cambio();
