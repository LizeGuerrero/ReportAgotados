-- Fase 3 · IMPORTACIÓN — parte 2 de 2: funciones del motor de carga (tipo disponible: proveedores)
-- Requiere 01-11. Idempotente. Ejecutar UNA por vez.
--
-- Permisos: importaciones.ver / importaciones.crear  Y  además el permiso del destino
-- (proveedores → Proveedores crear + editar). Cada persona solo puede cargar/validar/aplicar sus propias cargas.
-- Regla de celdas: una celda VACÍA nunca borra el dato que ya existe.

set lock_timeout = '5s';

create or replace function public._imp_exigir(p_org uuid, p_tipo text, p_accion text)
returns void
language plpgsql stable security definer
set search_path to ''
as $$
begin
  perform public._exigir_permiso(p_org, 'importaciones', p_accion);
  if p_accion = 'crear' then
    if p_tipo in ('proveedores', 'item_proveedor') then
      perform public._exigir_permiso(p_org, 'Proveedores', 'crear');
      perform public._exigir_permiso(p_org, 'Proveedores', 'editar');
    elsif p_tipo = 'items' then
      perform public._exigir_permiso(p_org, 'Items', 'crear');
      perform public._exigir_permiso(p_org, 'Items', 'editar');
    else
      raise exception 'Tipo de carga no válido';
    end if;
  end if;
end $$;

create or replace function public._imp_dueno(p_org uuid, p_id uuid)
returns public.importaciones
language plpgsql stable security definer
set search_path to ''
as $$
declare v public.importaciones;
begin
  select * into v from public.importaciones i where i.id = p_id and i.organizacion_id = p_org;
  if not found then raise exception 'Carga no encontrada'; end if;
  return v;
end $$;

create or replace function public.importacion_iniciar(p_org uuid, p_tipo text, p_archivo text)
returns uuid
language plpgsql security definer
set search_path to ''
as $$
declare v_id uuid;
begin
  perform public._imp_exigir(p_org, p_tipo, 'crear');
  if p_tipo <> 'proveedores' then raise exception 'Este tipo de carga aún no está disponible'; end if;
  insert into public.importaciones (organizacion_id, tipo, archivo, creado_por)
  values (p_org, p_tipo, left(nullif(btrim(p_archivo), ''), 200), auth.uid())
  returning id into v_id;
  return v_id;
end $$;

-- p_filas = [{"fila": 2, "datos": {"numero_documento": "900123", ...}}, ...]  (máx. 1000 por envío, 20000 por carga)
create or replace function public.importacion_cargar(p_org uuid, p_id uuid, p_filas jsonb)
returns integer
language plpgsql security definer
set search_path to ''
as $$
declare v public.importaciones; v_n integer; v_actual integer;
begin
  v := public._imp_dueno(p_org, p_id);
  perform public._imp_exigir(p_org, v.tipo, 'crear');
  if v.creado_por is distinct from auth.uid() then raise exception 'Esta carga pertenece a otro usuario'; end if;
  if v.estado <> 'cargando' then raise exception 'La carga ya no admite más filas'; end if;
  if p_filas is null or jsonb_typeof(p_filas) <> 'array' then raise exception 'Formato de filas no válido'; end if;
  v_n := jsonb_array_length(p_filas);
  if v_n = 0 or v_n > 1000 then raise exception 'Cada envío admite de 1 a 1000 filas'; end if;
  select count(*) into v_actual from public.importacion_filas f where f.importacion_id = p_id;
  if v_actual + v_n > 20000 then raise exception 'El máximo por carga es 20000 filas'; end if;

  insert into public.importacion_filas (importacion_id, fila, datos)
  select p_id, (e->>'fila')::integer, e->'datos'
  from jsonb_array_elements(p_filas) e
  where jsonb_typeof(e->'datos') = 'object';
  get diagnostics v_n = row_count;
  return v_n;
end $$;

-- Validación de proveedores: normaliza cada fila y la clasifica (nueva / actualizar / sin_cambios / error)
create or replace function public._imp_validar_proveedores(p_org uuid, p_id uuid)
returns void
language plpgsql security definer
set search_path to ''
as $$
declare
  r record; ex public.proveedores%rowtype;
  t text; n text; v_nombre text; v_contacto text; v_tel text; v_email text; v_notas text;
  v_cobra boolean; v_iva numeric; v_raw text; v_errs text[]; v_cambios jsonb; v_estado text; v_destino bigint;
  v_vistos jsonb := '{}'::jsonb; v_clave text;
begin
  for r in
    select f.id, f.fila, f.datos from public.importacion_filas f where f.importacion_id = p_id order by f.fila
  loop
    v_errs := array[]::text[]; v_cambios := '{}'::jsonb; v_estado := 'error'; v_destino := null;
    t := null; n := null; v_cobra := null; v_iva := null;

    -- documento
    if nullif(btrim(r.datos->>'numero_documento'), '') is null then
      v_errs := array_append(v_errs, 'Falta el número de documento');
    else
      begin
        select d.tipo, d.numero into t, n
          from public._proveedor_documento(r.datos->>'tipo_documento', r.datos->>'numero_documento') d;
      exception when others then
        v_errs := array_append(v_errs, sqlerrm);
        t := null; n := null;
      end;
    end if;

    -- textos
    v_nombre   := nullif(btrim(r.datos->>'nombre'), '');
    v_contacto := nullif(btrim(r.datos->>'contacto'), '');
    v_tel      := nullif(btrim(r.datos->>'telefono'), '');
    v_email    := nullif(btrim(r.datos->>'email'), '');
    v_notas    := nullif(btrim(r.datos->>'notas'), '');
    if v_nombre is not null and char_length(v_nombre) > 200 then
      v_errs := array_append(v_errs, 'El nombre supera 200 caracteres');
    end if;
    if v_email is not null and v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
      v_errs := array_append(v_errs, 'Correo no válido');
    end if;

    -- cobra IVA (Sí / No)
    v_raw := lower(btrim(coalesce(r.datos->>'cobra_iva', '')));
    if v_raw <> '' then
      if v_raw in ('si', 'sí', 's', '1', 'true', 'verdadero', 'yes', 'y', 'x') then v_cobra := true;
      elsif v_raw in ('no', 'n', '0', 'false', 'falso') then v_cobra := false;
      else v_errs := array_append(v_errs, 'Cobra IVA debe ser Sí o No');
      end if;
    end if;

    -- IVA de compra: 19, 19%, 0.19 o 0,19
    v_raw := btrim(coalesce(r.datos->>'iva_compra', ''));
    if v_raw <> '' then
      begin
        v_iva := replace(replace(v_raw, '%', ''), ',', '.')::numeric;
        if position('%' in v_raw) > 0 or v_iva > 1 then v_iva := v_iva / 100; end if;
        if v_iva < 0 or v_iva > 1 then
          v_errs := array_append(v_errs, 'IVA fuera de rango (0 a 100 %)');
          v_iva := null;
        else
          v_iva := round(v_iva, 4);
        end if;
      exception when others then
        v_errs := array_append(v_errs, 'IVA no válido: escribe un porcentaje como 19 o 19%');
        v_iva := null;
      end;
    end if;

    -- repetido dentro del mismo archivo
    if t is not null then
      v_clave := t || '|' || lower(n);
      if v_vistos ? v_clave then
        v_errs := array_append(v_errs, 'Documento repetido en el archivo (ya aparece en la fila ' || (v_vistos->>v_clave) || ')');
      else
        v_vistos := v_vistos || jsonb_build_object(v_clave, r.fila);
      end if;
    end if;

    -- contra lo que ya existe en la organización
    if cardinality(v_errs) = 0 then
      select * into ex from public.proveedores p
       where p.organizacion_id = p_org and p.tipo_documento = t and lower(btrim(p.numero_documento)) = lower(n);
      if found then
        v_destino := ex.id;
        if v_nombre   is not null and v_nombre   is distinct from ex.nombre   then v_cambios := v_cambios || jsonb_build_object('nombre', v_nombre); end if;
        if v_contacto is not null and v_contacto is distinct from ex.contacto then v_cambios := v_cambios || jsonb_build_object('contacto', v_contacto); end if;
        if v_tel      is not null and v_tel      is distinct from ex.telefono then v_cambios := v_cambios || jsonb_build_object('telefono', v_tel); end if;
        if v_email    is not null and v_email    is distinct from ex.email    then v_cambios := v_cambios || jsonb_build_object('email', v_email); end if;
        if v_notas    is not null and v_notas    is distinct from ex.notas    then v_cambios := v_cambios || jsonb_build_object('notas', v_notas); end if;
        if v_cobra    is not null and v_cobra    is distinct from ex.cobra_iva then v_cambios := v_cambios || jsonb_build_object('cobra_iva', v_cobra); end if;
        if v_iva      is not null and v_iva      is distinct from ex.iva_compra then v_cambios := v_cambios || jsonb_build_object('iva_compra', v_iva); end if;
        v_estado := case when v_cambios = '{}'::jsonb then 'sin_cambios' else 'actualizar' end;
        v_cambios := v_cambios || jsonb_build_object('tipo_documento', t, 'numero_documento', n);
      elsif v_nombre is null then
        v_errs := array_append(v_errs, 'Falta el nombre (el proveedor es nuevo)');
      else
        v_estado := 'nueva';
        v_cambios := jsonb_build_object(
          'tipo_documento', t, 'numero_documento', n, 'nombre', v_nombre, 'contacto', v_contacto,
          'telefono', v_tel, 'email', v_email, 'notas', v_notas,
          'cobra_iva', coalesce(v_cobra, true), 'iva_compra', coalesce(v_iva, 0.19));
      end if;
    end if;

    if cardinality(v_errs) > 0 then v_estado := 'error'; end if;
    update public.importacion_filas
       set estado = v_estado, errores = v_errs, cambios = v_cambios, destino_id = v_destino
     where id = r.id;
  end loop;
end $$;

create or replace function public.importacion_validar(p_org uuid, p_id uuid)
returns jsonb
language plpgsql security definer
set search_path to ''
as $$
declare v public.importaciones; v_res jsonb;
begin
  v := public._imp_dueno(p_org, p_id);
  perform public._imp_exigir(p_org, v.tipo, 'crear');
  if v.creado_por is distinct from auth.uid() then raise exception 'Esta carga pertenece a otro usuario'; end if;
  if v.estado not in ('cargando', 'validada') then raise exception 'Esta carga ya está %', v.estado; end if;
  if not exists (select 1 from public.importacion_filas f where f.importacion_id = p_id) then
    raise exception 'La carga no tiene filas';
  end if;

  update public.importacion_filas
     set estado = 'pendiente', errores = '{}', cambios = '{}'::jsonb, destino_id = null
   where importacion_id = p_id;

  if v.tipo = 'proveedores' then
    perform public._imp_validar_proveedores(p_org, p_id);
  else
    raise exception 'Este tipo de carga aún no está disponible';
  end if;

  select jsonb_build_object(
           'total', count(*),
           'nuevas', count(*) filter (where f.estado = 'nueva'),
           'actualizar', count(*) filter (where f.estado = 'actualizar'),
           'sin_cambios', count(*) filter (where f.estado = 'sin_cambios'),
           'errores', count(*) filter (where f.estado = 'error'))
    into v_res
  from public.importacion_filas f where f.importacion_id = p_id;

  update public.importaciones set estado = 'validada', validada_en = now(), resumen = v_res where id = p_id;
  return v_res;
end $$;

-- Aplica SOLO las filas válidas (nueva / actualizar). Las filas con error no se cargan.
create or replace function public.importacion_aplicar(p_org uuid, p_id uuid)
returns jsonb
language plpgsql security definer
set search_path to ''
as $$
declare
  v public.importaciones; r record; v_estado text;
  v_nuevas integer := 0; v_act integer := 0; v_fall integer := 0; v_res jsonb;
begin
  v := public._imp_dueno(p_org, p_id);
  perform public._imp_exigir(p_org, v.tipo, 'crear');
  if v.creado_por is distinct from auth.uid() then raise exception 'Esta carga pertenece a otro usuario'; end if;

  -- bloquea la carga: dos clics seguidos no pueden aplicarla dos veces
  select i.estado into v_estado from public.importaciones i where i.id = p_id for update;
  if v_estado <> 'validada' then
    raise exception 'Solo se puede aplicar una carga validada (estado actual: %)', v_estado;
  end if;

  if v.tipo <> 'proveedores' then raise exception 'Este tipo de carga aún no está disponible'; end if;

  for r in
    select f.id, f.estado, f.cambios, f.destino_id
      from public.importacion_filas f
     where f.importacion_id = p_id and f.estado in ('nueva', 'actualizar')
     order by f.fila
  loop
    begin
      if r.estado = 'nueva' then
        insert into public.proveedores
          (organizacion_id, tipo_documento, numero_documento, nombre, contacto, telefono, email, notas, cobra_iva, iva_compra)
        values (p_org, r.cambios->>'tipo_documento', r.cambios->>'numero_documento', r.cambios->>'nombre',
                r.cambios->>'contacto', r.cambios->>'telefono', r.cambios->>'email', r.cambios->>'notas',
                coalesce((r.cambios->>'cobra_iva')::boolean, true), coalesce((r.cambios->>'iva_compra')::numeric, 0.19));
      else
        update public.proveedores pv set
          nombre     = case when r.cambios ? 'nombre'     then r.cambios->>'nombre'     else pv.nombre end,
          contacto   = case when r.cambios ? 'contacto'   then r.cambios->>'contacto'   else pv.contacto end,
          telefono   = case when r.cambios ? 'telefono'   then r.cambios->>'telefono'   else pv.telefono end,
          email      = case when r.cambios ? 'email'      then r.cambios->>'email'      else pv.email end,
          notas      = case when r.cambios ? 'notas'      then r.cambios->>'notas'      else pv.notas end,
          cobra_iva  = case when r.cambios ? 'cobra_iva'  then (r.cambios->>'cobra_iva')::boolean else pv.cobra_iva end,
          iva_compra = case when r.cambios ? 'iva_compra' then (r.cambios->>'iva_compra')::numeric else pv.iva_compra end
        where pv.id = r.destino_id and pv.organizacion_id = p_org;
        if not found then raise exception 'El proveedor ya no existe'; end if;
      end if;
      update public.importacion_filas set estado = 'aplicada' where id = r.id;
      if r.estado = 'nueva' then v_nuevas := v_nuevas + 1; else v_act := v_act + 1; end if;
    exception
      when unique_violation then
        v_fall := v_fall + 1;
        update public.importacion_filas set estado = 'error',
          errores = array['El documento ya existe (se registró después de validar)'] where id = r.id;
      when others then
        v_fall := v_fall + 1;
        update public.importacion_filas set estado = 'error', errores = array[sqlerrm] where id = r.id;
    end;
  end loop;

  v_res := v.resumen || jsonb_build_object('nuevas_aplicadas', v_nuevas, 'actualizadas_aplicadas', v_act, 'fallidas', v_fall);
  update public.importaciones set estado = 'aplicada', aplicada_en = now(), resumen = v_res where id = p_id;
  return v_res;
end $$;

create or replace function public.importacion_descartar(p_org uuid, p_id uuid)
returns void
language plpgsql security definer
set search_path to ''
as $$
declare v public.importaciones;
begin
  v := public._imp_dueno(p_org, p_id);
  perform public._imp_exigir(p_org, v.tipo, 'crear');
  if v.creado_por is distinct from auth.uid() then raise exception 'Esta carga pertenece a otro usuario'; end if;
  if v.estado not in ('cargando', 'validada') then raise exception 'Esta carga ya está % y no se puede descartar', v.estado; end if;
  delete from public.importacion_filas where importacion_id = p_id;
  update public.importaciones set estado = 'descartada' where id = p_id;
end $$;

create or replace function public.importacion_filas_listar(
  p_org uuid, p_id uuid, p_estado text default null, p_limit integer default 50, p_offset integer default 0)
returns table(fila integer, estado text, errores text[], datos jsonb, cambios jsonb, total bigint)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
declare v public.importaciones;
begin
  v := public._imp_dueno(p_org, p_id);
  perform public._exigir_permiso(p_org, 'importaciones', 'ver');
  return query
  select f.fila, f.estado, f.errores, f.datos, f.cambios, count(*) over()
  from public.importacion_filas f
  where f.importacion_id = p_id and (p_estado is null or f.estado = p_estado)
  order by f.fila
  limit least(greatest(p_limit, 1), 500) offset greatest(p_offset, 0);
end $$;

create or replace function public.importacion_obtener(p_org uuid, p_id uuid)
returns jsonb
language plpgsql stable security definer
set search_path to ''
as $$
declare v public.importaciones;
begin
  v := public._imp_dueno(p_org, p_id);
  perform public._exigir_permiso(p_org, 'importaciones', 'ver');
  return jsonb_build_object('id', v.id, 'tipo', v.tipo, 'archivo', v.archivo, 'estado', v.estado,
                            'creada_en', v.creada_en, 'resumen', v.resumen,
                            'propia', v.creado_por is not distinct from auth.uid());
end $$;

create or replace function public.importacion_listar(p_org uuid, p_limit integer default 30)
returns table(id uuid, tipo text, archivo text, estado text, creada_en timestamptz, aplicada_en timestamptz,
              usuario text, resumen jsonb)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
begin
  perform public._exigir_permiso(p_org, 'importaciones', 'ver');
  return query
  select i.id, i.tipo, i.archivo, i.estado, i.creada_en, i.aplicada_en,
         nullif(btrim(coalesce(p.nombres, '') || ' ' || coalesce(p.apellidos, '')), ''), i.resumen
  from public.importaciones i
  left join public.profiles p on p.id = i.creado_por
  where i.organizacion_id = p_org and i.estado <> 'descartada'
  order by i.creada_en desc
  limit least(greatest(p_limit, 1), 100);
end $$;

-- Permisos de ejecución
revoke all on function public._imp_exigir(uuid, text, text) from public, anon, authenticated;
revoke all on function public._imp_dueno(uuid, uuid) from public, anon, authenticated;
revoke all on function public._imp_validar_proveedores(uuid, uuid) from public, anon, authenticated;
grant execute on function public._imp_exigir(uuid, text, text) to service_role;
grant execute on function public._imp_dueno(uuid, uuid) to service_role;
grant execute on function public._imp_validar_proveedores(uuid, uuid) to service_role;

do $$
declare f text;
begin
  foreach f in array array[
    'public.importacion_iniciar(uuid, text, text)',
    'public.importacion_cargar(uuid, uuid, jsonb)',
    'public.importacion_validar(uuid, uuid)',
    'public.importacion_aplicar(uuid, uuid)',
    'public.importacion_descartar(uuid, uuid)',
    'public.importacion_filas_listar(uuid, uuid, text, integer, integer)',
    'public.importacion_obtener(uuid, uuid)',
    'public.importacion_listar(uuid, integer)'
  ] loop
    execute format('revoke all on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated, service_role', f);
  end loop;
end $$;
