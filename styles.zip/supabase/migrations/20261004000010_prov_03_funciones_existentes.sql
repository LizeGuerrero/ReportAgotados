-- Fase 2 · PROVEEDORES — parte 3 de 3: funciones EXISTENTES de Pedidos adaptadas al nuevo modelo de proveedor
-- Qué cambia: (a) el proveedor se identifica por su id interno o por (tipo, número de documento) y no por el NIT-como-id;
-- (b) el IVA de las cotizaciones es el de COMPRA (proveedor), no el de venta del ítem; (c) se devuelve `documento` para mostrarlo.
-- La lógica de negocio restante no se toca. Requiere 01-09. UNA por vez. Idempotente.

set lock_timeout = '5s';

drop function if exists public.cotizacion_agregar_proveedor(uuid, bigint, bigint, text, text, integer, numeric);
drop function if exists public.cotizacion_guardar(uuid, uuid, boolean, numeric, integer, numeric, text, integer);
drop function if exists public.listar_proveedores_pedidos(uuid);
drop function if exists public.listar_ordenes_por_generar(uuid);
drop function if exists public.listar_ordenes_compra(uuid, bigint, integer, integer);

CREATE OR REPLACE FUNCTION "public"."cotizacion_agregar_proveedor"("p_org" "uuid", "p_item" bigint, "p_proveedor" bigint DEFAULT NULL::bigint, "p_tipo_documento" "text" DEFAULT 'NIT'::"text", "p_documento" "text" DEFAULT NULL::"text", "p_nombre" "text" DEFAULT NULL::"text", "p_referencia" "text" DEFAULT NULL::"text", "p_unidades_por_caja" integer DEFAULT NULL::integer, "p_cantidad" numeric DEFAULT NULL::numeric) RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
declare
  v_prov bigint; v_sc uuid; v_si uuid; v_cp uuid; v_cant numeric; v_pend integer;
  v_num integer; v_origen text;
begin
  perform public._pedidos_check(p_org, 'crear');
  if p_proveedor is null and nullif(btrim(p_documento), '') is null then
    raise exception 'Elige un proveedor o escribe su documento';
  end if;
  if p_unidades_por_caja is not null and p_unidades_por_caja <= 0 then raise exception 'Unidades por caja no válidas'; end if;
  if p_cantidad is not null and p_cantidad <= 0 then raise exception 'Cantidad no válida'; end if;
  if not exists (select 1 from public.items where id_item = p_item and organizacion_id = p_org) then
    raise exception 'Ítem no encontrado';
  end if;

  select sum(a.cantidad_sugerida), count(*) into v_cant, v_pend
  from public.agotados a
  where a.organizacion_id = p_org and a.item_id = p_item
    and a.estado_comercial is not null and a.respuesta_compras is null;

  if v_pend > 0 then
    v_origen := 'agotado';
    v_cant := coalesce(p_cantidad, v_cant);
  else
    v_origen := 'manual';
    -- sin agotado: el ítem debe estar ya en gestión; la cantidad sale de lo digitado o de la solicitud activa
    select si.cantidad_a_cotizar into v_cant
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
    where sc.organizacion_id = p_org and si.item_id = p_item and si.estado = 'activo'
    order by (si.cantidad_a_cotizar is not null) desc, sc.fecha_creacion desc
    limit 1;
    if not found then
      raise exception 'Este ítem no está en gestión: inícialo desde "Por proveedor"';
    end if;
    v_cant := coalesce(p_cantidad, v_cant);
    if v_cant is null then raise exception 'Define la cantidad a cotizar'; end if;
  end if;

  -- Proveedor: uno ya existente de esta organización, o se busca/crea por documento (misma lógica que el módulo Proveedores)
  if p_proveedor is not null then
    select pv.id into v_prov from public.proveedores pv where pv.id = p_proveedor and pv.organizacion_id = p_org;
    if v_prov is null then raise exception 'Proveedor no válido'; end if;
  else
    v_prov := public._proveedor_resolver_o_crear(p_org, p_tipo_documento, p_documento, p_nombre);
  end if;

  if not exists (select 1 from public.item_proveedor where item_id = p_item and proveedor_id = v_prov) then
    insert into public.item_proveedor (item_id, proveedor_id, codigo_proveedor, unidades_por_caja)
    values (p_item, v_prov, nullif(trim(p_referencia), ''), p_unidades_por_caja);
  else
    -- completa lo que falte; no repite una referencia que este proveedor ya tiene para el ítem
    update public.item_proveedor ip set
      codigo_proveedor = case
        when coalesce(ip.codigo_proveedor, '') = '' and nullif(trim(p_referencia), '') is not null
             and not exists (select 1 from public.item_proveedor o
                              where o.item_id = ip.item_id and o.proveedor_id = ip.proveedor_id
                                and lower(btrim(o.codigo_proveedor)) = lower(trim(p_referencia)))
        then nullif(trim(p_referencia), '') else ip.codigo_proveedor end,
      unidades_por_caja = coalesce(ip.unidades_por_caja, p_unidades_por_caja)
    where ip.item_id = p_item and ip.proveedor_id = v_prov;
  end if;

  -- ¿ya está en una solicitud abierta con este proveedor?
  select si.id into v_si
  from public.solicitud_items si
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
  where sc.organizacion_id = p_org and sc.proveedor_id = v_prov and sc.estado <> 'cerrada'
    and si.item_id = p_item and si.estado = 'activo'
  limit 1;
  if v_si is not null then
    select cp.id into v_cp from public.cotizacion_precios cp
    where cp.solicitud_item_id = v_si and cp.proveedor_id = v_prov;
    return v_cp;
  end if;

  select sc.id into v_sc from public.solicitudes_cotizacion sc
  where sc.organizacion_id = p_org and sc.proveedor_id = v_prov and sc.estado <> 'cerrada'
  order by sc.fecha_creacion desc limit 1;

  if v_sc is null then
    v_num := public._siguiente_consecutivo(p_org, 'solicitud');
    insert into public.solicitudes_cotizacion (organizacion_id, proveedor_id, numero, estado, creado_por, fecha_envio)
    values (p_org, v_prov, v_num, 'enviada', auth.uid(), now())
    returning id into v_sc;
  end if;

  insert into public.solicitud_items (solicitud_id, item_id, cantidad_a_cotizar, origen)
  values (v_sc, p_item, v_cant, v_origen) returning id into v_si;

  insert into public.cotizacion_precios (solicitud_item_id, proveedor_id)
  values (v_si, v_prov) returning id into v_cp;

  return v_cp;
end $$;

CREATE OR REPLACE FUNCTION "public"."cotizacion_guardar"("p_org" "uuid", "p_cotizacion" "uuid", "p_disponible" boolean, "p_costo" numeric DEFAULT NULL::numeric, "p_dias" integer DEFAULT NULL::integer, "p_flete" numeric DEFAULT NULL::numeric, "p_observacion" "text" DEFAULT NULL::"text", "p_unidades_por_caja" integer DEFAULT NULL::integer, "p_iva" numeric DEFAULT NULL::numeric) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
declare
  v_cp public.cotizacion_precios; v_si public.solicitud_items; v_sc public.solicitudes_cotizacion;
  v_iva numeric; v_upc integer; v_quedan integer;
begin
  perform public._pedidos_check(p_org, 'editar');

  select * into v_cp from public.cotizacion_precios where id = p_cotizacion;
  if v_cp.id is null then raise exception 'Cotización no encontrada'; end if;
  select * into v_si from public.solicitud_items where id = v_cp.solicitud_item_id;
  select * into v_sc from public.solicitudes_cotizacion where id = v_si.solicitud_id;
  if v_sc.organizacion_id <> p_org then raise exception 'Cotización no encontrada'; end if;
  if v_si.estado <> 'activo' then raise exception 'Esta cotización ya está cerrada'; end if;

  if p_disponible is null then raise exception 'Indica si el proveedor tiene disponibilidad'; end if;
  if p_disponible and (p_costo is null or p_costo <= 0) then raise exception 'Digita el costo unitario'; end if;
  if p_costo is not null and p_costo < 0 then raise exception 'Costo no válido'; end if;
  if p_flete is not null and p_flete < 0 then raise exception 'Flete no válido'; end if;
  if p_unidades_por_caja is not null and p_unidades_por_caja <= 0 then raise exception 'Unidades por caja no válidas'; end if;

  -- IVA de COMPRA (no el de venta del ítem): el digitado; si no, el ya guardado en esta cotización; si no, el del proveedor
  if p_iva is not null and (p_iva < 0 or p_iva > 1) then
    raise exception 'IVA no válido: usa una fracción entre 0 y 1 (por ejemplo 0.19)';
  end if;
  select case when pv.cobra_iva then pv.iva_compra else 0 end into v_iva
  from public.proveedores pv where pv.id = v_cp.proveedor_id;
  v_iva := coalesce(p_iva, v_cp.iva, v_iva, 0);

  v_upc := coalesce(p_unidades_por_caja, v_cp.unidades_por_caja);
  if v_upc is null then
    select ip.unidades_por_caja into v_upc
    from public.item_proveedor ip
    where ip.item_id = v_si.item_id and ip.proveedor_id = v_cp.proveedor_id
      and ip.unidades_por_caja is not null
    limit 1;
  end if;

  update public.cotizacion_precios set
    costo_unitario = p_costo,
    iva = v_iva,
    disponible = p_disponible,
    dias_entrega = p_dias,
    flete = case when p_disponible and p_flete > 0 then p_flete end,
    observacion = nullif(trim(p_observacion), ''),
    unidades_por_caja = v_upc,
    fecha_respuesta = now(),
    respondido_por = auth.uid(),
    seleccionado = case when p_disponible then seleccionado else false end,
    cantidad_pedir = case when p_disponible then cantidad_pedir else null end
  where id = v_cp.id;

  if p_unidades_por_caja is not null then
    update public.item_proveedor set unidades_por_caja = p_unidades_por_caja
    where item_id = v_si.item_id and proveedor_id = v_cp.proveedor_id;
  end if;

  update public.solicitudes_cotizacion
     set estado = 'enviada', fecha_envio = coalesce(fecha_envio, now())
   where id = v_sc.id and estado = 'borrador';

  -- Si todos los consultados respondieron "No disponible" -> agotado en proveedor
  select count(*) into v_quedan
  from public.solicitud_items si
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
  join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
  where sc.organizacion_id = p_org and si.item_id = v_si.item_id and si.estado = 'activo'
    and (cp.fecha_respuesta is null or cp.disponible is distinct from false);

  if v_quedan = 0 then
    update public.agotados set
      respuesta_compras = 'agotado_proveedor', fecha_respuesta = now(), respondido_por = auth.uid()
    where organizacion_id = p_org and item_id = v_si.item_id
      and estado_comercial is not null and respuesta_compras is null;
    perform public._pedidos_cerrar_item(p_org, v_si.item_id);
  end if;
end $$;

CREATE OR REPLACE FUNCTION "public"."obtener_cotizaciones_item"("p_org" "uuid", "p_item" bigint, "p_historial" boolean DEFAULT false) RETURNS TABLE("cotizacion_id" "uuid", "solicitud_id" "uuid", "solicitud_numero" "text", "solicitud_estado" "text", "proveedor_id" bigint, "proveedor" "text", "referencia" "text", "cantidad_a_cotizar" numeric, "costo_unitario" numeric, "iva" numeric, "costo_con_iva" numeric, "disponible" boolean, "dias_entrega" integer, "flete" numeric, "paga_flete" boolean, "observacion" "text", "unidades_por_caja" integer, "precio_erp" numeric, "fecha_solicitud" timestamp with time zone, "fecha_respuesta" timestamp with time zone, "respondio" "text", "seleccionado" boolean, "cantidad_pedir" numeric, "activa" boolean)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
begin
  perform public._pedidos_check(p_org, 'ver');
  return query
  select cp.id, sc.id, 'SC-' || lpad(coalesce(sc.numero, 0)::text, 4, '0'), sc.estado,
         cp.proveedor_id, pv.nombre, ip.refs, si.cantidad_a_cotizar,
         cp.costo_unitario, coalesce(cp.iva, case when pv.cobra_iva then pv.iva_compra else 0 end), cp.costo_con_iva, cp.disponible,
         cp.dias_entrega, cp.flete, cp.paga_flete, cp.observacion,
         coalesce(cp.unidades_por_caja, ip.upc), ip.precio, sc.fecha_creacion,
         cp.fecha_respuesta,
         nullif(trim(coalesce(pr.nombres, '') || ' ' || coalesce(pr.apellidos, '')), ''),
         cp.seleccionado, cp.cantidad_pedir, (si.estado = 'activo')
  from public.solicitud_items si
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
  join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
  join public.proveedores pv on pv.id = cp.proveedor_id
  join public.items i on i.id_item = si.item_id
  left join public.profiles pr on pr.id = cp.respondido_por
  left join lateral (
    select string_agg(distinct x.codigo_proveedor, ' / ')
             filter (where coalesce(x.codigo_proveedor, '') <> '') as refs,
           max(x.unidades_por_caja) as upc,
           max(x.precio_unitario) as precio
    from public.item_proveedor x
    where x.item_id = si.item_id and x.proveedor_id = cp.proveedor_id
  ) ip on true
  where si.item_id = p_item
    and (p_historial or si.estado = 'activo')
  order by (si.estado = 'activo') desc, cp.costo_con_iva nulls last, pv.nombre, sc.fecha_creacion desc;
end $$;

CREATE OR REPLACE FUNCTION "public"."matriz_cotizaciones"("p_org" "uuid", "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "linea" "text", "unidad_medida" "text", "iva" numeric, "provisional" boolean, "origen" "text", "cantidad_a_cotizar" numeric, "agotado_sedes" "text"[], "cotizaciones" "jsonb", "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._pedidos_check(p_org, 'ver');

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, i.unidad_medida, i.iva, i.provisional,
         g.origen, g.cant, ag.sedes, g.cots, count(*) over()
  from public.items i
  join lateral (
    select (array_agg(si.origen order by sc.fecha_creacion))[1] as origen,
           max(si.cantidad_a_cotizar) as cant,
           jsonb_agg(jsonb_build_object(
             'cotizacion_id', cp.id, 'proveedor_id', cp.proveedor_id, 'proveedor', pv.nombre, 'documento', pv.tipo_documento || ' ' || pv.numero_documento,
             'solicitud_numero', 'SC-' || lpad(coalesce(sc.numero, 0)::text, 4, '0'),
             'solicitud_estado', sc.estado,
             'costo_unitario', cp.costo_unitario, 'costo_con_iva', cp.costo_con_iva,
             'iva', coalesce(cp.iva, case when pv.cobra_iva then pv.iva_compra else 0 end),
             'disponible', cp.disponible, 'dias_entrega', cp.dias_entrega, 'flete', cp.flete,
             'unidades_por_caja', cp.unidades_por_caja, 'observacion', cp.observacion,
             'fecha_respuesta', cp.fecha_respuesta, 'seleccionado', cp.seleccionado,
             'cantidad_pedir', cp.cantidad_pedir,
             'precio_erp', ip.precio, 'referencia', ip.refs)
             order by pv.nombre, sc.fecha_creacion) as cots
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
    join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
    join public.proveedores pv on pv.id = cp.proveedor_id
    left join lateral (
      select max(x.precio_unitario) as precio,
             string_agg(distinct x.codigo_proveedor, ' / ')
               filter (where coalesce(x.codigo_proveedor, '') <> '') as refs
      from public.item_proveedor x
      where x.item_id = si.item_id and x.proveedor_id = cp.proveedor_id
    ) ip on true
    where si.item_id = i.id_item and si.estado = 'activo'
  ) g on true
  left join lateral (
    select array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  where i.organizacion_id = p_org
    and g.cots is not null
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
      )
    )
  order by i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_items_catalogo"("p_org" "uuid", "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "linea" "text", "unidad_medida" "text", "provisional" boolean, "cantidad_sugerida" numeric, "agotado_sedes" "text"[], "en_gestion" boolean, "proveedores" "jsonb", "ultima_orden_numero" "text", "ultima_orden_fecha" timestamp with time zone, "ultima_orden_cantidad" numeric, "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare v_q text; v_terms text[]; v_filtrado boolean;
begin
  perform public._pedidos_check(p_org, 'ver');

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;
  v_filtrado := coalesce(p_linea, '') <> '' or v_q <> '';

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, i.unidad_medida, i.provisional,
         ag.cant, ag.sedes,
         exists (
           select 1 from public.solicitud_items si
           join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
           where sc.organizacion_id = p_org and si.item_id = i.id_item and si.estado = 'activo'),
         coalesce(pv.lista, '[]'::jsonb),
         uo.numero, uo.fecha, uo.cantidad,
         count(*) over()
  from public.items i
  left join lateral (
    select sum(a.cantidad_sugerida) as cant, count(*) as n,
           array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  left join lateral (
    select jsonb_agg(jsonb_build_object(
             'proveedor_id', prv.id, 'proveedor', prv.nombre, 'documento', prv.tipo_documento || ' ' || prv.numero_documento,
             'codigo', ip.refs, 'precio_erp', ip.precio, 'dias', ip.dias,
             'preferido', ip.pref, 'unidades_por_caja', ip.upc,
             'ya_en_solicitud', exists (
               select 1 from public.solicitud_items si
               join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
               where sc.organizacion_id = p_org and sc.proveedor_id = prv.id
                 and sc.estado <> 'cerrada' and si.item_id = i.id_item and si.estado = 'activo'))
           order by ip.pref desc, prv.nombre) as lista,
           lower(coalesce(string_agg(ip.refs, ' '), '')) as refs
    from (
      select x.proveedor_id,
             string_agg(distinct x.codigo_proveedor, ' / ')
               filter (where coalesce(x.codigo_proveedor, '') <> '') as refs,
             max(x.precio_unitario) as precio,
             max(x.tiempo_entrega_dias) as dias,
             bool_or(x.proveedor_preferido) as pref,
             max(x.unidades_por_caja) as upc
      from public.item_proveedor x
      where x.item_id = i.id_item
      group by x.proveedor_id
    ) ip
    join public.proveedores prv on prv.id = ip.proveedor_id
  ) pv on true
  left join lateral (
    select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') as numero, oc.fecha, oi.cantidad
    from public.orden_items oi
    join public.ordenes_compra oc on oc.id = oi.orden_id
    where oi.item_id = i.id_item and oc.organizacion_id = p_org
    order by oc.fecha desc
    limit 1
  ) uo on true
  where i.organizacion_id = p_org
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    and (v_filtrado or ag.n > 0)
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
        or coalesce(pv.refs, '') like '%' || t.term || '%' escape '\'
      )
    )
  order by (ag.n > 0) desc, i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_pedidos"("p_org" "uuid", "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_estado" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "linea" "text", "unidad_medida" "text", "iva" numeric, "cantidad_sugerida" numeric, "sedes" "jsonb", "estado" "text", "cotizaciones_recibidas" integer, "cotizaciones_esperadas" integer, "mejor_costo" numeric, "mejor_proveedor" "text", "proveedor_elegido" "text", "proveedores" "jsonb", "fecha_estado" timestamp with time zone, "origen" "text", "provisional" boolean, "ultima_orden_numero" "text", "ultima_orden_fecha" timestamp with time zone, "ultima_orden_cantidad" numeric, "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._pedidos_check(p_org, 'ver');
  if coalesce(p_estado, '') not in ('', 'por_cotizar', 'en_cotizacion', 'cotizado',
       'pedido_solicitado', 'agotado_proveedor', 'repartir_sedes', 'no_se_pide') then
    raise exception 'Filtro de estado no válido';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  with ag as (
    -- lado agotados (igual que antes)
    select a.item_id,
           sum(a.cantidad_sugerida) as cant,
           min(a.fecha_estado) as f_estado,
           bool_or(a.respuesta_compras is null) as pendiente,
           bool_or(a.respuesta_compras = 'pedido_solicitado') as r_ped,
           bool_or(a.respuesta_compras = 'repartir_sedes') as r_rep,
           bool_or(a.respuesta_compras = 'no_se_pide') as r_no,
           jsonb_agg(jsonb_build_object(
             'sede_id', a.sede_id, 'sede', s.nombre,
             'cantidad_sugerida', a.cantidad_sugerida, 'notas', a.notas,
             'usuario', nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), ''),
             'fecha', a.fecha_estado, 'respuesta_compras', a.respuesta_compras,
             'motivo_compras', a.motivo_compras)
             order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    left join public.profiles pu on pu.id = a.creado_por
    where a.organizacion_id = p_org and a.estado_comercial is not null
    group by a.item_id
  ),
  man as (
    -- lado Compras: ítems con una solicitud activa (existan o no agotados)
    select si.item_id, min(sc.fecha_creacion) as f_estado
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
    where sc.organizacion_id = p_org and si.estado = 'activo'
    group by si.item_id
  ),
  base as (
    select coalesce(ag.item_id, man.item_id) as item_id,
           ag.cant,
           coalesce(ag.f_estado, man.f_estado) as f_estado,
           coalesce(ag.pendiente, true) as pendiente,
           coalesce(ag.r_ped, false) as r_ped,
           coalesce(ag.r_rep, false) as r_rep,
           coalesce(ag.r_no, false) as r_no,
           coalesce(ag.sedes, '[]'::jsonb) as sedes,
           (ag.item_id is not null) as con_agotado
    from ag
    full join man on man.item_id = ag.item_id
  ),
  cot as (
    select si.item_id,
           count(*)::int as esperadas,
           (count(*) filter (where cp.fecha_respuesta is not null))::int as recibidas,
           coalesce(bool_or(cp.seleccionado), false) as hay_ganador
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
    join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
    where si.estado = 'activo'
    group by si.item_id
  ),
  x as (
    select b.item_id, i.codigo_erp as codigo, i.nombre_base, i.linea, i.unidad_medida, i.iva,
           b.cant, b.sedes, b.f_estado,
           case
             when b.pendiente then
               case when coalesce(c.esperadas, 0) = 0 then 'por_cotizar'
                    when c.hay_ganador then 'cotizado'
                    else 'en_cotizacion' end
             when b.r_ped then 'pedido_solicitado'
             when b.r_rep then 'repartir_sedes'
             when b.r_no then 'no_se_pide'
             else 'agotado_proveedor'
           end as est,
           coalesce(c.recibidas, 0) as rec,
           coalesce(c.esperadas, 0) as esp,
           mj.costo, mj.prov, el.prov as elegido,
           coalesce(pv.lista, '[]'::jsonb) as lista,
           case when b.con_agotado then 'agotado' else 'manual' end as origen,
           i.provisional,
           uo.numero as uo_num, uo.fecha as uo_fecha, uo.cantidad as uo_cant
    from base b
    join public.items i on i.id_item = b.item_id and i.organizacion_id = p_org
    left join cot c on c.item_id = b.item_id
    left join lateral (
      select cp.costo_unitario as costo, prv.nombre as prov
      from public.solicitud_items si
      join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
      join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
      join public.proveedores prv on prv.id = cp.proveedor_id
      where si.item_id = b.item_id and si.estado = 'activo'
        and cp.disponible is true and cp.costo_unitario is not null
      order by cp.costo_unitario
      limit 1
    ) mj on true
    left join lateral (
      select prv.nombre as prov
      from public.solicitud_items si
      join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
      join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
      join public.proveedores prv on prv.id = cp.proveedor_id
      where si.item_id = b.item_id and si.estado = 'activo' and cp.seleccionado
      limit 1
    ) el on true
    left join lateral (
      select jsonb_agg(jsonb_build_object(
               'proveedor_id', prv.id, 'proveedor', prv.nombre, 'documento', prv.tipo_documento || ' ' || prv.numero_documento,
               'codigo', ip.codigo_proveedor, 'precio_erp', ip.precio_unitario,
               'dias', ip.tiempo_entrega_dias, 'preferido', ip.proveedor_preferido,
               'unidades_por_caja', ip.unidades_por_caja)
             order by ip.proveedor_preferido desc, prv.nombre) as lista,
             lower(coalesce(string_agg(ip.codigo_proveedor, ' '), '')) as refs
      from public.item_proveedor ip
      join public.proveedores prv on prv.id = ip.proveedor_id
      where ip.item_id = b.item_id
    ) pv on true
    left join lateral (
      -- última orden del ítem (cualquier proveedor): ayuda a no pedir dos veces lo mismo
      select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') as numero, oc.fecha, oi.cantidad
      from public.orden_items oi
      join public.ordenes_compra oc on oc.id = oi.orden_id
      where oi.item_id = b.item_id and oc.organizacion_id = p_org
      order by oc.fecha desc
      limit 1
    ) uo on true
    where (coalesce(p_linea, '') = '' or i.linea = p_linea)
      and not exists (
        select 1 from unnest(v_terms) as t(term)
        where not (
          extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
          or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
          or coalesce(pv.refs, '') like '%' || t.term || '%' escape '\'
        )
      )
  )
  select x.item_id, x.codigo, x.nombre_base, x.linea, x.unidad_medida, x.iva,
         x.cant, x.sedes, x.est, x.rec, x.esp,
         x.costo, x.prov, x.elegido, x.lista, x.f_estado,
         x.origen, x.provisional, x.uo_num, x.uo_fecha, x.uo_cant,
         count(*) over()
  from x
  where coalesce(p_estado, '') = '' or x.est = p_estado
  order by case x.est when 'por_cotizar' then 0 when 'en_cotizacion' then 1
                      when 'cotizado' then 2 when 'agotado_proveedor' then 3
                      when 'repartir_sedes' then 4 when 'no_se_pide' then 5
                      else 6 end,
           x.f_estado, x.nombre_base
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_proveedores_pedidos"("p_org" "uuid") RETURNS TABLE("id" bigint, "nombre" "text", "documento" "text", "items_pendientes" integer, "solicitudes_abiertas" integer, "items_total" integer)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
begin
  perform public._pedidos_check(p_org, 'ver');
  return query
  select pv.id, pv.nombre, pv.tipo_documento || ' ' || pv.numero_documento,
    (select count(distinct ip.item_id)
       from public.item_proveedor ip
       where ip.proveedor_id = pv.id
         and exists (select 1 from public.agotados a
                     where a.organizacion_id = p_org and a.item_id = ip.item_id
                       and a.estado_comercial is not null and a.respuesta_compras is null))::int,
    (select count(*) from public.solicitudes_cotizacion sc
       where sc.proveedor_id = pv.id and sc.organizacion_id = p_org and sc.estado <> 'cerrada')::int,
    (select count(distinct ip.item_id) from public.item_proveedor ip
       where ip.proveedor_id = pv.id)::int
  from public.proveedores pv
  where pv.organizacion_id = p_org
  order by 4 desc, pv.nombre;
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_ordenes_por_generar"("p_org" "uuid") RETURNS TABLE("proveedor_id" bigint, "proveedor" "text", "documento" "text", "items" integer, "total_con_iva" numeric, "lineas" "jsonb")
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
begin
  perform public._pedidos_check(p_org, 'ver');
  return query
  select pv.id, pv.nombre, pv.tipo_documento || ' ' || pv.numero_documento, count(*)::int,
         sum(cp.cantidad_pedir * cp.costo_con_iva),
         jsonb_agg(jsonb_build_object(
           'cotizacion_id', cp.id, 'item_id', si.item_id, 'codigo', i.codigo_erp,
           'nombre_base', i.nombre_base, 'linea', i.linea, 'referencia', r.refs,
           'cantidad', cp.cantidad_pedir, 'unidades_por_caja', cp.unidades_por_caja,
           'cajas', case when cp.unidades_por_caja is not null
                         then ceil(cp.cantidad_pedir / cp.unidades_por_caja) end,
           'costo_unitario', cp.costo_unitario, 'costo_con_iva', cp.costo_con_iva,
           'flete', cp.flete)
           order by i.nombre_base)
  from public.cotizacion_precios cp
  join public.solicitud_items si on si.id = cp.solicitud_item_id
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
  join public.items i on i.id_item = si.item_id
  join public.proveedores pv on pv.id = cp.proveedor_id
  left join lateral (
    select string_agg(distinct ip.codigo_proveedor, ' / ') as refs
    from public.item_proveedor ip
    where ip.item_id = si.item_id and ip.proveedor_id = cp.proveedor_id
      and coalesce(ip.codigo_proveedor, '') <> ''
  ) r on true
  where sc.organizacion_id = p_org and cp.seleccionado and si.estado = 'activo'
  group by pv.id, pv.nombre
  order by pv.nombre;
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_ordenes_compra"("p_org" "uuid", "p_proveedor" bigint DEFAULT NULL::bigint, "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("id" "uuid", "numero" integer, "numero_texto" "text", "proveedor_id" bigint, "proveedor" "text", "documento" "text", "sede" "text", "fecha" timestamp with time zone, "total_oc" numeric, "creado_por" "text", "items" "jsonb", "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
begin
  perform public._pedidos_check(p_org, 'ver');
  return query
  select oc.id, oc.numero, 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0'),
         oc.proveedor_id, pv.nombre, pv.tipo_documento || ' ' || pv.numero_documento, s.nombre, oc.fecha, oc.total,
         nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), ''),
         coalesce(it.lista, '[]'::jsonb), count(*) over()
  from public.ordenes_compra oc
  join public.proveedores pv on pv.id = oc.proveedor_id
  left join public.sedes s on s.id = oc.sede_id
  left join public.profiles pu on pu.id = oc.creado_por
  left join lateral (
    select jsonb_agg(jsonb_build_object(
             'item_id', oi.item_id, 'codigo', i.codigo_erp, 'nombre_base', i.nombre_base, 'linea', i.linea,
             'cantidad', oi.cantidad, 'unidades_por_caja', cp.unidades_por_caja,
             'costo_unitario', oi.precio_unitario_acordado, 'costo_con_iva', cp.costo_con_iva)
           order by i.nombre_base) as lista
    from public.orden_items oi
    join public.items i on i.id_item = oi.item_id
    left join public.cotizacion_precios cp on cp.id = oi.cotizacion_precio_id
    where oi.orden_id = oc.id
  ) it on true
  where oc.organizacion_id = p_org
    and (p_proveedor is null or oc.proveedor_id = p_proveedor)
  order by oc.fecha desc
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."orden_compra_texto"("p_org" "uuid", "p_orden" "uuid") RETURNS "text"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
declare
  v_num integer; v_prov text; v_nit bigint; v_doc text; v_sede text; v_ciudad text;
  v_total numeric; v_fecha timestamptz; v_lineas text;
begin
  perform public._pedidos_check(p_org, 'ver');
  select oc.numero, pv.nombre, pv.id, s.nombre, s.ciudad, oc.total, oc.fecha
    into v_num, v_prov, v_nit, v_sede, v_ciudad, v_total, v_fecha
  from public.ordenes_compra oc
  join public.proveedores pv on pv.id = oc.proveedor_id
  left join public.sedes s on s.id = oc.sede_id
  where oc.id = p_orden and oc.organizacion_id = p_org;
  if not found then raise exception 'Orden no encontrada'; end if;
  select pv.tipo_documento || ' ' || pv.numero_documento into v_doc from public.proveedores pv where pv.id = v_nit;

  select coalesce(string_agg(l.n::text || '. ' || l.txt, E'\n' order by l.n), '') into v_lineas
  from (
    select row_number() over (order by i.nombre_base, i.id_item) as n,
           i.nombre_base
             || case when r.refs is not null then ' | Ref: ' || r.refs else '' end
             || ' | Cant: ' || trim_scale(oi.cantidad)::text || ' ' || coalesce(i.unidad_medida, 'und')
             || case when cp.unidades_por_caja is not null
                     then ' (' || ceil(oi.cantidad / cp.unidades_por_caja)::int::text
                          || ' caja(s) de ' || cp.unidades_por_caja::text || ')'
                     else '' end
             || ' | Costo unit.: ' || public._fmt_moneda(oi.precio_unitario_acordado) || ' + IVA' as txt
    from public.orden_items oi
    join public.items i on i.id_item = oi.item_id
    left join public.cotizacion_precios cp on cp.id = oi.cotizacion_precio_id
    left join lateral (
      select string_agg(distinct ip.codigo_proveedor, ' / ') as refs
      from public.item_proveedor ip
      where ip.item_id = oi.item_id and ip.proveedor_id = v_nit
        and coalesce(ip.codigo_proveedor, '') <> ''
    ) r on true
    where oi.orden_id = p_orden
  ) l;

  return 'ORDEN DE COMPRA OC-' || lpad(coalesce(v_num, 0)::text, 4, '0')
    || E'\nProveedor: ' || v_prov || ' (' || v_doc || ')'
    || E'\nFecha: ' || to_char(v_fecha at time zone 'America/Bogota', 'DD/MM/YYYY')
    || E'\nEntregar en: ' || coalesce(v_sede, '-') || coalesce(' - ' || v_ciudad, '')
    || E'\n\n' || v_lineas
    || E'\n\nTotal con IVA: ' || public._fmt_moneda(v_total);
end $$;

revoke all on function public.cotizacion_agregar_proveedor(uuid, bigint, bigint, text, text, text, text, integer, numeric) from public, anon;
grant execute on function public.cotizacion_agregar_proveedor(uuid, bigint, bigint, text, text, text, text, integer, numeric) to authenticated, service_role;
revoke all on function public.cotizacion_guardar(uuid, uuid, boolean, numeric, integer, numeric, text, integer, numeric) from public, anon;
grant execute on function public.cotizacion_guardar(uuid, uuid, boolean, numeric, integer, numeric, text, integer, numeric) to authenticated, service_role;
revoke all on function public.obtener_cotizaciones_item(uuid, bigint, boolean) from public, anon;
grant execute on function public.obtener_cotizaciones_item(uuid, bigint, boolean) to authenticated, service_role;
revoke all on function public.matriz_cotizaciones(uuid, text, text, integer, integer) from public, anon;
grant execute on function public.matriz_cotizaciones(uuid, text, text, integer, integer) to authenticated, service_role;
revoke all on function public.listar_items_catalogo(uuid, text, text, integer, integer) from public, anon;
grant execute on function public.listar_items_catalogo(uuid, text, text, integer, integer) to authenticated, service_role;
revoke all on function public.listar_pedidos(uuid, text, text, text, integer, integer) from public, anon;
grant execute on function public.listar_pedidos(uuid, text, text, text, integer, integer) to authenticated, service_role;
revoke all on function public.listar_proveedores_pedidos(uuid) from public, anon;
grant execute on function public.listar_proveedores_pedidos(uuid) to authenticated, service_role;
revoke all on function public.listar_ordenes_por_generar(uuid) from public, anon;
grant execute on function public.listar_ordenes_por_generar(uuid) to authenticated, service_role;
revoke all on function public.listar_ordenes_compra(uuid, bigint, integer, integer) from public, anon;
grant execute on function public.listar_ordenes_compra(uuid, bigint, integer, integer) to authenticated, service_role;
revoke all on function public.orden_compra_texto(uuid, uuid) from public, anon;
grant execute on function public.orden_compra_texto(uuid, uuid) to authenticated, service_role;
