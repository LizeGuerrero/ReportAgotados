-- Fase 2 · PROVEEDORES — parte 2 de 3: funciones del módulo Proveedores
-- Requiere 01-07 (Ítems) y 08. UNA por vez. Idempotente.

set lock_timeout = '5s';

-- Documento: normaliza y valida (sin guiones ni dígito de verificación)
create or replace function public._proveedor_documento(p_tipo text, p_numero text, out tipo text, out numero text)
language plpgsql immutable
set search_path to ''
as $$
begin
  tipo := upper(coalesce(nullif(btrim(p_tipo), ''), 'NIT'));
  if tipo not in ('NIT', 'CC', 'CE', 'PAS', 'OTRO') then
    raise exception 'Tipo de documento no válido (NIT, CC, CE, PAS u OTRO)';
  end if;
  numero := upper(regexp_replace(btrim(coalesce(p_numero, '')), '[\s.]', '', 'g'));
  if numero !~ '^[A-Z0-9]{3,20}$' then
    raise exception 'Documento no válido: de 3 a 20 letras o números, sin guiones ni dígito de verificación';
  end if;
end $$;

-- Busca un proveedor de la organización por documento; si no existe lo crea (exige nombre).
-- Lo usan Proveedores y Pedidos, así hay UNA sola lógica de alta.
create or replace function public._proveedor_resolver_o_crear(p_org uuid, p_tipo text, p_numero text, p_nombre text)
returns bigint
language plpgsql security definer
set search_path to ''
as $$
declare v_t text; v_n text; v_id bigint; v_nombre text := nullif(btrim(p_nombre), '');
begin
  select d.tipo, d.numero into v_t, v_n from public._proveedor_documento(p_tipo, p_numero) d;
  select pv.id into v_id from public.proveedores pv
   where pv.organizacion_id = p_org and pv.tipo_documento = v_t and lower(btrim(pv.numero_documento)) = lower(v_n);
  if v_id is not null then return v_id; end if;
  if v_nombre is null then raise exception 'Para un proveedor nuevo escribe el nombre'; end if;
  if char_length(v_nombre) > 200 then raise exception 'El nombre no puede superar 200 caracteres'; end if;
  begin
    insert into public.proveedores (organizacion_id, tipo_documento, numero_documento, nombre)
    values (p_org, v_t, v_n, v_nombre) returning id into v_id;
  exception when unique_violation then
    select pv.id into v_id from public.proveedores pv
     where pv.organizacion_id = p_org and pv.tipo_documento = v_t and lower(btrim(pv.numero_documento)) = lower(v_n);
  end;
  return v_id;
end $$;

create or replace function public.proveedores_listar(
  p_org uuid, p_busqueda text default null, p_limit integer default 50, p_offset integer default 0)
returns table(proveedor_id bigint, tipo_documento text, numero_documento text, nombre text, contacto text,
              telefono text, email text, cobra_iva boolean, iva_compra numeric, items integer, total bigint)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'ver');
  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select pv.id, pv.tipo_documento, pv.numero_documento, pv.nombre, pv.contacto, pv.telefono, pv.email,
         pv.cobra_iva, pv.iva_compra,
         (select count(distinct ip.item_id)::int from public.item_proveedor ip where ip.proveedor_id = pv.id),
         count(*) over()
  from public.proveedores pv
  where pv.organizacion_id = p_org
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(pv.nombre)) like '%' || t.term || '%' escape '\'
        or lower(pv.numero_documento) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(coalesce(pv.contacto, ''))) like '%' || t.term || '%' escape '\'
        or lower(coalesce(pv.email, '')) like '%' || t.term || '%' escape '\'
      )
    )
  order by pv.nombre, pv.id
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

create or replace function public.proveedor_obtener(p_org uuid, p_proveedor bigint)
returns jsonb
language plpgsql stable security definer
set search_path to ''
as $$
declare v jsonb;
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'ver');
  select to_jsonb(pv) - 'organizacion_id' into v
  from public.proveedores pv where pv.id = p_proveedor and pv.organizacion_id = p_org;
  if v is null then raise exception 'Proveedor no encontrado'; end if;
  return v;
end $$;

create or replace function public.proveedor_crear(p_org uuid, p_datos jsonb)
returns bigint
language plpgsql security definer
set search_path to ''
as $$
declare
  v_t text; v_n text; v_nombre text; v_email text; v_cobra boolean; v_iva numeric; v_id bigint; v_otro text;
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'crear');
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;

  select d.tipo, d.numero into v_t, v_n
    from public._proveedor_documento(p_datos->>'tipo_documento', p_datos->>'numero_documento') d;

  v_nombre := nullif(btrim(p_datos->>'nombre'), '');
  if v_nombre is null then raise exception 'Escribe el nombre del proveedor'; end if;
  if char_length(v_nombre) > 200 then raise exception 'El nombre no puede superar 200 caracteres'; end if;

  v_email := nullif(btrim(p_datos->>'email'), '');
  if v_email is not null and v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Correo no válido'; end if;

  v_cobra := coalesce((p_datos->>'cobra_iva')::boolean, true);
  v_iva := coalesce(nullif(btrim(p_datos->>'iva_compra'), '')::numeric, 0.19);
  if v_iva < 0 or v_iva > 1 then
    raise exception 'IVA no válido: usa una fracción entre 0 y 1 (por ejemplo 0.19)';
  end if;

  select pv.nombre into v_otro from public.proveedores pv
   where pv.organizacion_id = p_org and pv.tipo_documento = v_t and lower(btrim(pv.numero_documento)) = lower(v_n);
  if found then raise exception 'Ya existe un proveedor con ese documento: %', v_otro; end if;

  begin
    insert into public.proveedores
      (organizacion_id, tipo_documento, numero_documento, nombre, contacto, telefono, email, notas, cobra_iva, iva_compra)
    values (p_org, v_t, v_n, v_nombre, nullif(btrim(p_datos->>'contacto'), ''), nullif(btrim(p_datos->>'telefono'), ''),
            v_email, nullif(btrim(p_datos->>'notas'), ''), v_cobra, v_iva)
    returning id into v_id;
  exception when unique_violation then
    raise exception 'Ya existe un proveedor con ese documento';
  end;
  return v_id;
end $$;

create or replace function public.proveedor_actualizar(p_org uuid, p_proveedor bigint, p_datos jsonb)
returns void
language plpgsql security definer
set search_path to ''
as $$
declare
  v_pv public.proveedores%rowtype; v_t text; v_n text; v_email text; v_iva numeric; v_otro text;
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'editar');
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;
  select * into v_pv from public.proveedores where id = p_proveedor and organizacion_id = p_org for update;
  if not found then raise exception 'Proveedor no encontrado'; end if;

  v_t := v_pv.tipo_documento; v_n := v_pv.numero_documento;
  if p_datos ? 'tipo_documento' or p_datos ? 'numero_documento' then
    select d.tipo, d.numero into v_t, v_n
      from public._proveedor_documento(coalesce(p_datos->>'tipo_documento', v_pv.tipo_documento),
                                       coalesce(p_datos->>'numero_documento', v_pv.numero_documento)) d;
    select x.nombre into v_otro from public.proveedores x
     where x.organizacion_id = p_org and x.id <> p_proveedor and x.tipo_documento = v_t
       and lower(btrim(x.numero_documento)) = lower(v_n);
    if found then raise exception 'Ya existe un proveedor con ese documento: %', v_otro; end if;
  end if;

  if p_datos ? 'nombre' then
    if nullif(btrim(p_datos->>'nombre'), '') is null then raise exception 'El nombre no puede quedar vacío'; end if;
    if char_length(btrim(p_datos->>'nombre')) > 200 then raise exception 'El nombre no puede superar 200 caracteres'; end if;
  end if;

  v_email := case when p_datos ? 'email' then nullif(btrim(p_datos->>'email'), '') else v_pv.email end;
  if v_email is not null and v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'Correo no válido'; end if;

  v_iva := v_pv.iva_compra;
  if p_datos ? 'iva_compra' then
    v_iva := coalesce(nullif(btrim(p_datos->>'iva_compra'), '')::numeric, 0.19);
    if v_iva < 0 or v_iva > 1 then
      raise exception 'IVA no válido: usa una fracción entre 0 y 1 (por ejemplo 0.19)';
    end if;
  end if;

  update public.proveedores pv set
    tipo_documento   = v_t,
    numero_documento = v_n,
    nombre   = case when p_datos ? 'nombre'   then btrim(p_datos->>'nombre') else pv.nombre end,
    contacto = case when p_datos ? 'contacto' then nullif(btrim(p_datos->>'contacto'), '') else pv.contacto end,
    telefono = case when p_datos ? 'telefono' then nullif(btrim(p_datos->>'telefono'), '') else pv.telefono end,
    email    = v_email,
    notas    = case when p_datos ? 'notas'    then nullif(btrim(p_datos->>'notas'), '') else pv.notas end,
    cobra_iva = case when p_datos ? 'cobra_iva' then coalesce((p_datos->>'cobra_iva')::boolean, pv.cobra_iva) else pv.cobra_iva end,
    iva_compra = v_iva
  where pv.id = p_proveedor;
end $$;

-- Catálogo del proveedor: qué ítems nos vende y con qué referencia / nombre
create or replace function public.proveedor_items_listar(
  p_org uuid, p_proveedor bigint, p_busqueda text default null, p_limit integer default 200, p_offset integer default 0)
returns table(id uuid, item_id bigint, codigo text, nombre_base text, linea text, activo boolean, provisional boolean,
              variante_id text, codigo_proveedor text, nombre_producto_proveedor text, unidades_por_caja integer,
              precio_unitario numeric, tiempo_entrega_dias integer, proveedor_preferido boolean, notas text, total bigint)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'ver');
  if not exists (select 1 from public.proveedores where id = p_proveedor and organizacion_id = p_org) then
    raise exception 'Proveedor no encontrado';
  end if;
  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select ip.id, i.id_item, i.codigo_erp, i.nombre_base, i.linea, i.activo, i.provisional,
         ip.variante_id, ip.codigo_proveedor, ip.nombre_producto_proveedor, ip.unidades_por_caja,
         ip.precio_unitario, ip.tiempo_entrega_dias, ip.proveedor_preferido, ip.notas, count(*) over()
  from public.item_proveedor ip
  join public.items i on i.id_item = ip.item_id and i.organizacion_id = p_org
  where ip.proveedor_id = p_proveedor
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
        or lower(coalesce(ip.codigo_proveedor, '')) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(coalesce(ip.nombre_producto_proveedor, ''))) like '%' || t.term || '%' escape '\'
      )
    )
  order by i.nombre_base, ip.codigo_proveedor nulls last
  limit least(greatest(p_limit, 1), 500) offset greatest(p_offset, 0);
end $$;

create or replace function public.proveedor_historial(p_org uuid, p_proveedor bigint, p_limit integer default 100)
returns table(fecha timestamptz, tabla text, accion text, usuario text, antes jsonb, despues jsonb)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'ver');
  return query
  select a.fecha, a.tabla, a.accion,
         nullif(btrim(coalesce(p.nombres, '') || ' ' || coalesce(p.apellidos, '')), ''),
         a.antes, a.despues
  from public.auditoria a
  left join public.profiles p on p.id = a.usuario_id
  where a.organizacion_id = p_org
    and ((a.tabla = 'proveedores' and a.registro = p_proveedor::text)
      or (a.tabla = 'item_proveedor' and coalesce(a.despues, a.antes)->>'proveedor_id' = p_proveedor::text))
  order by a.fecha desc
  limit least(greatest(p_limit, 1), 500);
end $$;

-- item_proveedores_listar ahora también devuelve el documento del proveedor (cambia la forma: se recrea)
drop function if exists public.item_proveedores_listar(uuid, bigint);

create or replace function public.item_proveedores_listar(p_org uuid, p_item bigint)
returns table(id uuid, proveedor_id bigint, proveedor text, documento text, variante_id text, codigo_proveedor text,
              nombre_producto_proveedor text, unidades_por_caja integer, precio_unitario numeric,
              tiempo_entrega_dias integer, proveedor_preferido boolean, notas text, repetida_en_otros integer)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'ver');
  if not exists (select 1 from public.items where id_item = p_item and organizacion_id = p_org) then
    raise exception 'Ítem no encontrado';
  end if;
  return query
  select ip.id, ip.proveedor_id, pv.nombre, pv.tipo_documento || ' ' || pv.numero_documento, ip.variante_id, ip.codigo_proveedor,
         ip.nombre_producto_proveedor, ip.unidades_por_caja, ip.precio_unitario,
         ip.tiempo_entrega_dias, ip.proveedor_preferido, ip.notas,
         (select count(distinct x.item_id)::int
            from public.item_proveedor x
            join public.items i2 on i2.id_item = x.item_id and i2.organizacion_id = p_org
           where x.proveedor_id = ip.proveedor_id and x.item_id <> ip.item_id
             and ip.codigo_proveedor is not null
             and lower(btrim(x.codigo_proveedor)) = lower(btrim(ip.codigo_proveedor)))
  from public.item_proveedor ip
  join public.proveedores pv on pv.id = ip.proveedor_id and pv.organizacion_id = p_org
  where ip.item_id = p_item
  order by pv.nombre, ip.codigo_proveedor nulls last;
end $$;

-- Permisos de ejecución
revoke all on function public._proveedor_documento(text, text) from public, anon, authenticated;
grant execute on function public._proveedor_documento(text, text) to service_role;
revoke all on function public._proveedor_resolver_o_crear(uuid, text, text, text) from public, anon, authenticated;
grant execute on function public._proveedor_resolver_o_crear(uuid, text, text, text) to service_role;

do $$
declare f text;
begin
  foreach f in array array[
    'public.proveedores_listar(uuid, text, integer, integer)',
    'public.proveedor_obtener(uuid, bigint)',
    'public.proveedor_crear(uuid, jsonb)',
    'public.proveedor_actualizar(uuid, bigint, jsonb)',
    'public.proveedor_items_listar(uuid, bigint, text, integer, integer)',
    'public.proveedor_historial(uuid, bigint, integer)',
    'public.item_proveedores_listar(uuid, bigint)'
  ] loop
    execute format('revoke all on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated, service_role', f);
  end loop;
end $$;
