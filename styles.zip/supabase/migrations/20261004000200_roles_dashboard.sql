-- =============================================================================
-- Dashboard de roles: crear, editar, eliminar roles y guardar su matriz de permisos
--
-- Aditiva: solo agrega funciones. No cambia tablas, políticas ni funciones existentes.
-- Requiere haber aplicado antes migracion_orgs_invitaciones.sql (usa es_admin_org e invitaciones).
-- Se puede correr más de una vez. Corre en una sola transacción.
--
-- Reglas:
--   · Todo es solo para admin ACTIVO de la organización dueña del rol.
--   · "admin" y "viewer" (Predeterminado) son roles del sistema: no se renombran, no se
--     eliminan y no se les editan permisos (admin = todo; viewer = nada).
--   · El módulo "Roles" está reservado al rol admin: no se puede dar a ningún otro rol.
--   · No se puede eliminar un rol con miembros ni con invitaciones pendientes.
-- =============================================================================
begin;

-- -----------------------------------------------------------------------------
-- Utilidades internas (no se exponen al navegador)
-- -----------------------------------------------------------------------------
create or replace function public._rol_protegido(p_nombre text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select p_nombre in ('admin', 'viewer')
$$;

create or replace function public._validar_nombre_rol(p_org uuid, p_nombre text, p_excluir uuid)
returns void
language plpgsql
stable
set search_path = ''
as $$
begin
  if char_length(p_nombre) < 2 or char_length(p_nombre) > 40 then
    raise exception 'El nombre del rol debe tener entre 2 y 40 caracteres';
  end if;
  if lower(p_nombre) in ('admin', 'viewer', 'predeterminado') then
    raise exception 'Ese nombre está reservado por el sistema';
  end if;
  if exists (
    select 1 from public.roles r
     where r.organizacion_id = p_org
       and lower(r.nombre) = lower(p_nombre)
       and (p_excluir is null or r.id <> p_excluir)
  ) then
    raise exception 'Ya existe un rol con ese nombre en la organización';
  end if;
end $$;

-- -----------------------------------------------------------------------------
-- Lectura
-- -----------------------------------------------------------------------------
create or replace function public.listar_roles_org(p_org uuid)
returns table (
  rol_id uuid, nombre text, descripcion text, protegido boolean,
  miembros bigint, invitaciones_pendientes bigint
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede ver los roles';
  end if;

  return query
  select r.id, r.nombre, r.descripcion, public._rol_protegido(r.nombre),
         (select count(*) from public.membresias m
           where m.rol_id = r.id and m.estado_membresia = 'activa' and m.activo),
         (select count(*) from public.invitaciones i
           where i.rol_id = r.id and i.estado = 'pendiente' and i.expira_en > now())
  from public.roles r
  where r.organizacion_id = p_org
  order by (r.nombre = 'admin') desc, (r.nombre = 'viewer') desc, r.nombre;
end $$;

create or replace function public.listar_permisos_org(p_org uuid)
returns table (
  rol_id uuid, modulo_id uuid,
  puede_ver boolean, puede_crear boolean, puede_editar boolean, puede_eliminar boolean
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede ver los permisos';
  end if;

  return query
  select pr.rol_id, pr.modulo_id, pr.puede_ver, pr.puede_crear, pr.puede_editar, pr.puede_eliminar
  from public.permisos_rol pr
  join public.roles r on r.id = pr.rol_id
  where r.organizacion_id = p_org;
end $$;

-- -----------------------------------------------------------------------------
-- Escritura
-- -----------------------------------------------------------------------------
-- Crea un rol, opcionalmente copiando los permisos de otro (nunca se copia el módulo "Roles").
create or replace function public.crear_rol(
  p_org uuid, p_nombre text, p_descripcion text default null, p_copiar_de uuid default null
) returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_nombre text := btrim(coalesce(p_nombre, ''));
  v_desc   text := nullif(btrim(coalesce(p_descripcion, '')), '');
  v_id     uuid;
begin
  if not public.es_admin_org(p_org) then
    raise exception 'Solo un administrador puede crear roles';
  end if;
  perform public._validar_nombre_rol(p_org, v_nombre, null);
  if v_desc is not null and char_length(v_desc) > 200 then
    raise exception 'La descripción no puede superar 200 caracteres';
  end if;
  if p_copiar_de is not null
     and not exists (select 1 from public.roles where id = p_copiar_de and organizacion_id = p_org) then
    raise exception 'El rol de origen no pertenece a esta organización';
  end if;

  insert into public.roles (nombre, organizacion_id, descripcion)
  values (v_nombre, p_org, v_desc)
  returning id into v_id;

  if p_copiar_de is not null then
    insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
    select v_id, pr.modulo_id, pr.puede_ver, pr.puede_crear, pr.puede_editar, pr.puede_eliminar
    from public.permisos_rol pr
    join public.modulos mo on mo.id = pr.modulo_id
    where pr.rol_id = p_copiar_de and mo.nombre <> 'Roles';
  end if;

  return v_id;
end $$;

create or replace function public.editar_rol(p_rol uuid, p_nombre text, p_descripcion text default null)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_r      public.roles%rowtype;
  v_nombre text := btrim(coalesce(p_nombre, ''));
  v_desc   text := nullif(btrim(coalesce(p_descripcion, '')), '');
begin
  select * into v_r from public.roles where id = p_rol;
  if not found or v_r.organizacion_id is null or not public.es_admin_org(v_r.organizacion_id) then
    raise exception 'Solo un administrador puede editar roles';
  end if;
  if public._rol_protegido(v_r.nombre) then
    raise exception 'Este rol es del sistema y no se puede modificar';
  end if;
  perform public._validar_nombre_rol(v_r.organizacion_id, v_nombre, p_rol);
  if v_desc is not null and char_length(v_desc) > 200 then
    raise exception 'La descripción no puede superar 200 caracteres';
  end if;

  update public.roles set nombre = v_nombre, descripcion = v_desc where id = p_rol;
end $$;

-- Reemplaza TODA la matriz del rol de forma atómica.
-- p_permisos = [{"modulo_id": "...", "ver": true, "crear": false, "editar": false, "eliminar": false}, ...]
-- Los módulos que no vienen o vienen sin ningún permiso quedan sin fila. Si un rol puede
-- crear/editar/eliminar, se le da también "ver" (no tiene sentido lo contrario).
create or replace function public.guardar_permisos_rol(p_rol uuid, p_permisos jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_r        public.roles%rowtype;
  v_item     jsonb;
  v_mod      record;
  v_ver      boolean;
  v_crear    boolean;
  v_editar   boolean;
  v_eliminar boolean;
begin
  select * into v_r from public.roles where id = p_rol for update;
  if not found or v_r.organizacion_id is null or not public.es_admin_org(v_r.organizacion_id) then
    raise exception 'Solo un administrador puede editar permisos';
  end if;
  if public._rol_protegido(v_r.nombre) then
    raise exception 'Este rol es del sistema y sus permisos no se pueden modificar';
  end if;
  if p_permisos is null or jsonb_typeof(p_permisos) <> 'array' then
    raise exception 'Formato de permisos no válido';
  end if;

  delete from public.permisos_rol where rol_id = p_rol;

  for v_item in select * from jsonb_array_elements(p_permisos) loop
    select mo.id, mo.nombre into v_mod
      from public.modulos mo
     where mo.id = (v_item ->> 'modulo_id')::uuid;
    if not found then
      raise exception 'Módulo no válido';
    end if;

    v_crear    := coalesce((v_item ->> 'crear')::boolean, false);
    v_editar   := coalesce((v_item ->> 'editar')::boolean, false);
    v_eliminar := coalesce((v_item ->> 'eliminar')::boolean, false);
    v_ver      := coalesce((v_item ->> 'ver')::boolean, false) or v_crear or v_editar or v_eliminar;

    if v_ver then
      if v_mod.nombre = 'Roles' then
        raise exception 'El módulo Roles está reservado al administrador';
      end if;
      insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
      values (p_rol, v_mod.id, true, v_crear, v_editar, v_eliminar)
      on conflict (rol_id, modulo_id) do update
         set puede_ver = true, puede_crear = excluded.puede_crear,
             puede_editar = excluded.puede_editar, puede_eliminar = excluded.puede_eliminar;
    end if;
  end loop;
end $$;

-- Elimina un rol sin miembros ni invitaciones pendientes. Borra también sus permisos y el
-- historial de invitaciones ya cerradas (aceptadas, rechazadas, canceladas o vencidas) que
-- apuntaban a ese rol, porque la base no permite dejarlas apuntando a un rol inexistente.
create or replace function public.eliminar_rol(p_rol uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_r public.roles%rowtype;
begin
  select * into v_r from public.roles where id = p_rol for update;
  if not found or v_r.organizacion_id is null or not public.es_admin_org(v_r.organizacion_id) then
    raise exception 'Solo un administrador puede eliminar roles';
  end if;
  if public._rol_protegido(v_r.nombre) then
    raise exception 'Este rol es del sistema y no se puede eliminar';
  end if;
  if exists (select 1 from public.membresias where rol_id = p_rol) then
    raise exception 'El rol tiene miembros asignados. Cámbiales el rol antes de eliminarlo';
  end if;
  if exists (
    select 1 from public.invitaciones
     where rol_id = p_rol and estado = 'pendiente' and expira_en > now()
  ) then
    raise exception 'El rol tiene invitaciones pendientes. Cancélalas antes de eliminarlo';
  end if;

  delete from public.invitaciones where rol_id = p_rol;
  delete from public.permisos_rol where rol_id = p_rol;
  delete from public.roles where id = p_rol;
end $$;

-- -----------------------------------------------------------------------------
-- Permisos de ejecución (los privilegios por defecto del proyecto dan EXECUTE a anon)
-- -----------------------------------------------------------------------------
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname = any (array[
        '_rol_protegido', '_validar_nombre_rol', 'listar_roles_org', 'listar_permisos_org',
        'crear_rol', 'editar_rol', 'guardar_permisos_rol', 'eliminar_rol'
      ])
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    if f.proname not in ('_rol_protegido', '_validar_nombre_rol') then
      execute format('grant execute on function %s to authenticated', f.sig);
    end if;
  end loop;
end $$;

commit;
