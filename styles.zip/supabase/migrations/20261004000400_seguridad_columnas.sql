-- =============================================================================
-- Seguridad de columnas: profiles y organizaciones
--
-- Las políticas existentes dejan a un usuario editar CUALQUIER columna de su propio perfil,
-- y a un admin editar CUALQUIER columna de su organización, directamente desde el navegador.
-- Esta migración no cambia ni reemplaza esas políticas: agrega triggers BEFORE UPDATE que,
-- solo para las llamadas hechas por usuarios del navegador (roles "authenticated" y "anon"),
-- rechazan el cambio de columnas que ningún usuario debe tocar por su cuenta.
--
-- NO les afecta (siguen funcionando igual):
--   · las funciones SECURITY DEFINER (corren como dueño de la base);
--   · el rol service_role (la llave secreta del servidor);
--   · el SQL Editor / psql / migraciones (corren como postgres).
--
-- Lo que la app hace hoy sigue permitido: CompleteProfileForm (nombres, apellidos, documento,
-- username, celular, foto, perfil_completo) y PATCH /api/organizaciones/[slug] (nombre).
--
-- Aditiva y se puede correr más de una vez. Corre en una sola transacción.
-- =============================================================================
begin;

-- -----------------------------------------------------------------------------
-- profiles
--   · id y created_at: no se cambian.
--   · activo: lo gobierna el sistema, no la persona.
--   · perfil_completo: puede pasar a true (así lo hace el formulario de completar perfil),
--     pero solo si los datos obligatorios del formulario están diligenciados.
-- -----------------------------------------------------------------------------
create or replace function public._trg_proteger_profiles()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if current_user in ('authenticated', 'anon') then
    if new.id is distinct from old.id then
      raise exception 'No se puede cambiar el identificador del perfil';
    end if;
    if new.created_at is distinct from old.created_at then
      raise exception 'No se puede cambiar la fecha de creación del perfil';
    end if;
    if new.activo is distinct from old.activo then
      raise exception 'No puedes cambiar el estado de tu cuenta';
    end if;
    if new.perfil_completo and not old.perfil_completo and (
         btrim(coalesce(new.nombres, '')) = ''
      or btrim(coalesce(new.apellidos, '')) = ''
      or btrim(coalesce(new.tipo_documento, '')) = ''
      or btrim(coalesce(new.numero_documento, '')) = ''
      or btrim(coalesce(new.username, '')) = ''
    ) then
      raise exception 'Completa nombres, apellidos, documento y usuario antes de continuar';
    end if;
  end if;
  return new;
end $$;

drop trigger if exists profiles_proteger_columnas on public.profiles;
create trigger profiles_proteger_columnas
  before update on public.profiles
  for each row execute function public._trg_proteger_profiles();

-- -----------------------------------------------------------------------------
-- organizaciones
--   El admin solo puede cambiar el NOMBRE. id, slug (rompería todos los enlaces),
--   activo (dejaría a todos fuera), identificacion y created_at quedan fijos.
--   (propietario_id ya está protegido por organizaciones_proteger_propietario.)
-- -----------------------------------------------------------------------------
create or replace function public._trg_proteger_organizaciones()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if current_user in ('authenticated', 'anon') then
    if new.id is distinct from old.id then
      raise exception 'No se puede cambiar el identificador de la organización';
    end if;
    if new.slug is distinct from old.slug then
      raise exception 'El código (slug) de la organización no se puede cambiar';
    end if;
    if new.activo is distinct from old.activo then
      raise exception 'El estado de la organización no se puede cambiar desde aquí';
    end if;
    if new.identificacion is distinct from old.identificacion then
      raise exception 'La identificación de la organización no se puede cambiar desde aquí';
    end if;
    if new.created_at is distinct from old.created_at then
      raise exception 'No se puede cambiar la fecha de creación de la organización';
    end if;
  end if;
  return new;
end $$;

drop trigger if exists organizaciones_proteger_columnas on public.organizaciones;
create trigger organizaciones_proteger_columnas
  before update on public.organizaciones
  for each row execute function public._trg_proteger_organizaciones();

-- -----------------------------------------------------------------------------
-- es_admin_org en políticas: una consulta SIN sesión (anon) a "roles" evalúa la política que
-- usa es_admin_org(); sin EXECUTE para anon eso daba un error en vez de una lista vacía.
-- es_admin_org() usa auth.uid(), que para anon es null, así que siempre devuelve false:
-- darle EXECUTE a anon no expone nada.
-- -----------------------------------------------------------------------------
grant execute on function public.es_admin_org(uuid) to anon;

-- Las funciones de trigger no se llaman por RPC; se les quita igual el EXECUTE por defecto.
revoke all on function public._trg_proteger_profiles() from public, anon, authenticated;
revoke all on function public._trg_proteger_organizaciones() from public, anon, authenticated;

commit;
