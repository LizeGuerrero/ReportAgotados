-- Fase 1 · ITEMS — parte 7 de 7: funciones EXISTENTES de Agotados y Pedidos, adaptadas a items.codigo_erp
-- Generado a partir de tu esquema actual (Dschemxa.sql). Solo cambia: (a) la búsqueda por código usa codigo_erp,
-- (b) se devuelve la columna nueva `codigo` para mostrarla, (c) item_provisional_vincular recibe el código como texto.
-- La lógica de negocio no se toca. Requiere haber aplicado 01-06. Idempotente: se puede repetir.

set lock_timeout = '5s';

drop function if exists public.listar_agotados(uuid, text, text, integer, integer, text, text[], text, text);
drop function if exists public.listar_items_catalogo(uuid, text, text, integer, integer);
drop function if exists public.listar_items_proveedor(uuid, bigint, text, text, boolean);
drop function if exists public.listar_pedidos(uuid, text, text, text, integer, integer);
drop function if exists public.matriz_cotizaciones(uuid, text, text, integer, integer);

CREATE OR REPLACE FUNCTION "public"."listar_agotados"("p_org" "uuid", "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0, "p_modo" "text" DEFAULT 'empieza_primero'::"text", "p_campos" "text"[] DEFAULT ARRAY['item'::"text", 'nombre'::"text", 'referencia'::"text"], "p_orden" "text" DEFAULT NULL::"text", "p_dir" "text" DEFAULT 'asc'::"text") RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "referencia" "text", "linea" "text", "sede" "text", "usuario" "text", "estado_comercial" "text", "fecha_estado" timestamp with time zone, "respuesta_compras" "text", "fecha_respuesta" timestamp with time zone, "motivo_compras" "text", "cantidad_sugerida" numeric, "notas" "text", "fecha_nota" timestamp with time zone, "seguimiento" "text", "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare
  v_sede uuid; v_q text; v_full text; v_terms text[]; v_campos text[];
  v_orden text := nullif(trim(p_orden), '');
  v_asc boolean;
begin
  v_sede := public._agotados_sede(p_org, 'reporte_agotados', 'ver');

  if p_modo not in ('contiene', 'empieza_primero', 'solo_empieza') then
    raise exception 'Modo de búsqueda no válido';
  end if;

  if v_orden is not null and v_orden not in (
    'item', 'nombre', 'referencia', 'linea', 'sede', 'usuario', 'solicitud',
    'fecha_solicitud', 'respuesta', 'fecha_respuesta', 'cantidad', 'nota',
    'fecha_nota', 'seguimiento'
  ) then
    raise exception 'Columna de orden no válida';
  end if;
  if coalesce(p_dir, 'asc') not in ('asc', 'desc') then
    raise exception 'Dirección de orden no válida';
  end if;
  v_asc := coalesce(p_dir, 'asc') = 'asc';

  v_campos := coalesce(p_campos, array['item', 'nombre', 'referencia']);
  if cardinality(v_campos) = 0 then
    v_campos := array['item', 'nombre', 'referencia'];
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_full := regexp_replace(v_q, '\s+', ' ', 'g');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, r.refs, i.linea,
         case when a.estado_comercial is not null then s.nombre end,
         case when a.estado_comercial is not null
              then nullif(trim(coalesce(p.nombres, '') || ' ' || coalesce(p.apellidos, '')), '') end,
         a.estado_comercial, a.fecha_estado,
         a.respuesta_compras, a.fecha_respuesta, a.motivo_compras,
         a.cantidad_sugerida, a.notas, a.fecha_nota,
         case when a.estado_comercial is not null then 'Proceso activo' end,
         count(*) over()
  from public.items i
  join public.sedes s on s.id = v_sede
  left join public.agotados a on a.item_id = i.id_item and a.sede_id = v_sede
  left join public.profiles p on p.id = a.creado_por
  left join lateral (
    select string_agg(distinct ip.codigo_proveedor, ' / ' order by ip.codigo_proveedor) as refs
    from public.item_proveedor ip
    where ip.item_id = i.id_item and coalesce(ip.codigo_proveedor, '') <> ''
  ) r on true
  cross join lateral (
    select extensions.unaccent(lower(i.nombre_base)) as n,
           lower(coalesce(r.refs, '')) as rr
  ) z
  cross join lateral (
    select case
      when v_full = '' then 0
      when ('nombre' = any(v_campos) and z.n like v_full || '%' escape '\')
        or ('item' = any(v_campos) and lower(coalesce(i.codigo_erp, '')) like v_full escape '\')
        or ('referencia' = any(v_campos) and (' / ' || z.rr) like '% / ' || v_full || '%' escape '\')
        then 0
      else 1
    end as rk
  ) k
  -- Valor por el que se ordena, ya en el mismo formato que ve el usuario
  -- (por eso "sede", "usuario" y "seguimiento" solo existen con solicitud activa).
  -- Se separa por tipo porque un CASE no puede mezclar texto, número y fecha.
  cross join lateral (
    select
      case v_orden
        when 'item' then lpad(coalesce(i.codigo_erp, ''), 40, '0')
        when 'nombre' then i.nombre_base
        when 'referencia' then r.refs
        when 'linea' then i.linea
        when 'sede' then case when a.estado_comercial is not null then s.nombre end
        when 'usuario' then case when a.estado_comercial is not null
          then nullif(trim(coalesce(p.nombres, '') || ' ' || coalesce(p.apellidos, '')), '') end
        when 'solicitud' then a.estado_comercial
        when 'respuesta' then a.respuesta_compras
        when 'nota' then a.notas
        when 'seguimiento' then case when a.estado_comercial is not null then 'Proceso activo' end
      end as k_txt,
      case v_orden
        when 'cantidad' then a.cantidad_sugerida
      end as k_num,
      case v_orden
        when 'fecha_solicitud' then a.fecha_estado
        when 'fecha_respuesta' then a.fecha_respuesta
        when 'fecha_nota' then a.fecha_nota
      end as k_ts
  ) o
  where i.organizacion_id = p_org
    and not i.provisional
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    and (
      v_q = ''
      or (
        not exists (
          select 1 from unnest(v_terms) as t(term)
          where not (
            ('nombre' = any(v_campos) and z.n like '%' || t.term || '%' escape '\')
            or ('item' = any(v_campos) and lower(coalesce(i.codigo_erp, '')) like t.term escape '\')
            or ('referencia' = any(v_campos) and z.rr like '%' || t.term || '%' escape '\')
          )
        )
        and (p_modo <> 'solo_empieza' or k.rk = 0)
      )
    )
  order by
    case when v_asc then o.k_txt end asc nulls last,
    case when not v_asc then o.k_txt end desc nulls last,
    case when v_asc then o.k_num end asc nulls last,
    case when not v_asc then o.k_num end desc nulls last,
    case when v_asc then o.k_ts end asc nulls last,
    case when not v_asc then o.k_ts end desc nulls last,
    -- desempate (y orden completo cuando no se eligió columna): el de siempre
    case when p_modo = 'contiene' then 0 else k.rk end, i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_items_catalogo"("p_org" "uuid", "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "linea" "text", "unidad_medida" "text", "provisional" boolean, "cantidad_sugerida" numeric, "agotado_sedes" "text"[], "en_gestion" boolean, "proveedores" "jsonb", "ultima_orden_numero" "text", "ultima_orden_fecha" timestamp with time zone, "ultima_orden_cantidad" numeric, "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare v_q text; v_terms text[]; v_filtrado boolean;
begin
  perform public._pedidos_check(p_org, 'ver');

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;
  v_filtrado := coalesce(p_linea, '') <> '' or v_q <> '';

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, i.unidad_medida, i.provisional,
         ag.cant, ag.sedes,
         exists (
           select 1 from public.solicitud_items si
           join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
           where sc.organizacion_id = p_org and si.item_id = i.id_item and si.estado = 'activo'),
         coalesce(pv.lista, '[]'::jsonb),
         uo.numero, uo.fecha, uo.cantidad,
         count(*) over()
  from public.items i
  left join lateral (
    select sum(a.cantidad_sugerida) as cant, count(*) as n,
           array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  left join lateral (
    select jsonb_agg(jsonb_build_object(
             'proveedor_id', prv.id, 'proveedor', prv.nombre,
             'codigo', ip.refs, 'precio_erp', ip.precio, 'dias', ip.dias,
             'preferido', ip.pref, 'unidades_por_caja', ip.upc,
             'ya_en_solicitud', exists (
               select 1 from public.solicitud_items si
               join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
               where sc.organizacion_id = p_org and sc.proveedor_id = prv.id
                 and sc.estado <> 'cerrada' and si.item_id = i.id_item and si.estado = 'activo'))
           order by ip.pref desc, prv.nombre) as lista,
           lower(coalesce(string_agg(ip.refs, ' '), '')) as refs
    from (
      select x.proveedor_id,
             string_agg(distinct x.codigo_proveedor, ' / ')
               filter (where coalesce(x.codigo_proveedor, '') <> '') as refs,
             max(x.precio_unitario) as precio,
             max(x.tiempo_entrega_dias) as dias,
             bool_or(x.proveedor_preferido) as pref,
             max(x.unidades_por_caja) as upc
      from public.item_proveedor x
      where x.item_id = i.id_item
      group by x.proveedor_id
    ) ip
    join public.proveedores prv on prv.id = ip.proveedor_id
  ) pv on true
  left join lateral (
    select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') as numero, oc.fecha, oi.cantidad
    from public.orden_items oi
    join public.ordenes_compra oc on oc.id = oi.orden_id
    where oi.item_id = i.id_item and oc.organizacion_id = p_org
    order by oc.fecha desc
    limit 1
  ) uo on true
  where i.organizacion_id = p_org
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    and (v_filtrado or ag.n > 0)
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
        or coalesce(pv.refs, '') like '%' || t.term || '%' escape '\'
      )
    )
  order by (ag.n > 0) desc, i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_items_proveedor"("p_org" "uuid", "p_proveedor" bigint, "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_catalogo" boolean DEFAULT false) RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "linea" "text", "referencia" "text", "unidades_por_caja" integer, "cantidad_sugerida" numeric, "ya_en_solicitud" boolean, "vinculado" boolean, "provisional" boolean, "precio_erp" numeric, "dias_entrega" integer, "agotado_sedes" "text"[], "ultima_orden_numero" "text", "ultima_orden_fecha" timestamp with time zone, "ultima_orden_cantidad" numeric)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._pedidos_check(p_org, 'ver');
  if not exists (select 1 from public.proveedores where id = p_proveedor and organizacion_id = p_org) then
    raise exception 'Proveedor no válido';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;
  if p_catalogo and v_q = '' then
    raise exception 'Escribe algo para buscar en el catálogo';
  end if;

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, ip.refs, ip.upc, ag.cant,
         exists (
           select 1 from public.solicitud_items si
           join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
           where sc.organizacion_id = p_org and sc.proveedor_id = p_proveedor
             and sc.estado <> 'cerrada' and si.item_id = i.id_item and si.estado = 'activo'),
         (ip.n > 0), i.provisional, ip.precio, ip.dias, ag.sedes,
         uo.numero, uo.fecha, uo.cantidad
  from public.items i
  left join lateral (
    select string_agg(distinct x.codigo_proveedor, ' / ')
             filter (where coalesce(x.codigo_proveedor, '') <> '') as refs,
           max(x.unidades_por_caja) as upc,
           max(x.precio_unitario) as precio,
           max(x.tiempo_entrega_dias) as dias,
           count(*) as n
    from public.item_proveedor x
    where x.item_id = i.id_item and x.proveedor_id = p_proveedor
  ) ip on true
  left join lateral (
    select sum(a.cantidad_sugerida) as cant, count(*) as n,
           array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  left join lateral (
    select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') as numero, oc.fecha, oi.cantidad
    from public.orden_items oi
    join public.ordenes_compra oc on oc.id = oi.orden_id
    where oi.item_id = i.id_item and oc.organizacion_id = p_org
    order by oc.fecha desc
    limit 1
  ) uo on true
  where i.organizacion_id = p_org
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    and (p_catalogo or ip.n > 0)
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
        or lower(coalesce(ip.refs, '')) like '%' || t.term || '%' escape '\'
      )
    )
  order by (ag.n > 0) desc, i.nombre_base, i.id_item
  limit case when p_catalogo then 100 else 1000 end;
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_pedidos"("p_org" "uuid", "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_estado" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "linea" "text", "unidad_medida" "text", "iva" numeric, "cantidad_sugerida" numeric, "sedes" "jsonb", "estado" "text", "cotizaciones_recibidas" integer, "cotizaciones_esperadas" integer, "mejor_costo" numeric, "mejor_proveedor" "text", "proveedor_elegido" "text", "proveedores" "jsonb", "fecha_estado" timestamp with time zone, "origen" "text", "provisional" boolean, "ultima_orden_numero" "text", "ultima_orden_fecha" timestamp with time zone, "ultima_orden_cantidad" numeric, "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._pedidos_check(p_org, 'ver');
  if coalesce(p_estado, '') not in ('', 'por_cotizar', 'en_cotizacion', 'cotizado',
       'pedido_solicitado', 'agotado_proveedor', 'repartir_sedes', 'no_se_pide') then
    raise exception 'Filtro de estado no válido';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  with ag as (
    -- lado agotados (igual que antes)
    select a.item_id,
           sum(a.cantidad_sugerida) as cant,
           min(a.fecha_estado) as f_estado,
           bool_or(a.respuesta_compras is null) as pendiente,
           bool_or(a.respuesta_compras = 'pedido_solicitado') as r_ped,
           bool_or(a.respuesta_compras = 'repartir_sedes') as r_rep,
           bool_or(a.respuesta_compras = 'no_se_pide') as r_no,
           jsonb_agg(jsonb_build_object(
             'sede_id', a.sede_id, 'sede', s.nombre,
             'cantidad_sugerida', a.cantidad_sugerida, 'notas', a.notas,
             'usuario', nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), ''),
             'fecha', a.fecha_estado, 'respuesta_compras', a.respuesta_compras,
             'motivo_compras', a.motivo_compras)
             order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    left join public.profiles pu on pu.id = a.creado_por
    where a.organizacion_id = p_org and a.estado_comercial is not null
    group by a.item_id
  ),
  man as (
    -- lado Compras: ítems con una solicitud activa (existan o no agotados)
    select si.item_id, min(sc.fecha_creacion) as f_estado
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
    where sc.organizacion_id = p_org and si.estado = 'activo'
    group by si.item_id
  ),
  base as (
    select coalesce(ag.item_id, man.item_id) as item_id,
           ag.cant,
           coalesce(ag.f_estado, man.f_estado) as f_estado,
           coalesce(ag.pendiente, true) as pendiente,
           coalesce(ag.r_ped, false) as r_ped,
           coalesce(ag.r_rep, false) as r_rep,
           coalesce(ag.r_no, false) as r_no,
           coalesce(ag.sedes, '[]'::jsonb) as sedes,
           (ag.item_id is not null) as con_agotado
    from ag
    full join man on man.item_id = ag.item_id
  ),
  cot as (
    select si.item_id,
           count(*)::int as esperadas,
           (count(*) filter (where cp.fecha_respuesta is not null))::int as recibidas,
           coalesce(bool_or(cp.seleccionado), false) as hay_ganador
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
    join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
    where si.estado = 'activo'
    group by si.item_id
  ),
  x as (
    select b.item_id, i.codigo_erp as codigo, i.nombre_base, i.linea, i.unidad_medida, i.iva,
           b.cant, b.sedes, b.f_estado,
           case
             when b.pendiente then
               case when coalesce(c.esperadas, 0) = 0 then 'por_cotizar'
                    when c.hay_ganador then 'cotizado'
                    else 'en_cotizacion' end
             when b.r_ped then 'pedido_solicitado'
             when b.r_rep then 'repartir_sedes'
             when b.r_no then 'no_se_pide'
             else 'agotado_proveedor'
           end as est,
           coalesce(c.recibidas, 0) as rec,
           coalesce(c.esperadas, 0) as esp,
           mj.costo, mj.prov, el.prov as elegido,
           coalesce(pv.lista, '[]'::jsonb) as lista,
           case when b.con_agotado then 'agotado' else 'manual' end as origen,
           i.provisional,
           uo.numero as uo_num, uo.fecha as uo_fecha, uo.cantidad as uo_cant
    from base b
    join public.items i on i.id_item = b.item_id and i.organizacion_id = p_org
    left join cot c on c.item_id = b.item_id
    left join lateral (
      select cp.costo_unitario as costo, prv.nombre as prov
      from public.solicitud_items si
      join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
      join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
      join public.proveedores prv on prv.id = cp.proveedor_id
      where si.item_id = b.item_id and si.estado = 'activo'
        and cp.disponible is true and cp.costo_unitario is not null
      order by cp.costo_unitario
      limit 1
    ) mj on true
    left join lateral (
      select prv.nombre as prov
      from public.solicitud_items si
      join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
      join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
      join public.proveedores prv on prv.id = cp.proveedor_id
      where si.item_id = b.item_id and si.estado = 'activo' and cp.seleccionado
      limit 1
    ) el on true
    left join lateral (
      select jsonb_agg(jsonb_build_object(
               'proveedor_id', prv.id, 'proveedor', prv.nombre,
               'codigo', ip.codigo_proveedor, 'precio_erp', ip.precio_unitario,
               'dias', ip.tiempo_entrega_dias, 'preferido', ip.proveedor_preferido,
               'unidades_por_caja', ip.unidades_por_caja)
             order by ip.proveedor_preferido desc, prv.nombre) as lista,
             lower(coalesce(string_agg(ip.codigo_proveedor, ' '), '')) as refs
      from public.item_proveedor ip
      join public.proveedores prv on prv.id = ip.proveedor_id
      where ip.item_id = b.item_id
    ) pv on true
    left join lateral (
      -- última orden del ítem (cualquier proveedor): ayuda a no pedir dos veces lo mismo
      select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') as numero, oc.fecha, oi.cantidad
      from public.orden_items oi
      join public.ordenes_compra oc on oc.id = oi.orden_id
      where oi.item_id = b.item_id and oc.organizacion_id = p_org
      order by oc.fecha desc
      limit 1
    ) uo on true
    where (coalesce(p_linea, '') = '' or i.linea = p_linea)
      and not exists (
        select 1 from unnest(v_terms) as t(term)
        where not (
          extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
          or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
          or coalesce(pv.refs, '') like '%' || t.term || '%' escape '\'
        )
      )
  )
  select x.item_id, x.codigo, x.nombre_base, x.linea, x.unidad_medida, x.iva,
         x.cant, x.sedes, x.est, x.rec, x.esp,
         x.costo, x.prov, x.elegido, x.lista, x.f_estado,
         x.origen, x.provisional, x.uo_num, x.uo_fecha, x.uo_cant,
         count(*) over()
  from x
  where coalesce(p_estado, '') = '' or x.est = p_estado
  order by case x.est when 'por_cotizar' then 0 when 'en_cotizacion' then 1
                      when 'cotizado' then 2 when 'agotado_proveedor' then 3
                      when 'repartir_sedes' then 4 when 'no_se_pide' then 5
                      else 6 end,
           x.f_estado, x.nombre_base
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."matriz_cotizaciones"("p_org" "uuid", "p_linea" "text" DEFAULT NULL::"text", "p_busqueda" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("item_id" bigint, "codigo" "text", "nombre_base" "text", "linea" "text", "unidad_medida" "text", "iva" numeric, "provisional" boolean, "origen" "text", "cantidad_a_cotizar" numeric, "agotado_sedes" "text"[], "cotizaciones" "jsonb", "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._pedidos_check(p_org, 'ver');

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, i.unidad_medida, i.iva, i.provisional,
         g.origen, g.cant, ag.sedes, g.cots, count(*) over()
  from public.items i
  join lateral (
    select (array_agg(si.origen order by sc.fecha_creacion))[1] as origen,
           max(si.cantidad_a_cotizar) as cant,
           jsonb_agg(jsonb_build_object(
             'cotizacion_id', cp.id, 'proveedor_id', cp.proveedor_id, 'proveedor', pv.nombre,
             'solicitud_numero', 'SC-' || lpad(coalesce(sc.numero, 0)::text, 4, '0'),
             'solicitud_estado', sc.estado,
             'costo_unitario', cp.costo_unitario, 'costo_con_iva', cp.costo_con_iva,
             'iva', coalesce(cp.iva, i.iva, 0),
             'disponible', cp.disponible, 'dias_entrega', cp.dias_entrega, 'flete', cp.flete,
             'unidades_por_caja', cp.unidades_por_caja, 'observacion', cp.observacion,
             'fecha_respuesta', cp.fecha_respuesta, 'seleccionado', cp.seleccionado,
             'cantidad_pedir', cp.cantidad_pedir,
             'precio_erp', ip.precio, 'referencia', ip.refs)
             order by pv.nombre, sc.fecha_creacion) as cots
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
    join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
    join public.proveedores pv on pv.id = cp.proveedor_id
    left join lateral (
      select max(x.precio_unitario) as precio,
             string_agg(distinct x.codigo_proveedor, ' / ')
               filter (where coalesce(x.codigo_proveedor, '') <> '') as refs
      from public.item_proveedor x
      where x.item_id = si.item_id and x.proveedor_id = cp.proveedor_id
    ) ip on true
    where si.item_id = i.id_item and si.estado = 'activo'
  ) g on true
  left join lateral (
    select array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  where i.organizacion_id = p_org
    and g.cots is not null
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
      )
    )
  order by i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_ordenes_por_generar"("p_org" "uuid") RETURNS TABLE("proveedor_id" bigint, "proveedor" "text", "items" integer, "total_con_iva" numeric, "lineas" "jsonb")
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
begin
  perform public._pedidos_check(p_org, 'ver');
  return query
  select pv.id, pv.nombre, count(*)::int,
         sum(cp.cantidad_pedir * cp.costo_con_iva),
         jsonb_agg(jsonb_build_object(
           'cotizacion_id', cp.id, 'item_id', si.item_id, 'codigo', i.codigo_erp,
           'nombre_base', i.nombre_base, 'linea', i.linea, 'referencia', r.refs,
           'cantidad', cp.cantidad_pedir, 'unidades_por_caja', cp.unidades_por_caja,
           'cajas', case when cp.unidades_por_caja is not null
                         then ceil(cp.cantidad_pedir / cp.unidades_por_caja) end,
           'costo_unitario', cp.costo_unitario, 'costo_con_iva', cp.costo_con_iva,
           'flete', cp.flete)
           order by i.nombre_base)
  from public.cotizacion_precios cp
  join public.solicitud_items si on si.id = cp.solicitud_item_id
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
  join public.items i on i.id_item = si.item_id
  join public.proveedores pv on pv.id = cp.proveedor_id
  left join lateral (
    select string_agg(distinct ip.codigo_proveedor, ' / ') as refs
    from public.item_proveedor ip
    where ip.item_id = si.item_id and ip.proveedor_id = cp.proveedor_id
      and coalesce(ip.codigo_proveedor, '') <> ''
  ) r on true
  where sc.organizacion_id = p_org and cp.seleccionado and si.estado = 'activo'
  group by pv.id, pv.nombre
  order by pv.nombre;
end $$;

CREATE OR REPLACE FUNCTION "public"."listar_ordenes_compra"("p_org" "uuid", "p_proveedor" bigint DEFAULT NULL::bigint, "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("id" "uuid", "numero" integer, "numero_texto" "text", "proveedor_id" bigint, "proveedor" "text", "sede" "text", "fecha" timestamp with time zone, "total_oc" numeric, "creado_por" "text", "items" "jsonb", "total" bigint)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
#variable_conflict use_column
begin
  perform public._pedidos_check(p_org, 'ver');
  return query
  select oc.id, oc.numero, 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0'),
         oc.proveedor_id, pv.nombre, s.nombre, oc.fecha, oc.total,
         nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), ''),
         coalesce(it.lista, '[]'::jsonb), count(*) over()
  from public.ordenes_compra oc
  join public.proveedores pv on pv.id = oc.proveedor_id
  left join public.sedes s on s.id = oc.sede_id
  left join public.profiles pu on pu.id = oc.creado_por
  left join lateral (
    select jsonb_agg(jsonb_build_object(
             'item_id', oi.item_id, 'codigo', i.codigo_erp, 'nombre_base', i.nombre_base, 'linea', i.linea,
             'cantidad', oi.cantidad, 'unidades_por_caja', cp.unidades_por_caja,
             'costo_unitario', oi.precio_unitario_acordado, 'costo_con_iva', cp.costo_con_iva)
           order by i.nombre_base) as lista
    from public.orden_items oi
    join public.items i on i.id_item = oi.item_id
    left join public.cotizacion_precios cp on cp.id = oi.cotizacion_precio_id
    where oi.orden_id = oc.id
  ) it on true
  where oc.organizacion_id = p_org
    and (p_proveedor is null or oc.proveedor_id = p_proveedor)
  order by oc.fecha desc
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

CREATE OR REPLACE FUNCTION "public"."solicitud_texto"("p_org" "uuid", "p_solicitud" "uuid") RETURNS "text"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
declare v_num integer; v_prov text; v_prov_id bigint; v_fecha timestamptz; v_lineas text;
begin
  perform public._pedidos_check(p_org, 'ver');
  select sc.numero, pv.nombre, sc.proveedor_id, sc.fecha_creacion
    into v_num, v_prov, v_prov_id, v_fecha
  from public.solicitudes_cotizacion sc
  left join public.proveedores pv on pv.id = sc.proveedor_id
  where sc.id = p_solicitud and sc.organizacion_id = p_org;
  if not found then raise exception 'Solicitud no encontrada'; end if;

  select coalesce(string_agg(l.n::text || '. ' || l.txt, E'\n' order by l.n), '') into v_lineas
  from (
    select row_number() over (order by i.nombre_base, i.id_item) as n,
           '[' || coalesce(i.codigo_erp, 'P' || abs(i.id_item)::text) || '] ' || i.nombre_base
             || ' | Línea: ' || coalesce(i.linea, '-')
             || ' | Ref: ' || coalesce(r.refs, '-')
             || ' | Cant: ' || coalesce(trim_scale(si.cantidad_a_cotizar)::text, '-')
             || ' ' || coalesce(i.unidad_medida, '') as txt
    from public.solicitud_items si
    join public.items i on i.id_item = si.item_id
    left join lateral (
      select string_agg(distinct ip.codigo_proveedor, ' / ') as refs
      from public.item_proveedor ip
      where ip.item_id = si.item_id and ip.proveedor_id = v_prov_id
        and coalesce(ip.codigo_proveedor, '') <> ''
    ) r on true
    where si.solicitud_id = p_solicitud and si.estado = 'activo'
  ) l;

  return 'SOLICITUD DE COTIZACIÓN SC-' || lpad(coalesce(v_num, 0)::text, 4, '0')
    || E'\nProveedor: ' || coalesce(v_prov, '-')
    || E'\nFecha: ' || to_char(v_fecha at time zone 'America/Bogota', 'DD/MM/YYYY')
    || E'\n\nAgradecemos cotizar (costo unitario antes de IVA, disponibilidad, tiempo de entrega y flete):\n'
    || v_lineas;
end $$;


drop function if exists public.item_provisional_vincular(uuid, bigint, bigint);

CREATE OR REPLACE FUNCTION "public"."item_provisional_vincular"("p_org" "uuid", "p_provisional" bigint, "p_codigo" "text") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $$
declare v_prov public.items; v_codigo text; v_real bigint;
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if not public.tiene_permiso(p_org, 'Items', 'editar') then
    raise exception 'Sin permiso para editar ítems';
  end if;
  v_codigo := public._item_codigo_limpiar(p_codigo);

  select * into v_prov from public.items
  where id_item = p_provisional and organizacion_id = p_org and provisional
  for update;
  if v_prov.id_item is null then raise exception 'Ítem provisional no encontrado'; end if;

  -- un provisional nunca debería tener esto (las sedes no lo ven); si lo tiene, que lo revise una persona
  if exists (select 1 from public.agotados where item_id = p_provisional)
     or exists (select 1 from public.inventario where item_id = p_provisional)
     or exists (select 1 from public.variantes where item_id = p_provisional) then
    raise exception 'El ítem provisional tiene agotados, inventario o variantes: revísalo antes de vincular';
  end if;

  -- ¿ya existe el ítem real con ese código en ESTA organización? entonces se fusiona con él
  select i.id_item into v_real from public.items i
  where i.organizacion_id = p_org and not i.provisional and lower(btrim(i.codigo_erp)) = lower(v_codigo);

  -- evita violar solicitud_items_activo_uk (solicitud_id, item_id) al fusionar
  if v_real is not null and exists (
    select 1
    from public.solicitud_items a
    join public.solicitud_items b
      on b.solicitud_id = a.solicitud_id and b.item_id = v_real and b.estado = 'activo'
    where a.item_id = p_provisional and a.estado = 'activo'
  ) then
    raise exception 'Una solicitud abierta contiene a la vez el ítem provisional y el real: ciérrala o quita uno antes de vincular';
  end if;

  if v_real is null then
    v_real := nextval('public.items_id_seq');
    insert into public.items (
      id_item, organizacion_id, codigo_erp, nombre_base, descripcion_2, unidad_medida, categoria,
      grupo_contable, grupo, codigo_linea, linea, iva, estado, notas, marca,
      informacion_tecnica, aplicacion_tecnica, activo, provisional)
    select v_real, organizacion_id, v_codigo, nombre_base, descripcion_2, unidad_medida, categoria,
           grupo_contable, grupo, codigo_linea, linea, iva, estado, notas, marca,
           informacion_tecnica, aplicacion_tecnica, activo, false
    from public.items where id_item = p_provisional;
  end if;

  -- item_proveedor: si el real ya tiene al mismo proveedor, se completan sus vacíos y se descarta la fila provisional
  update public.item_proveedor t set
    codigo_proveedor = coalesce(nullif(t.codigo_proveedor, ''), s.codigo_proveedor),
    precio_unitario = coalesce(t.precio_unitario, s.precio_unitario),
    tiempo_entrega_dias = coalesce(t.tiempo_entrega_dias, s.tiempo_entrega_dias),
    unidades_por_caja = coalesce(t.unidades_por_caja, s.unidades_por_caja)
  from public.item_proveedor s
  where s.item_id = p_provisional and t.item_id = v_real
    and t.proveedor_id = s.proveedor_id and t.variante_id is not distinct from s.variante_id;

  delete from public.item_proveedor s
  using public.item_proveedor t
  where s.item_id = p_provisional and t.item_id = v_real
    and t.proveedor_id = s.proveedor_id and t.variante_id is not distinct from s.variante_id;

  update public.item_proveedor set item_id = v_real where item_id = p_provisional;
  update public.solicitud_items set item_id = v_real where item_id = p_provisional;
  update public.orden_items set item_id = v_real where item_id = p_provisional;

  delete from public.items where id_item = p_provisional;
  return v_real;
end $$;

revoke all on function public.listar_agotados(uuid, text, text, integer, integer, text, text[], text, text) from public, anon;
grant execute on function public.listar_agotados(uuid, text, text, integer, integer, text, text[], text, text) to authenticated, service_role;
revoke all on function public.listar_items_catalogo(uuid, text, text, integer, integer) from public, anon;
grant execute on function public.listar_items_catalogo(uuid, text, text, integer, integer) to authenticated, service_role;
revoke all on function public.listar_items_proveedor(uuid, bigint, text, text, boolean) from public, anon;
grant execute on function public.listar_items_proveedor(uuid, bigint, text, text, boolean) to authenticated, service_role;
revoke all on function public.listar_pedidos(uuid, text, text, text, integer, integer) from public, anon;
grant execute on function public.listar_pedidos(uuid, text, text, text, integer, integer) to authenticated, service_role;
revoke all on function public.matriz_cotizaciones(uuid, text, text, integer, integer) from public, anon;
grant execute on function public.matriz_cotizaciones(uuid, text, text, integer, integer) to authenticated, service_role;
revoke all on function public.item_provisional_vincular(uuid, bigint, text) from public, anon;
grant execute on function public.item_provisional_vincular(uuid, bigint, text) to authenticated, service_role;
