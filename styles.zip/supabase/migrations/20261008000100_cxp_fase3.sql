-- Cuentas por pagar (CXP) · Fase 3: cruce de pendientes manuales con el ERP, filtro por proveedor completo,
-- "última carga" y documentos que no vinieron, tramos de antigüedad. Requiere Fases 1 y 2. Idempotente.
begin;

-- 1. Estado 'cruzado' y trazabilidad ------------------------------------------------------------------------
-- Un pendiente manual "cruzado" ya está representado por el documento del ERP: deja de sumar en todas las listas.
do $do$
declare c record;
begin
  -- Quita la restricción anterior de "estado" (pendiente/pagado) sin depender de su nombre.
  for c in
    select conname from pg_constraint
     where conrelid = 'public.cxp_documentos'::regclass and contype = 'c'
       and pg_get_constraintdef(oid) like '%''pendiente''%' and pg_get_constraintdef(oid) not like '%''cruzado''%'
  loop
    execute format('alter table public.cxp_documentos drop constraint %I', c.conname);
  end loop;
end $do$;
alter table public.cxp_documentos drop constraint if exists cxp_documentos_estado_check;
alter table public.cxp_documentos
  add constraint cxp_documentos_estado_check check (estado in ('pendiente', 'pagado', 'cruzado'));

alter table public.cxp_documentos
  add column if not exists cruzado_con uuid references public.cxp_documentos(id) on delete set null,
  add column if not exists fecha_cruce timestamptz,
  add column if not exists cruzado_por uuid references public.profiles(id),
  add column if not exists visto_en uuid references public.cxp_importaciones(id) on delete set null;

alter table public.cxp_documentos drop constraint if exists cxp_cruce_chk;
alter table public.cxp_documentos
  add constraint cxp_cruce_chk check ((estado = 'cruzado') = (cruzado_con is not null));

-- Un manual pagado que luego se cruza conserva su fecha de pago: basta con que "pagado" tenga fecha.
alter table public.cxp_documentos drop constraint if exists cxp_pago_chk;
alter table public.cxp_documentos
  add constraint cxp_pago_chk check (estado <> 'pagado' or fecha_pago is not null);

create index if not exists cxp_documentos_visto_idx on public.cxp_documentos (visto_en) where visto_en is not null;

-- El historial no debe llenarse con "visto en la carga X" en cada carga: el trigger solo mira las demás columnas.
drop trigger if exists trg_auditar_cxp_documentos on public.cxp_documentos;
create trigger trg_auditar_cxp_documentos
  after insert or delete or update of
    organizacion_id, origen, empresa, tercero, nombre, cond_pago, docto_proveedor, fecha_dcto, fecha_vcto, plazo,
    documento_erp, co_codigo, sede_id, detalle_erp, erp_raw, total_factura, anticipos, descuentos, retenciones,
    detalles, estado, fecha_pago, pagado_por, regla_id, cruzado_con, fecha_cruce, cruzado_por
  on public.cxp_documentos
  for each row execute function public.auditar_cambio();

-- Lo que ya está en la cartera se considera visto en la última carga de su organización (punto de partida).
update public.cxp_documentos d
   set visto_en = u.id
  from (select distinct on (organizacion_id) organizacion_id, id
          from public.cxp_importaciones order by organizacion_id, created_at desc) u
 where d.organizacion_id = u.organizacion_id and d.origen = 'erp' and d.estado = 'pendiente' and d.visto_en is null;

-- 2. Filtro común: proveedor completo y "no vino en la última carga" -------------------------------------
create or replace function public._cxp_filtrar(
  p_org uuid, p_estado text, p_busqueda text, p_tercero text, p_nombre text, p_sede uuid, p_origen text
) returns setof public.cxp_documentos
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_q text; v_terms text[]; v_ult uuid; v_t text := nullif(upper(btrim(p_tercero)), '');
begin
  if p_estado is null or p_estado not in ('pendiente', 'excluido', 'pagado') then raise exception 'Estado no válido'; end if;
  if p_estado = 'pagado' then
    perform public._exigir_permiso(p_org, 'cxp_pagos', 'ver');
  else
    perform public._exigir_permiso(p_org, 'cxp', 'ver');
  end if;
  if coalesce(p_origen, '') not in ('', 'erp', 'manual', 'ausente') then raise exception 'Origen no válido'; end if;
  if p_sede is not null and not exists (select 1 from public.sedes where id = p_sede and organizacion_id = p_org) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  select i.id into v_ult from public.cxp_importaciones i
   where i.organizacion_id = p_org order by i.created_at desc limit 1;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select d.*
  from public.cxp_documentos d
  where d.organizacion_id = p_org
    and case p_estado
          when 'pagado'   then d.estado = 'pagado'
          when 'excluido' then d.estado = 'pendiente' and d.regla_id is not null
          else                 d.estado = 'pendiente' and d.regla_id is null end
    and (coalesce(p_origen, '') = ''
         or (p_origen in ('erp', 'manual') and d.origen = p_origen)
         or (p_origen = 'ausente' and d.origen = 'erp' and v_ult is not null and d.visto_en is distinct from v_ult))
    and (p_sede is null or d.sede_id = p_sede)
    -- Por NIT; también los pendientes escritos a mano SIN NIT cuyo nombre coincide con el de ese NIT
    and (v_t is null or d.tercero = v_t
         or (d.tercero is null and exists (
               select 1 from public.cxp_documentos o
                where o.organizacion_id = p_org and o.tercero = v_t
                  and lower(btrim(o.nombre)) = lower(btrim(d.nombre)))))
    and (nullif(btrim(p_nombre), '') is null or lower(btrim(d.nombre)) = lower(btrim(p_nombre)))
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(d.nombre)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.tercero, '')) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.docto_proveedor, '')) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.documento_erp, '')) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(coalesce(d.detalle_erp, '') || ' ' || coalesce(d.detalles, ''))) like '%' || t.term || '%' escape '\'
      )
    );
end $fn$;

-- Lista de proveedores del filtro: un pendiente manual sin NIT se agrupa con el proveedor del mismo nombre.
create or replace function public.cxp_proveedores_filtro(p_org uuid, p_estado text default 'pendiente')
returns table (tercero text, nombre text, documentos integer)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
begin
  if p_estado is null or p_estado not in ('pendiente', 'excluido', 'pagado') then raise exception 'Estado no válido'; end if;
  if p_estado = 'pagado' then
    perform public._exigir_permiso(p_org, 'cxp_pagos', 'ver');
  else
    perform public._exigir_permiso(p_org, 'cxp', 'ver');
  end if;
  return query
  with b as (
    select coalesce(d.tercero, x.t) as t, d.nombre, d.updated_at
    from public.cxp_documentos d
    left join lateral (
      select min(o.tercero) as t
      from public.cxp_documentos o
      where d.tercero is null and o.organizacion_id = p_org and o.tercero is not null
        and lower(btrim(o.nombre)) = lower(btrim(d.nombre))
    ) x on true
    where d.organizacion_id = p_org
      and case p_estado
            when 'pagado'   then d.estado = 'pagado'
            when 'excluido' then d.estado = 'pendiente' and d.regla_id is not null
            else                 d.estado = 'pendiente' and d.regla_id is null end
  )
  select b.t, (array_agg(b.nombre order by b.updated_at desc))[1], count(*)::int
  from b
  group by coalesce(b.t, 'n:' || lower(btrim(b.nombre))), b.t
  order by 2;
end $fn$;

-- 3. Listado (con "no vino en la última carga" y tramos) y totales por tramos --------------------------------
drop function if exists public.cxp_listar(uuid, text, text, text, text, uuid, text, text, text, text, integer, integer);
create function public.cxp_listar(
  p_org uuid,
  p_estado text default 'pendiente',
  p_busqueda text default null,
  p_tercero text default null,
  p_nombre text default null,
  p_sede uuid default null,
  p_origen text default null,
  p_vencimiento text default null,
  p_orden text default null,
  p_dir text default 'asc',
  p_limit integer default 50,
  p_offset integer default 0
) returns table (
  id uuid, origen text, empresa text, tercero text, nombre text, cond_pago text,
  docto_proveedor text, documento_erp text, fecha_dcto date, fecha_vcto date, plazo integer,
  dias_venc integer, vencido boolean, sede text, anticipos numeric, descuentos numeric,
  retenciones numeric, total_factura numeric, val_pagar numeric, detalles text, estado text,
  fecha_pago timestamptz, pagado_por text,
  detalle_erp text, regla_id uuid, regla_tipo text, contexto text, nota_regla text,
  ausente boolean,
  total bigint
)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare
  v_hoy date := public._cxp_hoy();
  v_orden text := nullif(trim(p_orden), '');
  v_asc boolean;
  v_ult uuid;
begin
  if coalesce(p_vencimiento, '') not in ('', 'vencidos', 'por_vencer', '1_30', '31_60', '61_90', 'mas_90') then
    raise exception 'Filtro de vencimiento no válido';
  end if;
  if v_orden is not null and v_orden not in
     ('nombre', 'tercero', 'fecha_dcto', 'fecha_vcto', 'dias_venc', 'val_pagar', 'total_factura', 'fecha_pago') then
    raise exception 'Columna de orden no válida';
  end if;
  if coalesce(p_dir, 'asc') not in ('asc', 'desc') then raise exception 'Dirección de orden no válida'; end if;
  if v_orden is null then
    v_orden := case when p_estado = 'pagado' then 'fecha_pago' else 'fecha_vcto' end;
    v_asc := p_estado <> 'pagado';
  else
    v_asc := coalesce(p_dir, 'asc') = 'asc';
  end if;

  select i.id into v_ult from public.cxp_importaciones i
   where i.organizacion_id = p_org order by i.created_at desc limit 1;

  return query
  with b as (
    select d.id, d.origen, d.empresa, d.tercero, d.nombre, d.cond_pago, d.docto_proveedor,
           d.documento_erp, d.fecha_dcto, d.fecha_vcto, d.plazo,
           greatest(0, v_hoy - d.fecha_vcto) as dias,
           (d.fecha_vcto is not null and d.fecha_vcto < v_hoy) as venc,
           s.nombre as sede_nombre, d.anticipos, d.descuentos, d.retenciones, d.total_factura,
           d.val_pagar, d.detalles, d.estado, d.fecha_pago,
           nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), '') as pagador,
           d.detalle_erp, d.regla_id, rg.tipo as r_tipo, rg.contexto as r_contexto, rg.nota as r_nota,
           (d.origen = 'erp' and d.estado = 'pendiente' and v_ult is not null and d.visto_en is distinct from v_ult) as aus
    from public._cxp_filtrar(p_org, p_estado, p_busqueda, p_tercero, p_nombre, p_sede, p_origen) d
    left join public.sedes s on s.id = d.sede_id
    left join public.profiles pu on pu.id = d.pagado_por
    left join public.cxp_reglas rg on rg.id = d.regla_id
  )
  select b.id, b.origen, b.empresa, b.tercero, b.nombre, b.cond_pago, b.docto_proveedor,
         b.documento_erp, b.fecha_dcto, b.fecha_vcto, b.plazo, b.dias, b.venc, b.sede_nombre,
         b.anticipos, b.descuentos, b.retenciones, b.total_factura, b.val_pagar, b.detalles,
         b.estado, b.fecha_pago, b.pagador,
         b.detalle_erp, b.regla_id, b.r_tipo, b.r_contexto, b.r_nota,
         b.aus,
         count(*) over()
  from b
  where case coalesce(p_vencimiento, '')
          when 'vencidos'   then b.venc
          when 'por_vencer' then not b.venc
          when '1_30'       then b.dias between 1 and 30
          when '31_60'      then b.dias between 31 and 60
          when '61_90'      then b.dias between 61 and 90
          when 'mas_90'     then b.dias > 90
          else true end
  order by
    case when v_asc then (case v_orden when 'nombre' then lower(b.nombre) when 'tercero' then b.tercero end) end asc nulls last,
    case when not v_asc then (case v_orden when 'nombre' then lower(b.nombre) when 'tercero' then b.tercero end) end desc nulls last,
    case when v_asc then (case v_orden when 'dias_venc' then b.dias::numeric when 'val_pagar' then b.val_pagar
                                       when 'total_factura' then b.total_factura end) end asc nulls last,
    case when not v_asc then (case v_orden when 'dias_venc' then b.dias::numeric when 'val_pagar' then b.val_pagar
                                           when 'total_factura' then b.total_factura end) end desc nulls last,
    case when v_asc then (case v_orden when 'fecha_dcto' then b.fecha_dcto::timestamptz
                                       when 'fecha_vcto' then b.fecha_vcto::timestamptz
                                       when 'fecha_pago' then b.fecha_pago end) end asc nulls last,
    case when not v_asc then (case v_orden when 'fecha_dcto' then b.fecha_dcto::timestamptz
                                           when 'fecha_vcto' then b.fecha_vcto::timestamptz
                                           when 'fecha_pago' then b.fecha_pago end) end desc nulls last,
    lower(b.nombre), b.id
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $fn$;

-- Totales con los mismos filtros del listado, SIN el de vencimiento: así siempre se ven todos los tramos.
drop function if exists public.cxp_totales(uuid, text, text, text, text, uuid, text);
create function public.cxp_totales(
  p_org uuid,
  p_estado text default 'pendiente',
  p_busqueda text default null,
  p_tercero text default null,
  p_nombre text default null,
  p_sede uuid default null,
  p_origen text default null
) returns table (
  suma_total numeric, suma_vencido numeric, suma_por_vencer numeric,
  suma_1_30 numeric, suma_31_60 numeric, suma_61_90 numeric, suma_mas_90 numeric,
  n_total bigint, n_vencido bigint, n_por_vencer bigint,
  n_1_30 bigint, n_31_60 bigint, n_61_90 bigint, n_mas_90 bigint
)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_hoy date := public._cxp_hoy();
begin
  return query
  select coalesce(sum(d.val_pagar), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where d.fecha_vcto < v_hoy), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where not (d.fecha_vcto < v_hoy) or d.fecha_vcto is null), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where v_hoy - d.fecha_vcto between 1 and 30), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where v_hoy - d.fecha_vcto between 31 and 60), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where v_hoy - d.fecha_vcto between 61 and 90), 0)::numeric,
         coalesce(sum(d.val_pagar) filter (where v_hoy - d.fecha_vcto > 90), 0)::numeric,
         count(*),
         count(*) filter (where d.fecha_vcto < v_hoy),
         count(*) filter (where not (d.fecha_vcto < v_hoy) or d.fecha_vcto is null),
         count(*) filter (where v_hoy - d.fecha_vcto between 1 and 30),
         count(*) filter (where v_hoy - d.fecha_vcto between 31 and 60),
         count(*) filter (where v_hoy - d.fecha_vcto between 61 and 90),
         count(*) filter (where v_hoy - d.fecha_vcto > 90)
  from public._cxp_filtrar(p_org, p_estado, p_busqueda, p_tercero, p_nombre, p_sede, p_origen) d;
end $fn$;

-- 4. Última carga ---------------------------------------------------------------------------------------------
create or replace function public.cxp_ultima_carga(p_org uuid)
returns table (fecha timestamptz, usuario text, archivo text, filas integer, ausentes integer)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
begin
  perform public._exigir_permiso(p_org, 'cxp', 'ver');
  return query
  select i.created_at,
         nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), ''),
         i.archivo, i.filas,
         (select count(*)::int from public.cxp_documentos d
           where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente'
             and d.regla_id is null and d.visto_en is distinct from i.id)
  from public.cxp_importaciones i
  left join public.profiles pu on pu.id = i.usuario_id
  where i.organizacion_id = p_org
  order by i.created_at desc
  limit 1;
end $fn$;

-- 5. Cruce de pendientes manuales con el ERP -------------------------------------------------------------------
-- Cruzar = "este pendiente manual ya es ese documento del ERP". El manual deja de contarse (queda 'cruzado',
-- enlazado) y el documento del ERP hereda lo anotado (anticipos, descuentos, retenciones, detalles).
-- Si el manual ya estaba pagado, el documento del ERP queda pagado con esa misma fecha: no se paga dos veces.
create or replace function public._cxp_cruzar(p_org uuid, p_manual uuid, p_erp uuid, p_user uuid) returns void
  language plpgsql security definer set search_path to ''
as $fn$
declare m public.cxp_documentos%rowtype; e public.cxp_documentos%rowtype;
begin
  select * into m from public.cxp_documentos
   where id = p_manual and organizacion_id = p_org and origen = 'manual' and estado in ('pendiente', 'pagado') for update;
  if not found then raise exception 'El pendiente manual no existe o ya fue cruzado'; end if;
  select * into e from public.cxp_documentos
   where id = p_erp and organizacion_id = p_org and origen = 'erp' and estado = 'pendiente' and regla_id is null for update;
  if not found then raise exception 'El documento del ERP no existe, está excluido o ya está pagado'; end if;

  update public.cxp_documentos set
    anticipos   = case when anticipos = 0   then m.anticipos   else anticipos end,
    descuentos  = case when descuentos = 0  then m.descuentos  else descuentos end,
    retenciones = case when retenciones = 0 then m.retenciones else retenciones end,
    detalles    = left(case when m.detalles is null then detalles
                            when detalles is null then m.detalles
                            when position(m.detalles in detalles) > 0 then detalles
                            else detalles || ' | ' || m.detalles end, 500),
    estado      = case when m.estado = 'pagado' then 'pagado' else estado end,
    fecha_pago  = case when m.estado = 'pagado' then m.fecha_pago else fecha_pago end,
    pagado_por  = case when m.estado = 'pagado' then m.pagado_por else pagado_por end
  where id = e.id;

  update public.cxp_documentos
     set estado = 'cruzado', cruzado_con = e.id, fecha_cruce = now(), cruzado_por = p_user
   where id = m.id;
end $fn$;

create or replace function public.cxp_cruzar(p_org uuid, p_manual uuid, p_erp uuid) returns void
  language plpgsql security definer set search_path to ''
as $fn$
begin
  perform public._exigir_permiso(p_org, 'cxp', 'editar');
  -- Cruzar un manual ya pagado deja pagado el documento del ERP: exige el permiso de pagos.
  if exists (select 1 from public.cxp_documentos where id = p_manual and organizacion_id = p_org and estado = 'pagado') then
    perform public._exigir_permiso(p_org, 'cxp_pagos', 'editar');
  end if;
  perform public._cxp_cruzar(p_org, p_manual, p_erp, auth.uid());
end $fn$;

-- Sin p_manual: parejas probables (mismo NIT y misma factura, o mismo NIT y mismo valor).
-- Con p_manual: candidatos del ERP para ese pendiente (mismo NIT, misma factura o mismo valor), con búsqueda opcional.
create or replace function public.cxp_cruces_sugeridos(
  p_org uuid, p_manual uuid default null, p_busqueda text default null, p_limit integer default 50
) returns table (
  manual_id uuid, manual_nombre text, manual_docto text, manual_total numeric, manual_vcto date, manual_estado text,
  erp_id uuid, erp_nombre text, erp_documento text, erp_docto text, erp_total numeric, erp_vcto date,
  motivo text, puntaje integer
)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_q text;
begin
  perform public._exigir_permiso(p_org, 'cxp', 'ver');
  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');

  return query
  with par as (
    select m.id as m_id, m.nombre as m_nombre, m.docto_proveedor as m_docto, m.total_factura as m_total,
           m.fecha_vcto as m_vcto, m.estado as m_estado,
           e.id as e_id, e.nombre as e_nombre, e.documento_erp as e_doc, e.docto_proveedor as e_docto,
           e.total_factura as e_total, e.fecha_vcto as e_vcto,
           (length(coalesce(m.docto_proveedor_norm, '')) >= 3 and e.docto_proveedor_norm = m.docto_proveedor_norm) as misma_factura,
           (m.tercero is not null and e.tercero = m.tercero) as mismo_tercero,
           (e.total_factura = m.total_factura) as mismo_total
    from public.cxp_documentos m
    join public.cxp_documentos e
      on e.organizacion_id = m.organizacion_id and e.origen = 'erp' and e.estado = 'pendiente' and e.regla_id is null
    where m.organizacion_id = p_org and m.origen = 'manual' and m.estado in ('pendiente', 'pagado')
      and (p_manual is null or m.id = p_manual)
  ), pt as (
    select par.*,
           case when misma_factura and mismo_tercero then 100
                when misma_factura then 60
                when mismo_tercero and mismo_total then 80
                when mismo_total then 50
                else 40 end as pts,
           case when misma_factura and mismo_tercero then 'Misma factura del mismo NIT'
                when misma_factura then 'Misma factura'
                when mismo_tercero and mismo_total then 'Mismo NIT y mismo valor'
                when mismo_total then 'Mismo valor'
                else 'Mismo NIT' end as mot
    from par
    where case when p_manual is null
               then mismo_tercero and (misma_factura or mismo_total)
               else (misma_factura or mismo_tercero or mismo_total)
                    and (v_q = ''
                         or extensions.unaccent(lower(e_nombre)) like '%' || v_q || '%' escape '\'
                         or lower(e_doc) like '%' || v_q || '%' escape '\'
                         or lower(coalesce(e_docto, '')) like '%' || v_q || '%' escape '\')
          end
  )
  select pt.m_id, pt.m_nombre, pt.m_docto, pt.m_total, pt.m_vcto, pt.m_estado,
         pt.e_id, pt.e_nombre, pt.e_doc, pt.e_docto, pt.e_total, pt.e_vcto, pt.mot, pt.pts
  from pt
  order by pt.pts desc, lower(pt.m_nombre), pt.e_total
  limit least(greatest(p_limit, 1), 200);
end $fn$;

-- 6. Vista previa y carga: ahora también cruzan y marcan lo "visto" ------------------------------------------------
create or replace function public.cxp_importar_previsualizar(p_org uuid, p_filas jsonb, p_hash text default null)
returns jsonb
  language plpgsql stable security definer set search_path to ''
as $fn$
declare v jsonb;
begin
  perform public._exigir_permiso(p_org, 'cxp_importar', 'crear');

  with f as (select * from public._cxp_filas_import(p_filas)),
  c as (
    select f.*, d.id as doc_id, d.estado as doc_estado, d.total_factura as total_ant,
           public._cxp_regla_de(p_org, f.tercero, f.documento_erp, f.detalle) as regla_nueva,
           (d.id is not null and (
              d.total_factura is distinct from f.saldo or d.fecha_vcto is distinct from f.fecha_vcto
              or d.fecha_dcto is distinct from f.fecha_dcto or d.nombre is distinct from f.nombre
              or d.detalle_erp is distinct from f.detalle or d.cond_pago is distinct from f.cond_pago
              or d.docto_proveedor is distinct from f.docto_proveedor or d.co_codigo is distinct from f.co_codigo
           )) as cambio
    from f
    left join public.cxp_documentos d
      on d.organizacion_id = p_org and d.origen = 'erp'
     and coalesce(d.empresa, '') = coalesce(f.empresa, '') and d.tercero = f.tercero
     and lower(btrim(d.documento_erp)) = lower(btrim(f.documento_erp))
  ),
  ausentes as (
    select d.nombre, d.documento_erp, d.total_factura
    from public.cxp_documentos d
    where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente' and d.regla_id is null
      and not exists (
        select 1 from f
        where coalesce(f.empresa, '') = coalesce(d.empresa, '') and f.tercero = d.tercero
          and lower(btrim(f.documento_erp)) = lower(btrim(d.documento_erp)))
  ),
  cos_co as (
    select f.co_codigo, max(f.co_nombre) as co_nombre, count(*) as filas
    from f where f.co_codigo is not null group by f.co_codigo
  ),
  cruces as (
    select distinct on (m.id) m.nombre as m_nombre, m.docto_proveedor as m_docto, m.total_factura as m_total,
           m.estado as m_estado, c.documento_erp as e_doc, c.saldo as e_saldo
    from c
    join public.cxp_documentos m
      on m.organizacion_id = p_org and m.origen = 'manual' and m.estado in ('pendiente', 'pagado')
     and m.tercero = c.tercero and length(coalesce(m.docto_proveedor_norm, '')) >= 3
     and m.docto_proveedor_norm = nullif(upper(regexp_replace(coalesce(c.docto_proveedor, ''), '[^A-Za-z0-9]', '', 'g')), '')
    where c.regla_nueva is null and c.doc_estado is distinct from 'pagado'
    order by m.id, c.documento_erp
  )
  select jsonb_build_object(
    'total', (select count(*) from c),
    'nuevos', (select count(*) from c where doc_id is null),
    'nuevos_excluidos', (select count(*) from c where doc_id is null and regla_nueva is not null),
    'actualizados', (select count(*) from c where doc_estado = 'pendiente' and cambio),
    'sin_cambios', (select count(*) from c where doc_estado = 'pendiente' and not cambio),
    'pagados_omitidos', (select count(*) from c where doc_estado = 'pagado'),
    'pagados_saldo_distinto', (
      select coalesce(jsonb_agg(jsonb_build_object('nombre', x.nombre, 'documento', x.documento_erp,
                                                   'saldo_pagado', x.total_ant, 'saldo_erp', x.saldo) order by x.nombre), '[]'::jsonb)
      from (select * from c where doc_estado = 'pagado' and total_ant is distinct from saldo limit 50) x),
    'cambios_de_saldo', (
      select coalesce(jsonb_agg(jsonb_build_object('nombre', x.nombre, 'documento', x.documento_erp,
                                                   'saldo_anterior', x.total_ant, 'saldo_nuevo', x.saldo) order by x.nombre), '[]'::jsonb)
      from (select * from c where doc_estado = 'pendiente' and total_ant is distinct from saldo limit 50) x),
    'ausentes', (select count(*) from ausentes),
    'ausentes_lista', (
      select coalesce(jsonb_agg(jsonb_build_object('nombre', x.nombre, 'documento', x.documento_erp,
                                                   'saldo', x.total_factura) order by x.nombre), '[]'::jsonb)
      from (select * from ausentes limit 50) x),
    'cruces', (select count(*) from cruces),
    'cruces_lista', (
      select coalesce(jsonb_agg(jsonb_build_object('manual', x.m_nombre, 'factura', x.m_docto, 'valor_manual', x.m_total,
                                                   'estado_manual', x.m_estado, 'documento', x.e_doc, 'saldo_erp', x.e_saldo)
                               order by x.m_nombre), '[]'::jsonb)
      from (select * from cruces limit 50) x),
    'cos', (
      select coalesce(jsonb_agg(jsonb_build_object('codigo', co.co_codigo, 'nombre', co.co_nombre,
                                                   'filas', co.filas, 'sede_id', m.sede_id) order by co.co_codigo), '[]'::jsonb)
      from cos_co co
      left join public.cxp_co_sede m on m.organizacion_id = p_org and m.co_codigo = co.co_codigo),
    'repetido', (
      select jsonb_build_object('fecha', i.created_at, 'archivo', i.archivo)
      from public.cxp_importaciones i
      where i.organizacion_id = p_org and p_hash is not null and i.archivo_hash = p_hash
      order by i.created_at desc limit 1)
  ) into v;
  return v;
end $fn$;

create or replace function public.cxp_importar_confirmar(
  p_org uuid, p_filas jsonb, p_archivo text default null, p_hash text default null
) returns jsonb
  language plpgsql security definer set search_path to ''
as $fn$
declare
  v_total integer; v_omit integer; v_nuevos integer; v_act integer; v_aus integer; v_excl integer; v_cruces integer := 0;
  v_res jsonb; v_imp uuid := gen_random_uuid(); r record;
begin
  perform public._exigir_permiso(p_org, 'cxp_importar', 'crear');
  perform pg_advisory_xact_lock(hashtext('cxp_imp:' || p_org::text));

  drop table if exists pg_temp._cxp_f;
  create temp table _cxp_f on commit drop as select * from public._cxp_filas_import(p_filas);

  select count(*) into v_total from pg_temp._cxp_f;
  select count(*) into v_omit
    from pg_temp._cxp_f f
    join public.cxp_documentos d
      on d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pagado'
     and coalesce(d.empresa, '') = coalesce(f.empresa, '') and d.tercero = f.tercero
     and lower(btrim(d.documento_erp)) = lower(btrim(f.documento_erp));

  -- La carga se registra primero para poder marcar cada documento como "visto" en ella.
  insert into public.cxp_importaciones (id, organizacion_id, fuente, archivo, archivo_hash, filas, resumen, usuario_id)
  values (v_imp, p_org, 'excel', left(p_archivo, 200), p_hash, v_total, '{}'::jsonb, auth.uid());

  with up as (
    insert into public.cxp_documentos
      (organizacion_id, origen, empresa, tercero, nombre, cond_pago, docto_proveedor, fecha_dcto, fecha_vcto,
       plazo, documento_erp, co_codigo, sede_id, detalle_erp, erp_raw, total_factura, creado_por)
    select p_org, 'erp', f.empresa, f.tercero, f.nombre, f.cond_pago, f.docto_proveedor, f.fecha_dcto, f.fecha_vcto,
           f.plazo, f.documento_erp, f.co_codigo, m.sede_id, f.detalle, f.raw, f.saldo, auth.uid()
    from pg_temp._cxp_f f
    left join public.cxp_co_sede m on m.organizacion_id = p_org and m.co_codigo = f.co_codigo
    where not exists (
      select 1 from public.cxp_documentos p
      where p.organizacion_id = p_org and p.origen = 'erp' and p.estado = 'pagado'
        and coalesce(p.empresa, '') = coalesce(f.empresa, '') and p.tercero = f.tercero
        and lower(btrim(p.documento_erp)) = lower(btrim(f.documento_erp)))
    on conflict (organizacion_id, coalesce(empresa, ''), tercero, lower(btrim(documento_erp))) where origen = 'erp'
    do update set
      nombre = excluded.nombre, cond_pago = excluded.cond_pago, docto_proveedor = excluded.docto_proveedor,
      fecha_dcto = excluded.fecha_dcto, fecha_vcto = excluded.fecha_vcto, plazo = excluded.plazo,
      co_codigo = excluded.co_codigo, sede_id = coalesce(excluded.sede_id, public.cxp_documentos.sede_id),
      detalle_erp = excluded.detalle_erp, erp_raw = excluded.erp_raw, total_factura = excluded.total_factura
    where (public.cxp_documentos.nombre, public.cxp_documentos.cond_pago, public.cxp_documentos.docto_proveedor,
           public.cxp_documentos.fecha_dcto, public.cxp_documentos.fecha_vcto, public.cxp_documentos.plazo,
           public.cxp_documentos.co_codigo, public.cxp_documentos.detalle_erp, public.cxp_documentos.total_factura)
      is distinct from
          (excluded.nombre, excluded.cond_pago, excluded.docto_proveedor, excluded.fecha_dcto, excluded.fecha_vcto,
           excluded.plazo, excluded.co_codigo, excluded.detalle_erp, excluded.total_factura)
    returning (xmax = 0) as es_nuevo
  )
  select count(*) filter (where es_nuevo), count(*) filter (where not es_nuevo)
    into v_nuevos, v_act from up;

  -- Todo lo que vino en este archivo queda "visto" en esta carga; lo demás es lo que no vino.
  update public.cxp_documentos d
     set visto_en = v_imp
    from pg_temp._cxp_f f
   where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente'
     and coalesce(d.empresa, '') = coalesce(f.empresa, '') and d.tercero = f.tercero
     and lower(btrim(d.documento_erp)) = lower(btrim(f.documento_erp));

  perform public._cxp_aplicar_reglas(p_org);

  -- Cruce automático de pendientes manuales (pendientes o ya pagados) con lo que acaba de llegar:
  -- mismo NIT y misma factura del proveedor (de 3 o más caracteres). Un manual pagado deja pagado el del ERP.
  for r in
    select distinct on (m.id) m.id as m_id, e.id as e_id
    from public.cxp_documentos m
    join public.cxp_documentos e
      on e.organizacion_id = p_org and e.origen = 'erp' and e.estado = 'pendiente' and e.regla_id is null
     and e.tercero = m.tercero and e.docto_proveedor_norm = m.docto_proveedor_norm
    where m.organizacion_id = p_org and m.origen = 'manual' and m.estado in ('pendiente', 'pagado')
      and m.tercero is not null and length(coalesce(m.docto_proveedor_norm, '')) >= 3
      and exists (
        select 1 from pg_temp._cxp_f f
        where coalesce(f.empresa, '') = coalesce(e.empresa, '') and f.tercero = e.tercero
          and lower(btrim(f.documento_erp)) = lower(btrim(e.documento_erp)))
    order by m.id, e.documento_erp
  loop
    begin
      perform public._cxp_cruzar(p_org, r.m_id, r.e_id, auth.uid());
      v_cruces := v_cruces + 1;
    exception when others then
      raise warning 'No se pudo cruzar % con %: %', r.m_id, r.e_id, sqlerrm;
    end;
  end loop;

  select count(*) into v_aus
    from public.cxp_documentos d
   where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente'
     and d.regla_id is null and d.visto_en is distinct from v_imp;
  select count(*) into v_excl from public.cxp_documentos
   where organizacion_id = p_org and estado = 'pendiente' and regla_id is not null;

  v_res := jsonb_build_object(
    'total', v_total, 'nuevos', v_nuevos, 'actualizados', v_act,
    'sin_cambios', v_total - v_omit - v_nuevos - v_act,
    'pagados_omitidos', v_omit, 'ausentes', v_aus, 'excluidos', v_excl, 'cruces', v_cruces);

  update public.cxp_importaciones set resumen = v_res where id = v_imp;
  return v_res || jsonb_build_object('importacion_id', v_imp);
end $fn$;

-- 7. Permisos de ejecución (vuelve a recorrer todas las funciones cxp) -------------------------------------------
do $do$
declare r record;
begin
  for r in
    select p.oid::regprocedure as f, p.proname
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and (p.proname like 'cxp\_%' escape '\' or p.proname like '\_cxp\_%' escape '\')
  loop
    execute format('revoke all on function %s from public, anon', r.f);
    if r.proname like 'cxp\_%' escape '\' then
      execute format('grant execute on function %s to authenticated', r.f);
    end if;
    execute format('grant execute on function %s to service_role', r.f);
  end loop;
end $do$;

commit;
