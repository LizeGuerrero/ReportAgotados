-- Cuentas por pagar (CXP) · Fase 2: reglas de exclusión (REC NO REV), carga del Excel del ERP
-- y equivalencia C.O. ↔ sedes. Requiere la Fase 1. Idempotente.
begin;

-- 1. Permisos nuevos (solo admin; el resto se asigna desde el CRUD de roles) ---------------------
insert into public.modulos (nombre, descripcion) values
  ('cxp_importar', 'Cuentas por pagar: cargar archivos del ERP (ver historial, cargar, equivalencias C.O.-sede)'),
  ('cxp_reglas',   'Cuentas por pagar: reglas de exclusión (REC NO REV)')
on conflict (nombre) do nothing;

insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
select r.id, mo.id, true, true, true, true
from public.roles r
cross join public.modulos mo
where r.nombre = 'admin' and r.organizacion_id is not null
  and mo.nombre in ('cxp_importar', 'cxp_reglas')
on conflict (rol_id, modulo_id) do nothing;

-- 2. Reglas de exclusión ------------------------------------------------------------------------------
-- tipo 'documento': un documento concreto del ERP (NIT + número de documento). Es la regla normal.
-- tipo 'patron'   : todos los documentos de un tercero con exactamente ese detalle (regla amplia).
create table if not exists public.cxp_reglas (
  id              uuid primary key default gen_random_uuid(),
  organizacion_id uuid not null references public.organizaciones(id),
  tipo            text not null check (tipo in ('documento', 'patron')),
  tercero         text not null,
  documento_erp   text,
  detalle         text,
  nombre_ref      text,
  contexto        text not null,          -- nota para contabilidad: DE EQUIPO CONTAB, CRUZAR, REVISAR, ELIMINAR...
  nota            text,
  activa          boolean not null default true,
  creado_por      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint cxp_reglas_forma_chk check (
    (tipo = 'documento' and nullif(btrim(documento_erp), '') is not null and detalle is null)
    or (tipo = 'patron' and nullif(btrim(detalle), '') is not null and documento_erp is null)),
  constraint cxp_reglas_contexto_chk check (btrim(contexto) <> '')
);
create unique index if not exists cxp_reglas_doc_uk
  on public.cxp_reglas (organizacion_id, tercero, lower(btrim(documento_erp))) where tipo = 'documento';
create unique index if not exists cxp_reglas_patron_uk
  on public.cxp_reglas (organizacion_id, tercero, lower(btrim(detalle))) where tipo = 'patron';

drop trigger if exists trg_cxp_reglas_updated_at on public.cxp_reglas;
create trigger trg_cxp_reglas_updated_at before update on public.cxp_reglas
  for each row execute function public.set_updated_at();
drop trigger if exists trg_auditar_cxp_reglas on public.cxp_reglas;
create trigger trg_auditar_cxp_reglas after insert or delete or update on public.cxp_reglas
  for each row execute function public.auditar_cambio();

alter table public.cxp_reglas enable row level security;
drop policy if exists cxp_reglas_select on public.cxp_reglas;
create policy cxp_reglas_select on public.cxp_reglas for select
  using (public.tiene_permiso(organizacion_id, 'cxp_reglas', 'ver'));
revoke all on table public.cxp_reglas from anon;
revoke insert, update, delete on table public.cxp_reglas from authenticated;

-- Qué regla (si hay) deja fuera a cada documento
alter table public.cxp_documentos
  add column if not exists regla_id uuid references public.cxp_reglas(id) on delete set null;
create index if not exists cxp_documentos_regla_idx on public.cxp_documentos (regla_id) where regla_id is not null;

-- 3. Cargas y equivalencia C.O. ↔ sede ---------------------------------------------------------------
create table if not exists public.cxp_importaciones (
  id              uuid primary key default gen_random_uuid(),
  organizacion_id uuid not null references public.organizaciones(id),
  fuente          text not null default 'excel' check (fuente in ('excel', 'api')),
  archivo         text,
  archivo_hash    text,
  filas           integer not null default 0,
  resumen         jsonb not null default '{}'::jsonb,
  usuario_id      uuid references public.profiles(id),
  created_at      timestamptz not null default now()
);
create index if not exists cxp_importaciones_org_idx on public.cxp_importaciones (organizacion_id, created_at desc);
create index if not exists cxp_importaciones_hash_idx on public.cxp_importaciones (organizacion_id, archivo_hash);

create table if not exists public.cxp_co_sede (
  organizacion_id uuid not null references public.organizaciones(id),
  co_codigo       text not null,
  co_nombre       text,
  sede_id         uuid references public.sedes(id),
  updated_at      timestamptz not null default now(),
  primary key (organizacion_id, co_codigo)
);

alter table public.cxp_importaciones enable row level security;
alter table public.cxp_co_sede enable row level security;
drop policy if exists cxp_importaciones_select on public.cxp_importaciones;
create policy cxp_importaciones_select on public.cxp_importaciones for select
  using (public.tiene_permiso(organizacion_id, 'cxp_importar', 'ver'));
drop policy if exists cxp_co_sede_select on public.cxp_co_sede;
create policy cxp_co_sede_select on public.cxp_co_sede for select
  using (public.tiene_permiso(organizacion_id, 'cxp_importar', 'ver'));
revoke all on table public.cxp_importaciones from anon;
revoke all on table public.cxp_co_sede from anon;
revoke insert, update, delete on table public.cxp_importaciones from authenticated;
revoke insert, update, delete on table public.cxp_co_sede from authenticated;

-- 4. Aplicación de reglas -----------------------------------------------------------------------------
create or replace function public._cxp_regla_de(p_org uuid, p_tercero text, p_documento text, p_detalle text)
returns uuid
  language sql stable set search_path to ''
as $fn$
  select r.id
  from public.cxp_reglas r
  where r.organizacion_id = p_org and r.activa and r.tercero = p_tercero
    and ((r.tipo = 'documento' and lower(btrim(r.documento_erp)) = lower(btrim(coalesce(p_documento, ''))))
      or (r.tipo = 'patron' and lower(btrim(r.detalle)) = lower(btrim(coalesce(p_detalle, '')))))
  order by (r.tipo = 'documento') desc, r.created_at, r.id
  limit 1
$fn$;

-- Recalcula qué documentos pendientes del ERP quedan excluidos. Se llama al cambiar una regla y al cargar.
create or replace function public._cxp_aplicar_reglas(p_org uuid) returns integer
  language plpgsql security definer set search_path to ''
as $fn$
declare v_n integer;
begin
  update public.cxp_documentos d
     set regla_id = public._cxp_regla_de(d.organizacion_id, d.tercero, d.documento_erp, d.detalle_erp)
   where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente'
     and d.regla_id is distinct from public._cxp_regla_de(d.organizacion_id, d.tercero, d.documento_erp, d.detalle_erp);
  get diagnostics v_n = row_count;
  return v_n;
end $fn$;

-- 5. La cartera ahora separa pendientes / excluidas / pagadas -------------------------------------------
create or replace function public._cxp_filtrar(
  p_org uuid, p_estado text, p_busqueda text, p_tercero text, p_nombre text, p_sede uuid, p_origen text
) returns setof public.cxp_documentos
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  if p_estado is null or p_estado not in ('pendiente', 'excluido', 'pagado') then raise exception 'Estado no válido'; end if;
  if p_estado = 'pagado' then
    perform public._exigir_permiso(p_org, 'cxp_pagos', 'ver');
  else
    perform public._exigir_permiso(p_org, 'cxp', 'ver');
  end if;
  if coalesce(p_origen, '') not in ('', 'erp', 'manual') then raise exception 'Origen no válido'; end if;
  if p_sede is not null and not exists (select 1 from public.sedes where id = p_sede and organizacion_id = p_org) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select d.*
  from public.cxp_documentos d
  where d.organizacion_id = p_org
    and case p_estado
          when 'pagado'   then d.estado = 'pagado'
          when 'excluido' then d.estado = 'pendiente' and d.regla_id is not null
          else                 d.estado = 'pendiente' and d.regla_id is null end
    and (coalesce(p_origen, '') = '' or d.origen = p_origen)
    and (p_sede is null or d.sede_id = p_sede)
    and (nullif(btrim(p_tercero), '') is null or d.tercero = upper(btrim(p_tercero)))
    and (nullif(btrim(p_nombre), '') is null or lower(btrim(d.nombre)) = lower(btrim(p_nombre)))
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(d.nombre)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.tercero, '')) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.docto_proveedor, '')) like '%' || t.term || '%' escape '\'
        or lower(coalesce(d.documento_erp, '')) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(coalesce(d.detalle_erp, '') || ' ' || coalesce(d.detalles, ''))) like '%' || t.term || '%' escape '\'
      )
    );
end $fn$;

drop function if exists public.cxp_listar(uuid, text, text, text, text, uuid, text, text, text, text, integer, integer);
create function public.cxp_listar(
  p_org uuid,
  p_estado text default 'pendiente',
  p_busqueda text default null,
  p_tercero text default null,
  p_nombre text default null,
  p_sede uuid default null,
  p_origen text default null,
  p_vencimiento text default null,
  p_orden text default null,
  p_dir text default 'asc',
  p_limit integer default 50,
  p_offset integer default 0
) returns table (
  id uuid, origen text, empresa text, tercero text, nombre text, cond_pago text,
  docto_proveedor text, documento_erp text, fecha_dcto date, fecha_vcto date, plazo integer,
  dias_venc integer, vencido boolean, sede text, anticipos numeric, descuentos numeric,
  retenciones numeric, total_factura numeric, val_pagar numeric, detalles text, estado text,
  fecha_pago timestamptz, pagado_por text,
  detalle_erp text, regla_id uuid, regla_tipo text, contexto text, nota_regla text,
  total bigint
)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare
  v_hoy date := public._cxp_hoy();
  v_orden text := nullif(trim(p_orden), '');
  v_asc boolean;
begin
  if coalesce(p_vencimiento, '') not in ('', 'vencidos', 'por_vencer') then
    raise exception 'Filtro de vencimiento no válido';
  end if;
  if v_orden is not null and v_orden not in
     ('nombre', 'tercero', 'fecha_dcto', 'fecha_vcto', 'dias_venc', 'val_pagar', 'total_factura', 'fecha_pago') then
    raise exception 'Columna de orden no válida';
  end if;
  if coalesce(p_dir, 'asc') not in ('asc', 'desc') then raise exception 'Dirección de orden no válida'; end if;
  if v_orden is null then
    v_orden := case when p_estado = 'pagado' then 'fecha_pago' else 'fecha_vcto' end;
    v_asc := p_estado <> 'pagado';
  else
    v_asc := coalesce(p_dir, 'asc') = 'asc';
  end if;

  return query
  with b as (
    select d.id, d.origen, d.empresa, d.tercero, d.nombre, d.cond_pago, d.docto_proveedor,
           d.documento_erp, d.fecha_dcto, d.fecha_vcto, d.plazo,
           greatest(0, v_hoy - d.fecha_vcto) as dias,
           (d.fecha_vcto is not null and d.fecha_vcto < v_hoy) as venc,
           s.nombre as sede_nombre, d.anticipos, d.descuentos, d.retenciones, d.total_factura,
           d.val_pagar, d.detalles, d.estado, d.fecha_pago,
           nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), '') as pagador,
           d.detalle_erp, d.regla_id, rg.tipo as r_tipo, rg.contexto as r_contexto, rg.nota as r_nota
    from public._cxp_filtrar(p_org, p_estado, p_busqueda, p_tercero, p_nombre, p_sede, p_origen) d
    left join public.sedes s on s.id = d.sede_id
    left join public.profiles pu on pu.id = d.pagado_por
    left join public.cxp_reglas rg on rg.id = d.regla_id
  )
  select b.id, b.origen, b.empresa, b.tercero, b.nombre, b.cond_pago, b.docto_proveedor,
         b.documento_erp, b.fecha_dcto, b.fecha_vcto, b.plazo, b.dias, b.venc, b.sede_nombre,
         b.anticipos, b.descuentos, b.retenciones, b.total_factura, b.val_pagar, b.detalles,
         b.estado, b.fecha_pago, b.pagador,
         b.detalle_erp, b.regla_id, b.r_tipo, b.r_contexto, b.r_nota,
         count(*) over()
  from b
  where case coalesce(p_vencimiento, '')
          when 'vencidos' then b.venc
          when 'por_vencer' then not b.venc
          else true end
  order by
    case when v_asc then (case v_orden when 'nombre' then lower(b.nombre) when 'tercero' then b.tercero end) end asc nulls last,
    case when not v_asc then (case v_orden when 'nombre' then lower(b.nombre) when 'tercero' then b.tercero end) end desc nulls last,
    case when v_asc then (case v_orden when 'dias_venc' then b.dias::numeric when 'val_pagar' then b.val_pagar
                                       when 'total_factura' then b.total_factura end) end asc nulls last,
    case when not v_asc then (case v_orden when 'dias_venc' then b.dias::numeric when 'val_pagar' then b.val_pagar
                                           when 'total_factura' then b.total_factura end) end desc nulls last,
    case when v_asc then (case v_orden when 'fecha_dcto' then b.fecha_dcto::timestamptz
                                       when 'fecha_vcto' then b.fecha_vcto::timestamptz
                                       when 'fecha_pago' then b.fecha_pago end) end asc nulls last,
    case when not v_asc then (case v_orden when 'fecha_dcto' then b.fecha_dcto::timestamptz
                                           when 'fecha_vcto' then b.fecha_vcto::timestamptz
                                           when 'fecha_pago' then b.fecha_pago end) end desc nulls last,
    lower(b.nombre), b.id
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $fn$;

create or replace function public.cxp_proveedores_filtro(p_org uuid, p_estado text default 'pendiente')
returns table (tercero text, nombre text, documentos integer)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
begin
  if p_estado is null or p_estado not in ('pendiente', 'excluido', 'pagado') then raise exception 'Estado no válido'; end if;
  if p_estado = 'pagado' then
    perform public._exigir_permiso(p_org, 'cxp_pagos', 'ver');
  else
    perform public._exigir_permiso(p_org, 'cxp', 'ver');
  end if;
  return query
  select d.tercero, (array_agg(d.nombre order by d.updated_at desc))[1], count(*)::int
  from public.cxp_documentos d
  where d.organizacion_id = p_org
    and case p_estado
          when 'pagado'   then d.estado = 'pagado'
          when 'excluido' then d.estado = 'pendiente' and d.regla_id is not null
          else                 d.estado = 'pendiente' and d.regla_id is null end
  group by coalesce(d.tercero, 'n:' || lower(btrim(d.nombre))), d.tercero
  order by 2;
end $fn$;

-- Una excluida no se puede pagar desde la cartera
create or replace function public.cxp_marcar_pagado(p_org uuid, p_ids uuid[]) returns integer
  language plpgsql security definer set search_path to ''
as $fn$
declare v_n integer; v_esperados integer;
begin
  perform public._exigir_permiso(p_org, 'cxp_pagos', 'editar');
  if p_ids is null or cardinality(p_ids) = 0 then raise exception 'Selecciona al menos un documento'; end if;
  select count(distinct x) into v_esperados from unnest(p_ids) x;

  update public.cxp_documentos
     set estado = 'pagado', fecha_pago = now(), pagado_por = auth.uid()
   where organizacion_id = p_org and estado = 'pendiente' and regla_id is null and id = any(p_ids);
  get diagnostics v_n = row_count;

  if v_n <> v_esperados then
    raise exception 'Algún documento ya estaba pagado, está excluido o no existe; no se marcó ninguno';
  end if;
  return v_n;
end $fn$;

create or replace function public.cxp_listar_sedes(p_org uuid)
returns table (id uuid, nombre text)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if not (public.tiene_permiso(p_org, 'cxp', 'ver') or public.tiene_permiso(p_org, 'cxp_pagos', 'ver')
          or public.tiene_permiso(p_org, 'cxp_importar', 'ver')) then
    raise exception 'Sin permiso para ver cuentas por pagar';
  end if;
  return query select s.id, s.nombre from public.sedes s where s.organizacion_id = p_org order by s.nombre;
end $fn$;

-- 6. CRUD de reglas (REC NO REV) --------------------------------------------------------------------------
create or replace function public.cxp_reglas_listar(
  p_org uuid, p_busqueda text default null, p_contexto text default null,
  p_limit integer default 100, p_offset integer default 0
) returns table (
  id uuid, tipo text, tercero text, nombre_ref text, documento_erp text, detalle text, contexto text,
  nota text, activa boolean, docs integer, valor numeric, creado_por text, created_at timestamptz, total bigint
)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._exigir_permiso(p_org, 'cxp_reglas', 'ver');
  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select r.id, r.tipo, r.tercero, r.nombre_ref, r.documento_erp, r.detalle, r.contexto, r.nota, r.activa,
         coalesce(a.n, 0)::int, coalesce(a.v, 0)::numeric,
         nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), ''),
         r.created_at, count(*) over()
  from public.cxp_reglas r
  left join public.profiles pu on pu.id = r.creado_por
  left join lateral (
    select count(*) as n, sum(d.val_pagar) as v
    from public.cxp_documentos d where d.regla_id = r.id and d.estado = 'pendiente'
  ) a on true
  where r.organizacion_id = p_org
    and (nullif(btrim(p_contexto), '') is null or r.contexto = p_contexto)
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        lower(r.tercero) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(coalesce(r.nombre_ref, ''))) like '%' || t.term || '%' escape '\'
        or lower(coalesce(r.documento_erp, '')) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(coalesce(r.detalle, ''))) like '%' || t.term || '%' escape '\'
        or extensions.unaccent(lower(r.contexto || ' ' || coalesce(r.nota, ''))) like '%' || t.term || '%' escape '\'
      )
    )
  order by r.created_at desc, r.id
  limit least(greatest(p_limit, 1), 500) offset greatest(p_offset, 0);
end $fn$;

-- Cuántos documentos (y cuánto dinero) dejaría fuera una regla, antes de guardarla.
create or replace function public.cxp_regla_previsualizar(p_org uuid, p_datos jsonb) returns jsonb
  language plpgsql stable security definer set search_path to ''
as $fn$
declare
  v_tipo text := p_datos->>'tipo'; v_t text; v jsonb;
  v_doc text := nullif(btrim(p_datos->>'documento_erp'), '');
  v_det text := nullif(btrim(p_datos->>'detalle'), '');
begin
  perform public._exigir_permiso(p_org, 'cxp_reglas', 'ver');
  if v_tipo is null or v_tipo not in ('documento', 'patron') then raise exception 'Tipo de regla no válido'; end if;
  v_t := public._cxp_nit(p_datos->>'tercero');
  if v_t is null then return jsonb_build_object('docs', 0, 'valor', 0, 'ejemplos', '[]'::jsonb); end if;

  with m as (
    select d.nombre, d.documento_erp, d.detalle_erp, d.val_pagar
    from public.cxp_documentos d
    where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente' and d.tercero = v_t
      and ((v_tipo = 'documento' and v_doc is not null and lower(btrim(d.documento_erp)) = lower(v_doc))
        or (v_tipo = 'patron' and v_det is not null and lower(btrim(d.detalle_erp)) = lower(v_det)))
  )
  select jsonb_build_object(
    'docs', (select count(*) from m),
    'valor', (select coalesce(sum(val_pagar), 0) from m),
    'ejemplos', (select coalesce(jsonb_agg(jsonb_build_object(
                   'nombre', x.nombre, 'documento', x.documento_erp, 'detalle', x.detalle_erp, 'valor', x.val_pagar)), '[]'::jsonb)
                 from (select * from m limit 5) x))
  into v;
  return v;
end $fn$;

create or replace function public.cxp_regla_guardar(p_org uuid, p_id uuid, p_datos jsonb) returns uuid
  language plpgsql security definer set search_path to ''
as $fn$
declare
  r public.cxp_reglas%rowtype;
  v_tipo text; v_t text; v_doc text; v_det text; v_nom text; v_ctx text; v_nota text; v_act boolean; v_id uuid;
begin
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;
  if p_id is null then
    perform public._exigir_permiso(p_org, 'cxp_reglas', 'crear');
  else
    perform public._exigir_permiso(p_org, 'cxp_reglas', 'editar');
    select * into r from public.cxp_reglas where id = p_id and organizacion_id = p_org for update;
    if not found then raise exception 'Regla no encontrada'; end if;
  end if;

  v_tipo := case when p_datos ? 'tipo' then p_datos->>'tipo' else r.tipo end;
  if v_tipo is null or v_tipo not in ('documento', 'patron') then raise exception 'Tipo de regla no válido'; end if;
  v_t := case when p_datos ? 'tercero' then public._cxp_nit(p_datos->>'tercero') else r.tercero end;
  if v_t is null then raise exception 'Escribe el NIT del tercero'; end if;

  v_doc := case when v_tipo <> 'documento' then null
                when p_datos ? 'documento_erp' then nullif(btrim(p_datos->>'documento_erp'), '') else r.documento_erp end;
  v_det := case when v_tipo <> 'patron' then null
                when p_datos ? 'detalle' then nullif(btrim(p_datos->>'detalle'), '') else r.detalle end;
  if v_tipo = 'documento' and v_doc is null then raise exception 'Escribe el número de documento del ERP'; end if;
  if v_tipo = 'patron' and v_det is null then raise exception 'Escribe el detalle exacto que trae el ERP'; end if;
  if char_length(coalesce(v_doc, '')) > 60 then raise exception 'El documento no puede superar 60 caracteres'; end if;
  if char_length(coalesce(v_det, '')) > 300 then raise exception 'El detalle no puede superar 300 caracteres'; end if;

  v_ctx := upper(case when p_datos ? 'contexto' then nullif(btrim(p_datos->>'contexto'), '') else r.contexto end);
  if v_ctx is null then raise exception 'Elige un contexto (la nota para contabilidad)'; end if;
  if char_length(v_ctx) > 60 then raise exception 'El contexto no puede superar 60 caracteres'; end if;
  v_nota := case when p_datos ? 'nota' then nullif(btrim(p_datos->>'nota'), '') else r.nota end;
  if char_length(coalesce(v_nota, '')) > 500 then raise exception 'La nota no puede superar 500 caracteres'; end if;
  v_nom := case when p_datos ? 'nombre_ref' then nullif(btrim(p_datos->>'nombre_ref'), '') else r.nombre_ref end;
  if v_nom is null then
    select d.nombre into v_nom from public.cxp_documentos d
     where d.organizacion_id = p_org and d.tercero = v_t order by d.updated_at desc limit 1;
  end if;
  if char_length(coalesce(v_nom, '')) > 200 then raise exception 'El nombre no puede superar 200 caracteres'; end if;
  v_act := case when p_datos ? 'activa' then coalesce((p_datos->>'activa')::boolean, true) else coalesce(r.activa, true) end;

  begin
    if p_id is null then
      insert into public.cxp_reglas
        (organizacion_id, tipo, tercero, documento_erp, detalle, nombre_ref, contexto, nota, activa, creado_por)
      values (p_org, v_tipo, v_t, v_doc, v_det, v_nom, v_ctx, v_nota, v_act, auth.uid())
      returning id into v_id;
    else
      update public.cxp_reglas set
        tipo = v_tipo, tercero = v_t, documento_erp = v_doc, detalle = v_det, nombre_ref = v_nom,
        contexto = v_ctx, nota = v_nota, activa = v_act
      where id = p_id;
      v_id := p_id;
    end if;
  exception when unique_violation then
    raise exception 'Ya existe una regla igual para ese tercero';
  end;

  perform public._cxp_aplicar_reglas(p_org);
  return v_id;
end $fn$;

create or replace function public.cxp_regla_eliminar(p_org uuid, p_id uuid) returns void
  language plpgsql security definer set search_path to ''
as $fn$
begin
  perform public._exigir_permiso(p_org, 'cxp_reglas', 'eliminar');
  delete from public.cxp_reglas where id = p_id and organizacion_id = p_org;
  if not found then raise exception 'Regla no encontrada'; end if;
  perform public._cxp_aplicar_reglas(p_org);
end $fn$;

-- 7. Carga desde el ERP ---------------------------------------------------------------------------------------
-- Valida y normaliza las filas que llegan (Excel hoy, API mañana: el formato es el mismo).
create or replace function public._cxp_filas_import(p_filas jsonb)
returns table (
  fila integer, empresa text, tercero text, nombre text, co_codigo text, co_nombre text, cond_pago text,
  docto_proveedor text, documento_erp text, fecha_dcto date, fecha_vcto date, plazo integer,
  saldo numeric, detalle text, raw jsonb
)
  language plpgsql stable set search_path to ''
as $fn$
declare
  e jsonb; i integer := 0; seen text[] := array[]::text[]; v_key text;
begin
  if p_filas is null or jsonb_typeof(p_filas) <> 'array' or jsonb_array_length(p_filas) = 0 then
    raise exception 'El archivo no trae filas';
  end if;
  if jsonb_array_length(p_filas) > 5000 then raise exception 'Máximo 5000 filas por carga'; end if;

  for e in select x from jsonb_array_elements(p_filas) x loop
    i := i + 1;
    fila := coalesce(nullif(e->>'fila', '')::integer, i);
    begin
      tercero := public._cxp_nit(e->>'tercero');
    exception when others then
      raise exception 'Fila %: %', fila, sqlerrm;
    end;
    if tercero is null then raise exception 'Fila %: falta el tercero (NIT)', fila; end if;

    documento_erp := nullif(btrim(e->>'documento_erp'), '');
    if documento_erp is null then raise exception 'Fila %: falta el número de documento', fila; end if;
    if char_length(documento_erp) > 60 then raise exception 'Fila %: el documento es demasiado largo', fila; end if;

    nombre := nullif(btrim(e->>'nombre'), '');
    if nombre is null then raise exception 'Fila %: falta el nombre del tercero', fila; end if;
    nombre := left(nombre, 200);

    saldo := nullif(btrim(e->>'saldo'), '')::numeric;
    if saldo is null then raise exception 'Fila %: falta el saldo', fila; end if;

    fecha_dcto := nullif(btrim(e->>'fecha_dcto'), '')::date;
    fecha_vcto := nullif(btrim(e->>'fecha_vcto'), '')::date;
    if fecha_vcto is null then raise exception 'Fila %: falta la fecha de vencimiento', fila; end if;
    -- El ERP a veces trae el vencimiento anterior al documento (se causó días después): se usa la fecha del documento.
    if fecha_dcto is not null and fecha_vcto < fecha_dcto then fecha_vcto := fecha_dcto; end if;

    empresa         := nullif(btrim(e->>'empresa'), '');
    co_codigo       := nullif(btrim(e->>'co_codigo'), '');
    co_nombre       := nullif(btrim(e->>'co_nombre'), '');
    cond_pago       := left(nullif(btrim(e->>'cond_pago'), ''), 60);
    docto_proveedor := left(nullif(btrim(e->>'docto_proveedor'), ''), 100);
    plazo           := (nullif(btrim(e->>'plazo'), '')::numeric)::integer;
    detalle         := nullif(btrim(e->>'detalle'), '');
    raw             := case when jsonb_typeof(e->'raw') = 'object' then e->'raw' else null end;

    v_key := lower(coalesce(empresa, '')) || '|' || tercero || '|' || lower(documento_erp);
    if v_key = any(seen) then
      raise exception 'Fila %: el documento % del tercero % está repetido en el archivo', fila, documento_erp, tercero;
    end if;
    seen := array_append(seen, v_key);
    return next;
  end loop;
end $fn$;

-- Vista previa: no escribe nada.
create or replace function public.cxp_importar_previsualizar(p_org uuid, p_filas jsonb, p_hash text default null)
returns jsonb
  language plpgsql stable security definer set search_path to ''
as $fn$
declare v jsonb;
begin
  perform public._exigir_permiso(p_org, 'cxp_importar', 'crear');

  with f as (select * from public._cxp_filas_import(p_filas)),
  c as (
    select f.*, d.id as doc_id, d.estado as doc_estado, d.total_factura as total_ant,
           public._cxp_regla_de(p_org, f.tercero, f.documento_erp, f.detalle) as regla_nueva,
           (d.id is not null and (
              d.total_factura is distinct from f.saldo or d.fecha_vcto is distinct from f.fecha_vcto
              or d.fecha_dcto is distinct from f.fecha_dcto or d.nombre is distinct from f.nombre
              or d.detalle_erp is distinct from f.detalle or d.cond_pago is distinct from f.cond_pago
              or d.docto_proveedor is distinct from f.docto_proveedor or d.co_codigo is distinct from f.co_codigo
           )) as cambio
    from f
    left join public.cxp_documentos d
      on d.organizacion_id = p_org and d.origen = 'erp'
     and coalesce(d.empresa, '') = coalesce(f.empresa, '') and d.tercero = f.tercero
     and lower(btrim(d.documento_erp)) = lower(btrim(f.documento_erp))
  ),
  ausentes as (
    select d.nombre, d.documento_erp, d.total_factura
    from public.cxp_documentos d
    where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente'
      and not exists (
        select 1 from f
        where coalesce(f.empresa, '') = coalesce(d.empresa, '') and f.tercero = d.tercero
          and lower(btrim(f.documento_erp)) = lower(btrim(d.documento_erp)))
  ),
  cos_co as (
    select f.co_codigo, max(f.co_nombre) as co_nombre, count(*) as filas
    from f where f.co_codigo is not null group by f.co_codigo
  )
  select jsonb_build_object(
    'total', (select count(*) from c),
    'nuevos', (select count(*) from c where doc_id is null),
    'nuevos_excluidos', (select count(*) from c where doc_id is null and regla_nueva is not null),
    'actualizados', (select count(*) from c where doc_estado = 'pendiente' and cambio),
    'sin_cambios', (select count(*) from c where doc_estado = 'pendiente' and not cambio),
    'pagados_omitidos', (select count(*) from c where doc_estado = 'pagado'),
    'pagados_saldo_distinto', (
      select coalesce(jsonb_agg(jsonb_build_object('nombre', x.nombre, 'documento', x.documento_erp,
                                                   'saldo_pagado', x.total_ant, 'saldo_erp', x.saldo) order by x.nombre), '[]'::jsonb)
      from (select * from c where doc_estado = 'pagado' and total_ant is distinct from saldo limit 50) x),
    'cambios_de_saldo', (
      select coalesce(jsonb_agg(jsonb_build_object('nombre', x.nombre, 'documento', x.documento_erp,
                                                   'saldo_anterior', x.total_ant, 'saldo_nuevo', x.saldo) order by x.nombre), '[]'::jsonb)
      from (select * from c where doc_estado = 'pendiente' and total_ant is distinct from saldo limit 50) x),
    'ausentes', (select count(*) from ausentes),
    'ausentes_lista', (
      select coalesce(jsonb_agg(jsonb_build_object('nombre', x.nombre, 'documento', x.documento_erp,
                                                   'saldo', x.total_factura) order by x.nombre), '[]'::jsonb)
      from (select * from ausentes limit 50) x),
    'cos', (
      select coalesce(jsonb_agg(jsonb_build_object('codigo', co.co_codigo, 'nombre', co.co_nombre,
                                                   'filas', co.filas, 'sede_id', m.sede_id) order by co.co_codigo), '[]'::jsonb)
      from cos_co co
      left join public.cxp_co_sede m on m.organizacion_id = p_org and m.co_codigo = co.co_codigo),
    'repetido', (
      select jsonb_build_object('fecha', i.created_at, 'archivo', i.archivo)
      from public.cxp_importaciones i
      where i.organizacion_id = p_org and p_hash is not null and i.archivo_hash = p_hash
      order by i.created_at desc limit 1)
  ) into v;
  return v;
end $fn$;

-- Carga: agrega lo nuevo, actualiza lo del ERP (conserva anticipos, descuentos, retenciones y detalles),
-- omite lo ya pagado y recalcula las reglas. Volver a cargar el mismo archivo no cambia nada.
create or replace function public.cxp_importar_confirmar(
  p_org uuid, p_filas jsonb, p_archivo text default null, p_hash text default null
) returns jsonb
  language plpgsql security definer set search_path to ''
as $fn$
declare
  v_total integer; v_omit integer; v_nuevos integer; v_act integer; v_aus integer; v_excl integer;
  v_res jsonb; v_imp uuid;
begin
  perform public._exigir_permiso(p_org, 'cxp_importar', 'crear');
  perform pg_advisory_xact_lock(hashtext('cxp_imp:' || p_org::text));

  drop table if exists pg_temp._cxp_f;
  create temp table _cxp_f on commit drop as select * from public._cxp_filas_import(p_filas);

  select count(*) into v_total from pg_temp._cxp_f;
  select count(*) into v_omit
    from pg_temp._cxp_f f
    join public.cxp_documentos d
      on d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pagado'
     and coalesce(d.empresa, '') = coalesce(f.empresa, '') and d.tercero = f.tercero
     and lower(btrim(d.documento_erp)) = lower(btrim(f.documento_erp));

  with up as (
    insert into public.cxp_documentos
      (organizacion_id, origen, empresa, tercero, nombre, cond_pago, docto_proveedor, fecha_dcto, fecha_vcto,
       plazo, documento_erp, co_codigo, sede_id, detalle_erp, erp_raw, total_factura, creado_por)
    select p_org, 'erp', f.empresa, f.tercero, f.nombre, f.cond_pago, f.docto_proveedor, f.fecha_dcto, f.fecha_vcto,
           f.plazo, f.documento_erp, f.co_codigo, m.sede_id, f.detalle, f.raw, f.saldo, auth.uid()
    from pg_temp._cxp_f f
    left join public.cxp_co_sede m on m.organizacion_id = p_org and m.co_codigo = f.co_codigo
    where not exists (
      select 1 from public.cxp_documentos p
      where p.organizacion_id = p_org and p.origen = 'erp' and p.estado = 'pagado'
        and coalesce(p.empresa, '') = coalesce(f.empresa, '') and p.tercero = f.tercero
        and lower(btrim(p.documento_erp)) = lower(btrim(f.documento_erp)))
    on conflict (organizacion_id, coalesce(empresa, ''), tercero, lower(btrim(documento_erp))) where origen = 'erp'
    do update set
      nombre = excluded.nombre, cond_pago = excluded.cond_pago, docto_proveedor = excluded.docto_proveedor,
      fecha_dcto = excluded.fecha_dcto, fecha_vcto = excluded.fecha_vcto, plazo = excluded.plazo,
      co_codigo = excluded.co_codigo, sede_id = coalesce(excluded.sede_id, public.cxp_documentos.sede_id),
      detalle_erp = excluded.detalle_erp, erp_raw = excluded.erp_raw, total_factura = excluded.total_factura
    where (public.cxp_documentos.nombre, public.cxp_documentos.cond_pago, public.cxp_documentos.docto_proveedor,
           public.cxp_documentos.fecha_dcto, public.cxp_documentos.fecha_vcto, public.cxp_documentos.plazo,
           public.cxp_documentos.co_codigo, public.cxp_documentos.detalle_erp, public.cxp_documentos.total_factura)
      is distinct from
          (excluded.nombre, excluded.cond_pago, excluded.docto_proveedor, excluded.fecha_dcto, excluded.fecha_vcto,
           excluded.plazo, excluded.co_codigo, excluded.detalle_erp, excluded.total_factura)
    returning (xmax = 0) as es_nuevo
  )
  select count(*) filter (where es_nuevo), count(*) filter (where not es_nuevo)
    into v_nuevos, v_act from up;

  select count(*) into v_aus
    from public.cxp_documentos d
   where d.organizacion_id = p_org and d.origen = 'erp' and d.estado = 'pendiente'
     and not exists (
       select 1 from pg_temp._cxp_f f
       where coalesce(f.empresa, '') = coalesce(d.empresa, '') and f.tercero = d.tercero
         and lower(btrim(f.documento_erp)) = lower(btrim(d.documento_erp)));

  perform public._cxp_aplicar_reglas(p_org);
  select count(*) into v_excl from public.cxp_documentos
   where organizacion_id = p_org and estado = 'pendiente' and regla_id is not null;

  v_res := jsonb_build_object(
    'total', v_total, 'nuevos', v_nuevos, 'actualizados', v_act,
    'sin_cambios', v_total - v_omit - v_nuevos - v_act,
    'pagados_omitidos', v_omit, 'ausentes', v_aus, 'excluidos', v_excl);

  insert into public.cxp_importaciones (organizacion_id, fuente, archivo, archivo_hash, filas, resumen, usuario_id)
  values (p_org, 'excel', left(p_archivo, 200), p_hash, v_total, v_res, auth.uid())
  returning id into v_imp;

  return v_res || jsonb_build_object('importacion_id', v_imp);
end $fn$;

create or replace function public.cxp_importaciones_listar(p_org uuid, p_limit integer default 10)
returns table (id uuid, fecha timestamptz, archivo text, usuario text, filas integer, resumen jsonb)
  language plpgsql stable security definer set search_path to ''
as $fn$
#variable_conflict use_column
begin
  perform public._exigir_permiso(p_org, 'cxp_importar', 'ver');
  return query
  select i.id, i.created_at, i.archivo,
         nullif(trim(coalesce(pu.nombres, '') || ' ' || coalesce(pu.apellidos, '')), ''), i.filas, i.resumen
  from public.cxp_importaciones i
  left join public.profiles pu on pu.id = i.usuario_id
  where i.organizacion_id = p_org
  order by i.created_at desc
  limit least(greatest(p_limit, 1), 50);
end $fn$;

-- Equivalencia C.O. del ERP ↔ sede. Al guardarla, también se corrige la sede de lo ya cargado.
create or replace function public.cxp_co_sede_guardar(p_org uuid, p_codigo text, p_nombre text, p_sede uuid)
returns integer
  language plpgsql security definer set search_path to ''
as $fn$
declare v_cod text := nullif(btrim(p_codigo), ''); v_n integer;
begin
  perform public._exigir_permiso(p_org, 'cxp_importar', 'editar');
  if v_cod is null or char_length(v_cod) > 20 then raise exception 'Código de C.O. no válido'; end if;
  if p_sede is not null and not exists (select 1 from public.sedes where id = p_sede and organizacion_id = p_org) then
    raise exception 'La sede no pertenece a esta organización';
  end if;

  insert into public.cxp_co_sede (organizacion_id, co_codigo, co_nombre, sede_id)
  values (p_org, v_cod, left(nullif(btrim(p_nombre), ''), 120), p_sede)
  on conflict (organizacion_id, co_codigo) do update
    set co_nombre = coalesce(excluded.co_nombre, public.cxp_co_sede.co_nombre),
        sede_id = excluded.sede_id, updated_at = now();

  update public.cxp_documentos
     set sede_id = p_sede
   where organizacion_id = p_org and origen = 'erp' and co_codigo = v_cod and sede_id is distinct from p_sede;
  get diagnostics v_n = row_count;
  return v_n;
end $fn$;

-- 8. Permisos de ejecución (vuelve a recorrer todas las funciones cxp) ---------------------------------------
do $do$
declare r record;
begin
  for r in
    select p.oid::regprocedure as f, p.proname
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and (p.proname like 'cxp\_%' escape '\' or p.proname like '\_cxp\_%' escape '\')
  loop
    execute format('revoke all on function %s from public, anon', r.f);
    if r.proname like 'cxp\_%' escape '\' then
      execute format('grant execute on function %s to authenticated', r.f);
    end if;
    execute format('grant execute on function %s to service_role', r.f);
  end loop;
end $do$;

commit;
