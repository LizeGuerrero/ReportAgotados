-- =====================================================================================
-- 02_pedidos_flujo_masivo.sql
--
-- Qué hace (todo es aditivo: no borra datos de negocio):
--   1. Módulos nuevos: `pedidos_ganador` (elegir proveedor ganador y generar órdenes de compra)
--      y `mensajes` (estructuras de mensajes). Inserción SIN duplicar módulos ni permisos.
--   2. Los roles que hoy tienen `pedidos` conservan lo que ya podían hacer: copian su permiso a
--      `pedidos_ganador`. Los administradores reciben `mensajes`.
--   3. Permisos: elegir ganador / generar órdenes ahora exigen `pedidos_ganador`; crear un proveedor
--      o vincularlo a un ítem desde Pedidos exige `Proveedores / crear` (antes no se validaba).
--   4. Operaciones masivas: elegir ganadores, generar todas las órdenes, responder agotados.
--   5. Búsquedas: listar_items_catalogo / listar_items_proveedor aceptan una preselección;
--      matriz_cotizaciones filtra por proveedor y estado en el servidor.
--   6. Estructuras de mensajes por organización (tablas + RPC) y textos de solicitud / orden
--      generados desde esa configuración (datos internos ya no viajan al proveedor).
--
-- Ejecutar completo, en una sola transacción. Es idempotente (se puede volver a correr).
-- =====================================================================================

begin;

-- -------------------------------------------------------------------------------------
-- 1. Módulos nuevos (sin duplicar)
-- -------------------------------------------------------------------------------------
insert into public.modulos (nombre, descripcion)
select v.nombre, v.descripcion
from (values
  ('pedidos_ganador', 'Pedidos: elegir el proveedor ganador y generar órdenes de compra'),
  ('mensajes',        'Estructuras de los mensajes que Pedidos genera para proveedores')
) as v(nombre, descripcion)
where not exists (select 1 from public.modulos m where m.nombre = v.nombre)
on conflict (nombre) do nothing;

-- -------------------------------------------------------------------------------------
-- 2. Permisos de los roles existentes (sin duplicar; sin llenar el historial con ruido)
-- -------------------------------------------------------------------------------------
alter table public.permisos_rol disable trigger aud_permisos;

-- Quien ya podía operar en "pedidos" conserva exactamente lo mismo en "pedidos_ganador".
insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
select pr.rol_id, mg.id, pr.puede_ver, pr.puede_crear, pr.puede_editar, pr.puede_eliminar
from public.permisos_rol pr
join public.modulos mp on mp.id = pr.modulo_id and mp.nombre = 'pedidos'
join public.modulos mg on mg.nombre = 'pedidos_ganador'
on conflict (rol_id, modulo_id) do nothing;

-- Mensajes: solo los administradores de cada organización (los demás roles se asignan desde Roles).
insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
select r.id, mm.id, true, true, true, true
from public.roles r
join public.modulos mm on mm.nombre = 'mensajes'
where r.nombre = 'admin' and r.organizacion_id is not null
on conflict (rol_id, modulo_id) do nothing;

alter table public.permisos_rol enable trigger aud_permisos;

-- Matriz base de roles (la usan "restablecer rol" y las organizaciones nuevas).
create or replace function public._permisos_base(p_nombre text)
returns table(modulo text, ver boolean, crear boolean, editar boolean, eliminar boolean)
language sql immutable
set search_path to ''
as $$
  select x.modulo, x.ver, x.crear, x.editar, x.eliminar
  from (values
    ('Bodega',    'Agotados',         true, false, true,  false),
    ('Bodega',    'Bodega',           true, true,  true,  false),
    ('Comercial', 'Agotados',         true, true,  true,  false),
    ('Comercial', 'reporte_agotados', true, true,  true,  false),
    ('Compras',   'Agotados',         true, false, false, false),
    ('Compras',   'Compras',          true, true,  true,  false),
    ('Compras',   'Items',            true, false, false, false),
    ('Compras',   'pedidos',          true, true,  true,  false),
    ('Compras',   'pedidos_ganador',  true, true,  true,  false),
    ('Compras',   'Proveedores',      true, true,  true,  false),
    ('Gerencia',  'Agotados',         true, false, true,  false),
    ('Gerencia',  'Bodega',           true, false, false, false),
    ('Gerencia',  'Compras',          true, false, false, false),
    ('Gerencia',  'Items',            true, false, false, false),
    ('Gerencia',  'Proveedores',      true, false, false, false)
  ) as x(rol, modulo, ver, crear, editar, eliminar)
  where x.rol = p_nombre
$$;

-- Organizaciones nuevas: la matriz sale de _permisos_base (una sola fuente de verdad).
create or replace function public.crear_organizacion(p_nombre text, p_identificacion text)
returns text
language plpgsql
security definer
set search_path to ''
as $_$
declare
  v_uid    uuid := auth.uid();
  v_nombre text := btrim(coalesce(p_nombre, ''));
  v_ident  text := public.normalizar_identificacion(p_identificacion);
  v_base   text;
  v_slug   text;
  v_org    uuid;
  v_sede   uuid;
  v_admin  uuid;
begin
  if v_uid is null then raise exception 'No autenticado'; end if;
  if not exists (select 1 from public.profiles where id = v_uid and perfil_completo) then
    raise exception 'Completa tu perfil antes de crear una organización';
  end if;
  if char_length(v_nombre) < 3 or char_length(v_nombre) > 120 then
    raise exception 'El nombre de la organización debe tener entre 3 y 120 caracteres';
  end if;
  if v_ident is null or v_ident !~ '^[A-Z0-9-]{5,20}$' then
    raise exception 'Identificación no válida: 5 a 20 caracteres, solo letras, números o guion';
  end if;
  if exists (select 1 from public.organizaciones where identificacion = v_ident) then
    raise exception 'Ya existe una organización con esa identificación';
  end if;

  v_base := regexp_replace(
    lower(translate(v_nombre, 'áéíóúüñÁÉÍÓÚÜÑ', 'aeiouunaeiouun')), '[^a-z0-9]+', '-', 'g');
  v_base := btrim(left(btrim(v_base, '-'), 40), '-');
  if v_base = '' then v_base := 'org'; end if;
  v_slug := v_base;
  while exists (select 1 from public.organizaciones where slug = v_slug) loop
    v_slug := v_base || '-' || substr(md5(random()::text || clock_timestamp()::text), 1, 4);
  end loop;

  begin
    insert into public.organizaciones (slug, nombre, identificacion, propietario_id)
    values (v_slug, v_nombre, v_ident, v_uid)
    returning id into v_org;
  exception when unique_violation then
    raise exception 'No se pudo crear la organización: la identificación o el nombre ya están en uso';
  end;

  insert into public.sedes (organizacion_id, nombre) values (v_org, 'Principal')
  returning id into v_sede;

  insert into public.roles (nombre, organizacion_id, descripcion) values
    ('admin',     v_org, 'Administrador de la organización'),
    ('Gerencia',  v_org, null),
    ('Compras',   v_org, null),
    ('Bodega',    v_org, null),
    ('Comercial', v_org, null),
    ('viewer',    v_org, 'Predeterminado: sin acceso a módulos');

  -- admin: todos los módulos con todos los permisos
  insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
  select r.id, mo.id, true, true, true, true
  from public.roles r
  cross join public.modulos mo
  where r.organizacion_id = v_org and r.nombre = 'admin';

  -- demás roles base: matriz única (_permisos_base)
  insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
  select r.id, mo.id, b.ver, b.crear, b.editar, b.eliminar
  from public.roles r
  cross join lateral public._permisos_base(r.nombre) b
  join public.modulos mo on mo.nombre = b.modulo
  where r.organizacion_id = v_org and r.nombre in ('Gerencia', 'Compras', 'Bodega', 'Comercial');

  select id into v_admin from public.roles where organizacion_id = v_org and nombre = 'admin';

  insert into public.membresias (usuario_id, organizacion_id, rol_id, estado_membresia, activo, sede_id)
  values (v_uid, v_org, v_admin, 'activa', true, v_sede);

  return v_slug;
end $_$;

-- -------------------------------------------------------------------------------------
-- 3. Permisos: ganador + RLS alineada con el módulo "pedidos"
-- -------------------------------------------------------------------------------------
create or replace function public._pedidos_ganador_check(p_org uuid, p_accion text)
returns void
language plpgsql
stable
security definer
set search_path to ''
as $$
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if not public.tiene_permiso(p_org, 'pedidos_ganador', p_accion) then
    raise exception 'Sin permiso para % en la elección de proveedor y las órdenes de compra', p_accion;
  end if;
end $$;

revoke all on function public._pedidos_ganador_check(uuid, text) from public, anon, authenticated;
grant all on function public._pedidos_ganador_check(uuid, text) to service_role;

-- Las RPC de Pedidos validan el módulo "pedidos", pero estas tablas solo se podían leer con
-- "Compras": un rol con "pedidos" sin "Compras" no recibía los eventos de tiempo real.
drop policy if exists "solicitudes_cotizacion_select_pedidos" on public.solicitudes_cotizacion;
create policy "solicitudes_cotizacion_select_pedidos" on public.solicitudes_cotizacion
  for select using (public.tiene_permiso(organizacion_id, 'pedidos', 'ver'));

drop policy if exists "ordenes_compra_select_pedidos" on public.ordenes_compra;
create policy "ordenes_compra_select_pedidos" on public.ordenes_compra
  for select using (public.tiene_permiso(organizacion_id, 'pedidos', 'ver'));

drop policy if exists "solicitud_items_select_pedidos" on public.solicitud_items;
create policy "solicitud_items_select_pedidos" on public.solicitud_items
  for select using (public.tiene_permiso(
    (select sc.organizacion_id from public.solicitudes_cotizacion sc where sc.id = solicitud_items.solicitud_id),
    'pedidos', 'ver'));

drop policy if exists "cotizacion_precios_select_pedidos" on public.cotizacion_precios;
create policy "cotizacion_precios_select_pedidos" on public.cotizacion_precios
  for select using (public.tiene_permiso(
    (select sc.organizacion_id
       from public.solicitud_items si
       join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
      where si.id = cotizacion_precios.solicitud_item_id),
    'pedidos', 'ver'));

-- Elegir (o quitar) el ganador de un ítem: ahora es "pedidos_ganador / editar".
create or replace function public.cotizacion_elegir(
  p_org uuid, p_cotizacion uuid, p_cantidad_pedir numeric default null::numeric, p_elegir boolean default true)
returns void
language plpgsql
security definer
set search_path to ''
as $$
declare
  v_cp public.cotizacion_precios; v_si public.solicitud_items;
  v_sc public.solicitudes_cotizacion; v_cant numeric;
begin
  perform public._pedidos_ganador_check(p_org, 'editar');

  select * into v_cp from public.cotizacion_precios where id = p_cotizacion;
  if v_cp.id is null then raise exception 'Cotización no encontrada'; end if;
  select * into v_si from public.solicitud_items where id = v_cp.solicitud_item_id;
  select * into v_sc from public.solicitudes_cotizacion where id = v_si.solicitud_id;
  if v_sc.organizacion_id <> p_org then raise exception 'Cotización no encontrada'; end if;
  if v_si.estado <> 'activo' then raise exception 'Esta cotización ya está cerrada'; end if;

  if not p_elegir then
    update public.cotizacion_precios set seleccionado = false, cantidad_pedir = null where id = v_cp.id;
    return;
  end if;

  if v_cp.disponible is not true or v_cp.costo_unitario is null then
    raise exception 'Solo puedes elegir una cotización con costo y disponibilidad';
  end if;

  v_cant := coalesce(p_cantidad_pedir, v_cp.cantidad_pedir, v_si.cantidad_a_cotizar);
  if v_cant is null or v_cant <= 0 then raise exception 'Define la cantidad a pedir'; end if;

  update public.cotizacion_precios cp set seleccionado = false, cantidad_pedir = null
  from public.solicitud_items si2, public.solicitudes_cotizacion sc2
  where si2.id = cp.solicitud_item_id and sc2.id = si2.solicitud_id
    and sc2.organizacion_id = p_org and si2.item_id = v_si.item_id
    and si2.estado = 'activo' and cp.id <> v_cp.id and cp.seleccionado;

  update public.cotizacion_precios set seleccionado = true, cantidad_pedir = v_cant where id = v_cp.id;
end $$;

-- Elegir en bloque. p_items = [{item_id, proveedor_id?, cantidad?}]
--   · con proveedor_id: se elige la cotización de ese proveedor;
--   · sin proveedor_id: se elige la de menor costo con IVA (solo entre las disponibles y con costo).
-- p_quitar = true: deja sin elección a los ítems indicados.
-- Cada ítem es independiente: los que no se pueden elegir se informan, no frenan al resto.
create or replace function public.cotizacion_elegir_masivo(
  p_org uuid, p_items jsonb, p_quitar boolean default false)
returns jsonb
language plpgsql
security definer
set search_path to ''
as $$
declare
  e jsonb; v_item bigint; v_prov bigint; v_cant numeric; v_cp uuid;
  v_ok integer := 0; v_omit jsonb := '[]'::jsonb;
begin
  perform public._pedidos_ganador_check(p_org, 'editar');
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Selecciona al menos un ítem';
  end if;
  if jsonb_array_length(p_items) > 500 then raise exception 'Máximo 500 ítems por operación'; end if;

  for e in select x from jsonb_array_elements(p_items) x loop
    begin
      v_item := (e->>'item_id')::bigint;
      v_prov := nullif(e->>'proveedor_id', '')::bigint;
      v_cant := nullif(e->>'cantidad', '')::numeric;

      if p_quitar then
        update public.cotizacion_precios cp set seleccionado = false, cantidad_pedir = null
        from public.solicitud_items si
        join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
        where si.id = cp.solicitud_item_id and sc.organizacion_id = p_org
          and si.item_id = v_item and si.estado = 'activo' and cp.seleccionado;
        v_ok := v_ok + 1;
        continue;
      end if;

      v_cp := null;
      select cp.id into v_cp
      from public.cotizacion_precios cp
      join public.solicitud_items si on si.id = cp.solicitud_item_id
      join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
      where sc.organizacion_id = p_org and si.item_id = v_item and si.estado = 'activo'
        and cp.disponible is true and cp.costo_unitario is not null
        and (v_prov is null or cp.proveedor_id = v_prov)
      order by cp.costo_con_iva, cp.dias_entrega nulls last, cp.id
      limit 1;

      if v_cp is null then
        v_omit := v_omit || jsonb_build_array(jsonb_build_object(
          'item_id', v_item, 'motivo', 'No hay una cotización con costo y disponibilidad'));
        continue;
      end if;

      perform public.cotizacion_elegir(p_org, v_cp, v_cant, true);
      v_ok := v_ok + 1;
    exception when others then
      v_omit := v_omit || jsonb_build_array(jsonb_build_object(
        'item_id', e->>'item_id', 'motivo', sqlerrm));
    end;
  end loop;

  if v_ok > 0 then
    perform public._auditar(p_org, 'seleccion_masiva',
      case when p_quitar then 'quitó la elección de ' else 'eligió proveedor para ' end || v_ok || ' ítem(s) en bloque');
  end if;
  return jsonb_build_object('procesados', v_ok, 'omitidos', v_omit);
end $$;

-- Generar la orden de un proveedor: ahora es "pedidos_ganador / crear".
create or replace function public.orden_compra_generar(p_org uuid, p_proveedor bigint)
returns uuid
language plpgsql
security definer
set search_path to ''
as $$
declare v_sede uuid; v_oc uuid; v_num integer; v_total numeric; v_n integer; r record; v_prov text;
begin
  perform public._pedidos_ganador_check(p_org, 'crear');
  select m.sede_id into v_sede
  from public.membresias m
  where m.usuario_id = auth.uid() and m.organizacion_id = p_org
    and m.activo = true and m.estado_membresia = 'activa' and m.sede_id is not null
  limit 1;

  perform 1
  from public.cotizacion_precios cp
  join public.solicitud_items si on si.id = cp.solicitud_item_id
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
  where sc.organizacion_id = p_org and cp.proveedor_id = p_proveedor
    and cp.seleccionado and si.estado = 'activo'
  for update of cp;

  select count(*), coalesce(sum(cp.cantidad_pedir * cp.costo_con_iva), 0) into v_n, v_total
  from public.cotizacion_precios cp
  join public.solicitud_items si on si.id = cp.solicitud_item_id
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
  where sc.organizacion_id = p_org and cp.proveedor_id = p_proveedor
    and cp.seleccionado and si.estado = 'activo';

  if v_n = 0 then raise exception 'No hay ítems elegidos para este proveedor'; end if;

  if exists (
    select 1 from public.cotizacion_precios cp
    join public.solicitud_items si on si.id = cp.solicitud_item_id
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
    where sc.organizacion_id = p_org and cp.proveedor_id = p_proveedor
      and cp.seleccionado and si.estado = 'activo' and cp.cantidad_pedir is null
  ) then
    raise exception 'Hay ítems elegidos sin cantidad a pedir';
  end if;

  v_num := public._siguiente_consecutivo(p_org, 'orden');
  insert into public.ordenes_compra (organizacion_id, proveedor_id, sede_id, creado_por, numero, total)
  values (p_org, p_proveedor, v_sede, auth.uid(), v_num, v_total)
  returning id into v_oc;

  for r in
    select cp.id as cp_id, si.item_id, cp.cantidad_pedir, cp.costo_unitario
    from public.cotizacion_precios cp
    join public.solicitud_items si on si.id = cp.solicitud_item_id
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
    where sc.organizacion_id = p_org and cp.proveedor_id = p_proveedor
      and cp.seleccionado and si.estado = 'activo'
  loop
    insert into public.orden_items (orden_id, item_id, cantidad, precio_unitario_acordado, cotizacion_precio_id, sede_id)
    values (v_oc, r.item_id, r.cantidad_pedir, r.costo_unitario, r.cp_id, v_sede);

    update public.agotados set
      respuesta_compras = 'pedido_solicitado', fecha_respuesta = now(), respondido_por = auth.uid()
    where organizacion_id = p_org and item_id = r.item_id
      and estado_comercial is not null and respuesta_compras is null;

    perform public._pedidos_cerrar_item(p_org, r.item_id);
  end loop;

  select pv.nombre into v_prov from public.proveedores pv where pv.id = p_proveedor;
  perform public._auditar(p_org, 'orden_generada',
    'generó la orden OC-' || lpad(v_num::text, 4, '0') || ' para ' || coalesce(v_prov, '?')
    || ' con ' || v_n || ' ítem(s)');
  return v_oc;
end $$;

-- Generar TODAS las órdenes pendientes (una por proveedor). Cada proveedor es independiente:
-- si una falla, las demás se generan y la falla se informa.
create or replace function public.ordenes_compra_generar_todas(p_org uuid, p_proveedores bigint[] default null)
returns jsonb
language plpgsql
security definer
set search_path to ''
as $$
declare r record; v_oc uuid; v_ok jsonb := '[]'::jsonb; v_fall jsonb := '[]'::jsonb;
begin
  perform public._pedidos_ganador_check(p_org, 'crear');
  for r in
    select distinct cp.proveedor_id
    from public.cotizacion_precios cp
    join public.solicitud_items si on si.id = cp.solicitud_item_id
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
    where sc.organizacion_id = p_org and cp.seleccionado and si.estado = 'activo'
      and (p_proveedores is null or cp.proveedor_id = any(p_proveedores))
    order by 1
  loop
    begin
      v_oc := public.orden_compra_generar(p_org, r.proveedor_id);
      v_ok := v_ok || jsonb_build_array(jsonb_build_object('proveedor_id', r.proveedor_id, 'orden_id', v_oc));
    exception when others then
      v_fall := v_fall || jsonb_build_array(jsonb_build_object('proveedor_id', r.proveedor_id, 'error', sqlerrm));
    end;
  end loop;
  return jsonb_build_object('generadas', v_ok, 'fallidas', v_fall);
end $$;

-- Responder agotados en bloque (solo los que siguen sin respuesta; no pisa respuestas ya dadas).
create or replace function public.agotados_responder_masivo(
  p_org uuid, p_items bigint[], p_respuesta text, p_motivo text default null)
returns integer
language plpgsql
security definer
set search_path to ''
as $$
declare v_motivo text := nullif(trim(p_motivo), ''); v_n integer;
begin
  perform public._pedidos_check(p_org, 'editar');
  if p_items is null or cardinality(p_items) = 0 then raise exception 'Selecciona al menos un ítem'; end if;
  if p_respuesta not in ('pedido_solicitado', 'agotado_proveedor', 'repartir_sedes', 'no_se_pide') then
    raise exception 'Respuesta no válida';
  end if;
  if p_respuesta = 'no_se_pide' and v_motivo is null then
    raise exception 'Escribe el motivo por el que no se pide';
  end if;
  update public.agotados set
    respuesta_compras = p_respuesta, fecha_respuesta = now(), respondido_por = auth.uid(),
    motivo_compras = case when p_respuesta = 'no_se_pide' then v_motivo end
  where organizacion_id = p_org and item_id = any(p_items)
    and estado_comercial is not null and respuesta_compras is null;
  get diagnostics v_n = row_count;
  return v_n;
end $$;

-- -------------------------------------------------------------------------------------
-- 4. Solicitudes de cotización: un solo motor y permisos coherentes
-- -------------------------------------------------------------------------------------
create or replace function public.solicitudes_crear_multi(p_org uuid, p_items jsonb)
returns jsonb
language plpgsql
security definer
set search_path to ''
as $$
declare
  rp record; r record;
  v_sc uuid; v_si uuid; v_num integer; v_n integer;
  v_cant numeric; v_sug numeric; v_pend integer; v_origen text;
  v_creadas jsonb := '[]'::jsonb; v_omitidos jsonb := '[]'::jsonb;
begin
  perform public._pedidos_check(p_org, 'crear');
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Selecciona al menos un ítem';
  end if;

  for r in
    select (e->>'item_id')::bigint as item_id,
           nullif(e->>'cantidad', '')::numeric as cantidad,
           coalesce(e->'proveedores', '[]'::jsonb) as provs
    from jsonb_array_elements(p_items) e
  loop
    if jsonb_typeof(r.provs) <> 'array' or jsonb_array_length(r.provs) = 0 then
      raise exception 'El ítem % no tiene proveedores elegidos', r.item_id;
    end if;
    if not exists (select 1 from public.items where id_item = r.item_id and organizacion_id = p_org) then
      raise exception 'El ítem % no existe', r.item_id;
    end if;
    if r.cantidad is not null and r.cantidad <= 0 then
      raise exception 'La cantidad del ítem % debe ser mayor a 0', r.item_id;
    end if;
    select count(*) into v_pend
    from public.agotados a
    where a.organizacion_id = p_org and a.item_id = r.item_id
      and a.estado_comercial is not null and a.respuesta_compras is null;
    if v_pend = 0 and r.cantidad is null then
      raise exception 'Digita la cantidad del ítem %', r.item_id;
    end if;
  end loop;

  for rp in
    select distinct pr.valor::bigint as prov
    from jsonb_array_elements(p_items) e,
         jsonb_array_elements_text(coalesce(e->'proveedores', '[]'::jsonb)) as pr(valor)
    order by 1
  loop
    if not exists (select 1 from public.proveedores where id = rp.prov and organizacion_id = p_org) then
      raise exception 'Proveedor no válido: %', rp.prov;
    end if;
    v_sc := null; v_n := 0;

    for r in
      select (e->>'item_id')::bigint as item_id, nullif(e->>'cantidad', '')::numeric as cantidad
      from jsonb_array_elements(p_items) e
      where exists (
        select 1 from jsonb_array_elements_text(coalesce(e->'proveedores', '[]'::jsonb)) as z(v)
        where z.v::bigint = rp.prov)
    loop
      if exists (
        select 1 from public.solicitud_items si
        join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
        where sc.organizacion_id = p_org and sc.proveedor_id = rp.prov
          and sc.estado <> 'cerrada' and si.item_id = r.item_id and si.estado = 'activo'
      ) then
        v_omitidos := v_omitidos || jsonb_build_array(
          jsonb_build_object('item_id', r.item_id, 'proveedor_id', rp.prov));
        continue;
      end if;

      select sum(a.cantidad_sugerida), count(*) into v_sug, v_pend
      from public.agotados a
      where a.organizacion_id = p_org and a.item_id = r.item_id
        and a.estado_comercial is not null and a.respuesta_compras is null;

      if v_pend > 0 then
        v_origen := 'agotado';
        v_cant := coalesce(r.cantidad, v_sug);
      else
        v_origen := 'manual';
        v_cant := r.cantidad;
      end if;

      if v_sc is null then
        v_num := public._siguiente_consecutivo(p_org, 'solicitud');
        insert into public.solicitudes_cotizacion (organizacion_id, proveedor_id, numero, estado, creado_por)
        values (p_org, rp.prov, v_num, 'borrador', auth.uid())
        returning id into v_sc;
      end if;

      if not exists (select 1 from public.item_proveedor where item_id = r.item_id and proveedor_id = rp.prov) then
        -- vincular un proveedor a un ítem es una alta de Proveedores: se exige ese permiso
        if not public.tiene_permiso(p_org, 'Proveedores', 'crear') then
          raise exception 'Para consultar a un proveedor que el ítem aún no tiene vinculado necesitas permiso de crear en Proveedores';
        end if;
        insert into public.item_proveedor (item_id, proveedor_id) values (r.item_id, rp.prov);
      end if;

      insert into public.solicitud_items (solicitud_id, item_id, cantidad_a_cotizar, origen)
      values (v_sc, r.item_id, v_cant, v_origen)
      returning id into v_si;

      insert into public.cotizacion_precios (solicitud_item_id, proveedor_id)
      values (v_si, rp.prov);

      v_n := v_n + 1;
    end loop;

    if v_sc is not null then
      v_creadas := v_creadas || jsonb_build_array(
        jsonb_build_object('solicitud_id', v_sc, 'proveedor_id', rp.prov, 'items', v_n));
    end if;
  end loop;

  return jsonb_build_object('creadas', v_creadas, 'omitidos', v_omitidos);
end $$;

-- solicitud_crear (un solo proveedor) queda como envoltura del motor único.
create or replace function public.solicitud_crear(p_org uuid, p_proveedor bigint, p_items jsonb)
returns uuid
language plpgsql
security definer
set search_path to ''
as $$
declare v_items jsonb; v_res jsonb;
begin
  select coalesce(jsonb_agg(jsonb_build_object(
           'item_id', e->>'item_id', 'cantidad', e->>'cantidad',
           'proveedores', jsonb_build_array(p_proveedor))), '[]'::jsonb)
    into v_items
  from jsonb_array_elements(case when jsonb_typeof(p_items) = 'array' then p_items else '[]'::jsonb end) e;

  v_res := public.solicitudes_crear_multi(p_org, v_items);
  if jsonb_array_length(v_res->'creadas') = 0 then
    raise exception 'Los ítems ya están en una solicitud abierta con este proveedor';
  end if;
  return ((v_res->'creadas'->0)->>'solicitud_id')::uuid;
end $$;

-- Agregar un proveedor a la cotización de un ítem (desde el detalle): mismo criterio de permisos.
create or replace function public.cotizacion_agregar_proveedor(
  p_org uuid, p_item bigint, p_proveedor bigint default null::bigint, p_tipo_documento text default 'NIT'::text,
  p_documento text default null::text, p_nombre text default null::text, p_referencia text default null::text,
  p_unidades_por_caja integer default null::integer, p_cantidad numeric default null::numeric)
returns uuid
language plpgsql
security definer
set search_path to ''
as $$
declare
  v_prov bigint; v_sc uuid; v_si uuid; v_cp uuid; v_cant numeric; v_pend integer;
  v_num integer; v_origen text;
begin
  perform public._pedidos_check(p_org, 'crear');
  if p_proveedor is null and nullif(btrim(p_documento), '') is null then
    raise exception 'Elige un proveedor o escribe su documento';
  end if;
  if p_unidades_por_caja is not null and p_unidades_por_caja <= 0 then raise exception 'Unidades por caja no válidas'; end if;
  if p_cantidad is not null and p_cantidad <= 0 then raise exception 'Cantidad no válida'; end if;
  if not exists (select 1 from public.items where id_item = p_item and organizacion_id = p_org) then
    raise exception 'Ítem no encontrado';
  end if;

  select sum(a.cantidad_sugerida), count(*) into v_cant, v_pend
  from public.agotados a
  where a.organizacion_id = p_org and a.item_id = p_item
    and a.estado_comercial is not null and a.respuesta_compras is null;

  if v_pend > 0 then
    v_origen := 'agotado';
    v_cant := coalesce(p_cantidad, v_cant);
  else
    v_origen := 'manual';
    select si.cantidad_a_cotizar into v_cant
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
    where sc.organizacion_id = p_org and si.item_id = p_item and si.estado = 'activo'
    order by (si.cantidad_a_cotizar is not null) desc, sc.fecha_creacion desc
    limit 1;
    if not found then
      raise exception 'Este ítem no está en gestión: inícialo desde "Cotizar"';
    end if;
    v_cant := coalesce(p_cantidad, v_cant);
    if v_cant is null then raise exception 'Define la cantidad a cotizar'; end if;
  end if;

  if p_proveedor is not null then
    select pv.id into v_prov from public.proveedores pv where pv.id = p_proveedor and pv.organizacion_id = p_org;
    if v_prov is null then raise exception 'Proveedor no válido'; end if;
  else
    -- puede crear un proveedor nuevo: exige el permiso del módulo Proveedores
    perform public._exigir_permiso(p_org, 'Proveedores', 'crear');
    v_prov := public._proveedor_resolver_o_crear(p_org, p_tipo_documento, p_documento, p_nombre);
  end if;

  if not exists (select 1 from public.item_proveedor where item_id = p_item and proveedor_id = v_prov) then
    if not public.tiene_permiso(p_org, 'Proveedores', 'crear') then
      raise exception 'Para consultar a un proveedor que el ítem aún no tiene vinculado necesitas permiso de crear en Proveedores';
    end if;
    insert into public.item_proveedor (item_id, proveedor_id, codigo_proveedor, unidades_por_caja)
    values (p_item, v_prov, nullif(trim(p_referencia), ''), p_unidades_por_caja);
  else
    update public.item_proveedor ip set
      codigo_proveedor = case
        when coalesce(ip.codigo_proveedor, '') = '' and nullif(trim(p_referencia), '') is not null
             and not exists (select 1 from public.item_proveedor o
                              where o.item_id = ip.item_id and o.proveedor_id = ip.proveedor_id
                                and lower(btrim(o.codigo_proveedor)) = lower(trim(p_referencia)))
        then nullif(trim(p_referencia), '') else ip.codigo_proveedor end,
      unidades_por_caja = coalesce(ip.unidades_por_caja, p_unidades_por_caja)
    where ip.item_id = p_item and ip.proveedor_id = v_prov;
  end if;

  select si.id into v_si
  from public.solicitud_items si
  join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
  where sc.organizacion_id = p_org and sc.proveedor_id = v_prov and sc.estado <> 'cerrada'
    and si.item_id = p_item and si.estado = 'activo'
  limit 1;
  if v_si is not null then
    select cp.id into v_cp from public.cotizacion_precios cp
    where cp.solicitud_item_id = v_si and cp.proveedor_id = v_prov;
    return v_cp;
  end if;

  select sc.id into v_sc from public.solicitudes_cotizacion sc
  where sc.organizacion_id = p_org and sc.proveedor_id = v_prov and sc.estado <> 'cerrada'
  order by sc.fecha_creacion desc limit 1;

  if v_sc is null then
    v_num := public._siguiente_consecutivo(p_org, 'solicitud');
    insert into public.solicitudes_cotizacion (organizacion_id, proveedor_id, numero, estado, creado_por, fecha_envio)
    values (p_org, v_prov, v_num, 'enviada', auth.uid(), now())
    returning id into v_sc;
  end if;

  insert into public.solicitud_items (solicitud_id, item_id, cantidad_a_cotizar, origen)
  values (v_sc, p_item, v_cant, v_origen) returning id into v_si;

  insert into public.cotizacion_precios (solicitud_item_id, proveedor_id)
  values (v_si, v_prov) returning id into v_cp;

  return v_cp;
end $$;

-- -------------------------------------------------------------------------------------
-- 5. Búsquedas: preselección y filtros en el servidor
-- -------------------------------------------------------------------------------------
drop function if exists public.listar_items_catalogo(uuid, text, text, integer, integer);
create or replace function public.listar_items_catalogo(
  p_org uuid, p_linea text default null::text, p_busqueda text default null::text,
  p_limit integer default 50, p_offset integer default 0, p_items bigint[] default null)
returns table(item_id bigint, codigo text, nombre_base text, linea text, unidad_medida text, provisional boolean,
              cantidad_sugerida numeric, agotado_sedes text[], en_gestion boolean, proveedores jsonb,
              ultima_orden_numero text, ultima_orden_fecha timestamp with time zone,
              ultima_orden_cantidad numeric, total bigint)
language plpgsql
stable
security definer
set search_path to ''
as $$
#variable_conflict use_column
declare v_q text; v_terms text[]; v_filtrado boolean;
begin
  perform public._pedidos_check(p_org, 'ver');

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;
  v_filtrado := coalesce(p_linea, '') <> '' or v_q <> '';

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, i.unidad_medida, i.provisional,
         ag.cant, ag.sedes,
         exists (
           select 1 from public.solicitud_items si
           join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
           where sc.organizacion_id = p_org and si.item_id = i.id_item and si.estado = 'activo'),
         coalesce(pv.lista, '[]'::jsonb),
         uo.numero, uo.fecha, uo.cantidad,
         count(*) over()
  from public.items i
  left join lateral (
    select sum(a.cantidad_sugerida) as cant, count(*) as n,
           array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  left join lateral (
    select jsonb_agg(jsonb_build_object(
             'proveedor_id', prv.id, 'proveedor', prv.nombre, 'documento', prv.tipo_documento || ' ' || prv.numero_documento,
             'codigo', ip.refs, 'precio_erp', ip.precio, 'dias', ip.dias,
             'preferido', ip.pref, 'unidades_por_caja', ip.upc,
             'ya_en_solicitud', exists (
               select 1 from public.solicitud_items si
               join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
               where sc.organizacion_id = p_org and sc.proveedor_id = prv.id
                 and sc.estado <> 'cerrada' and si.item_id = i.id_item and si.estado = 'activo'))
           order by ip.pref desc, prv.nombre) as lista,
           lower(coalesce(string_agg(ip.refs, ' '), '')) as refs
    from (
      select x.proveedor_id,
             string_agg(distinct x.codigo_proveedor, ' / ')
               filter (where coalesce(x.codigo_proveedor, '') <> '') as refs,
             max(x.precio_unitario) as precio,
             max(x.tiempo_entrega_dias) as dias,
             bool_or(x.proveedor_preferido) as pref,
             max(x.unidades_por_caja) as upc
      from public.item_proveedor x
      where x.item_id = i.id_item
      group by x.proveedor_id
    ) ip
    join public.proveedores prv on prv.id = ip.proveedor_id
  ) pv on true
  left join lateral (
    select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') as numero, oc.fecha, oi.cantidad
    from public.orden_items oi
    join public.ordenes_compra oc on oc.id = oi.orden_id
    where oi.item_id = i.id_item and oc.organizacion_id = p_org
    order by oc.fecha desc
    limit 1
  ) uo on true
  where i.organizacion_id = p_org
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    -- con preselección (p_items) solo esos ítems; sin ella, lo de siempre (filtro o ítems con agotado)
    and (case when p_items is not null then i.id_item = any(p_items) else (v_filtrado or ag.n > 0) end)
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
        or coalesce(pv.refs, '') like '%' || t.term || '%' escape '\'
      )
    )
  order by (ag.n > 0) desc, i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

drop function if exists public.listar_items_proveedor(uuid, bigint, text, text, boolean);
create or replace function public.listar_items_proveedor(
  p_org uuid, p_proveedor bigint, p_linea text default null::text, p_busqueda text default null::text,
  p_catalogo boolean default false, p_items bigint[] default null)
returns table(item_id bigint, codigo text, nombre_base text, linea text, referencia text,
              unidades_por_caja integer, cantidad_sugerida numeric, ya_en_solicitud boolean, vinculado boolean,
              provisional boolean, precio_erp numeric, dias_entrega integer, agotado_sedes text[],
              ultima_orden_numero text, ultima_orden_fecha timestamp with time zone,
              ultima_orden_cantidad numeric)
language plpgsql
stable
security definer
set search_path to ''
as $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._pedidos_check(p_org, 'ver');
  if not exists (select 1 from public.proveedores where id = p_proveedor and organizacion_id = p_org) then
    raise exception 'Proveedor no válido';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;
  if p_catalogo and v_q = '' then
    raise exception 'Escribe algo para buscar en el catálogo';
  end if;

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, ip.refs, ip.upc, ag.cant,
         exists (
           select 1 from public.solicitud_items si
           join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id
           where sc.organizacion_id = p_org and sc.proveedor_id = p_proveedor
             and sc.estado <> 'cerrada' and si.item_id = i.id_item and si.estado = 'activo'),
         (ip.n > 0), i.provisional, ip.precio, ip.dias, ag.sedes,
         uo.numero, uo.fecha, uo.cantidad
  from public.items i
  left join lateral (
    select string_agg(distinct x.codigo_proveedor, ' / ')
             filter (where coalesce(x.codigo_proveedor, '') <> '') as refs,
           max(x.unidades_por_caja) as upc,
           max(x.precio_unitario) as precio,
           max(x.tiempo_entrega_dias) as dias,
           count(*) as n
    from public.item_proveedor x
    where x.item_id = i.id_item and x.proveedor_id = p_proveedor
  ) ip on true
  left join lateral (
    select sum(a.cantidad_sugerida) as cant, count(*) as n,
           array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  left join lateral (
    select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') as numero, oc.fecha, oi.cantidad
    from public.orden_items oi
    join public.ordenes_compra oc on oc.id = oi.orden_id
    where oi.item_id = i.id_item and oc.organizacion_id = p_org
    order by oc.fecha desc
    limit 1
  ) uo on true
  where i.organizacion_id = p_org
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    -- además de lo vinculado al proveedor: los ítems preseleccionados desde la bandeja de Solicitudes
    and (p_catalogo or ip.n > 0 or (p_items is not null and i.id_item = any(p_items)))
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
        or lower(coalesce(ip.refs, '')) like '%' || t.term || '%' escape '\'
      )
    )
  order by (ag.n > 0) desc, (p_items is not null and i.id_item = any(p_items)) desc, i.nombre_base, i.id_item
  limit case when p_catalogo then 100 else 1000 end;
end $$;

drop function if exists public.matriz_cotizaciones(uuid, text, text, integer, integer);
create or replace function public.matriz_cotizaciones(
  p_org uuid, p_linea text default null::text, p_busqueda text default null::text,
  p_limit integer default 50, p_offset integer default 0,
  p_proveedor bigint default null, p_estado text default null)
returns table(item_id bigint, codigo text, nombre_base text, linea text, unidad_medida text, iva numeric,
              provisional boolean, origen text, cantidad_a_cotizar numeric, agotado_sedes text[],
              cotizaciones jsonb, total bigint)
language plpgsql
stable
security definer
set search_path to ''
as $$
#variable_conflict use_column
declare v_q text; v_terms text[];
begin
  perform public._pedidos_check(p_org, 'ver');
  if coalesce(p_estado, '') not in ('', 'sin_ganador', 'con_ganador', 'faltan') then
    raise exception 'Filtro de estado no válido';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select i.id_item, i.codigo_erp, i.nombre_base, i.linea, i.unidad_medida, i.iva, i.provisional,
         g.origen, g.cant, ag.sedes, g.cots, count(*) over()
  from public.items i
  join lateral (
    select (array_agg(si.origen order by sc.fecha_creacion))[1] as origen,
           max(si.cantidad_a_cotizar) as cant,
           coalesce(bool_or(cp.seleccionado), false) as hay_ganador,
           coalesce(bool_or(cp.fecha_respuesta is null), false) as faltan,
           coalesce(bool_or(cp.proveedor_id = p_proveedor), false) as con_prov,
           jsonb_agg(jsonb_build_object(
             'cotizacion_id', cp.id, 'proveedor_id', cp.proveedor_id, 'proveedor', pv.nombre, 'documento', pv.tipo_documento || ' ' || pv.numero_documento,
             'solicitud_numero', 'SC-' || lpad(coalesce(sc.numero, 0)::text, 4, '0'),
             'solicitud_estado', sc.estado,
             'costo_unitario', cp.costo_unitario, 'costo_con_iva', cp.costo_con_iva,
             'iva', coalesce(cp.iva, case when pv.cobra_iva then pv.iva_compra else 0 end),
             'disponible', cp.disponible, 'dias_entrega', cp.dias_entrega, 'flete', cp.flete,
             'unidades_por_caja', cp.unidades_por_caja, 'observacion', cp.observacion,
             'fecha_respuesta', cp.fecha_respuesta, 'seleccionado', cp.seleccionado,
             'cantidad_pedir', cp.cantidad_pedir,
             'precio_erp', ip.precio, 'referencia', ip.refs)
             order by pv.nombre, sc.fecha_creacion) as cots
    from public.solicitud_items si
    join public.solicitudes_cotizacion sc on sc.id = si.solicitud_id and sc.organizacion_id = p_org
    join public.cotizacion_precios cp on cp.solicitud_item_id = si.id
    join public.proveedores pv on pv.id = cp.proveedor_id
    left join lateral (
      select max(x.precio_unitario) as precio,
             string_agg(distinct x.codigo_proveedor, ' / ')
               filter (where coalesce(x.codigo_proveedor, '') <> '') as refs
      from public.item_proveedor x
      where x.item_id = si.item_id and x.proveedor_id = cp.proveedor_id
    ) ip on true
    where si.item_id = i.id_item and si.estado = 'activo'
  ) g on true
  left join lateral (
    select array_agg(distinct s.nombre order by s.nombre) as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = i.id_item
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  where i.organizacion_id = p_org
    and g.cots is not null
    and (coalesce(p_linea, '') = '' or i.linea = p_linea)
    and (p_proveedor is null or g.con_prov)
    and case coalesce(p_estado, '')
          when 'sin_ganador' then not g.hay_ganador
          when 'con_ganador' then g.hay_ganador
          when 'faltan' then g.faltan
          else true end
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or lower(coalesce(i.codigo_erp, '')) like t.term escape '\'
      )
    )
  order by i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

-- -------------------------------------------------------------------------------------
-- 6. Estructuras de mensajes (por organización)
-- -------------------------------------------------------------------------------------
create table if not exists public.mensaje_plantillas (
  id              uuid primary key default gen_random_uuid(),
  organizacion_id uuid not null references public.organizaciones(id) on delete cascade,
  tipo            text not null check (tipo in ('solicitud_cotizacion', 'orden_compra')),
  encabezado      text not null default '',
  introduccion    text not null default '',
  pie             text not null default '',
  updated_at      timestamptz not null default now(),
  updated_by      uuid references public.profiles(id) on delete set null,
  unique (organizacion_id, tipo)
);

create table if not exists public.mensaje_campos (
  id           uuid primary key default gen_random_uuid(),
  plantilla_id uuid not null references public.mensaje_plantillas(id) on delete cascade,
  clave        text not null,
  etiqueta     text not null default '',
  orden        integer not null,
  visible      boolean not null,
  destino      text not null check (destino in ('proveedor', 'interno')),
  unique (plantilla_id, clave)
);

alter table public.mensaje_plantillas enable row level security;
alter table public.mensaje_campos enable row level security;
-- Sin políticas: no hay acceso directo desde el cliente; todo pasa por las RPC de abajo.
revoke all on table public.mensaje_plantillas from anon, authenticated;
revoke all on table public.mensaje_campos from anon, authenticated;
grant all on table public.mensaje_plantillas to service_role;
grant all on table public.mensaje_campos to service_role;

-- Catálogo de campos disponibles por tipo de mensaje (la "estructura" real).
--   ambito: encabezado | linea | pie
--   destino por defecto: 'proveedor' (lo ve el proveedor) o 'interno' (solo la copia interna)
--   permite_proveedor: false = dato que NUNCA puede enviarse al proveedor
create or replace function public._mensaje_catalogo()
returns table(tipo text, ambito text, clave text, etiqueta text, orden integer,
              visible boolean, destino text, permite_proveedor boolean)
language sql
immutable
set search_path to ''
as $$
  select * from (values
    -- Solicitud de cotización
    ('solicitud_cotizacion','encabezado','numero',          'N°',                 1, false, 'proveedor', true),
    ('solicitud_cotizacion','encabezado','proveedor',       'Proveedor',          2, true,  'proveedor', true),
    ('solicitud_cotizacion','encabezado','fecha',           'Fecha',              3, true,  'proveedor', true),
    ('solicitud_cotizacion','encabezado','creado_por',      'Creada por',         4, true,  'interno',   false),
    ('solicitud_cotizacion','linea',     'nombre_proveedor','Producto',           1, true,  'proveedor', true),
    ('solicitud_cotizacion','linea',     'referencia',      'Ref',                2, true,  'proveedor', true),
    ('solicitud_cotizacion','linea',     'cantidad',        'Cant',               3, true,  'proveedor', true),
    ('solicitud_cotizacion','linea',     'unidad',          'Unidad',             4, true,  'proveedor', true),
    ('solicitud_cotizacion','linea',     'unidades_caja',   'Und/caja',           5, false, 'proveedor', true),
    ('solicitud_cotizacion','linea',     'codigo_erp',      'Código interno',     6, true,  'interno',   true),
    ('solicitud_cotizacion','linea',     'nombre_interno',  'Nombre interno',     7, true,  'interno',   true),
    ('solicitud_cotizacion','linea',     'linea',           'Línea',              8, true,  'interno',   false),
    ('solicitud_cotizacion','linea',     'sedes',           'Agotado en',         9, true,  'interno',   false),
    ('solicitud_cotizacion','linea',     'ultima_orden',    'Última orden',      10, true,  'interno',   false),
    -- Orden de compra
    ('orden_compra','encabezado','numero',          'N°',                 1, false, 'proveedor', true),
    ('orden_compra','encabezado','proveedor',       'Proveedor',          2, true,  'proveedor', true),
    ('orden_compra','encabezado','fecha',           'Fecha',              3, true,  'proveedor', true),
    ('orden_compra','encabezado','entregar_en',     'Entregar en',        4, true,  'proveedor', true),
    ('orden_compra','encabezado','creado_por',      'Creada por',         5, true,  'interno',   false),
    ('orden_compra','linea',     'nombre_proveedor','Producto',           1, true,  'proveedor', true),
    ('orden_compra','linea',     'referencia',      'Ref',                2, true,  'proveedor', true),
    ('orden_compra','linea',     'cantidad',        'Cant',               3, true,  'proveedor', true),
    ('orden_compra','linea',     'unidad',          'Unidad',             4, true,  'proveedor', true),
    ('orden_compra','linea',     'cajas',           'Cajas',              5, true,  'proveedor', true),
    ('orden_compra','linea',     'costo_unitario',  'Costo unit. (antes de IVA)', 6, true, 'proveedor', true),
    ('orden_compra','linea',     'iva',             'IVA',                7, false, 'proveedor', true),
    ('orden_compra','linea',     'costo_con_iva',   'Costo con IVA',      8, false, 'proveedor', true),
    ('orden_compra','linea',     'subtotal',        'Subtotal con IVA',   9, false, 'proveedor', true),
    ('orden_compra','linea',     'flete',           'Flete',             10, false, 'proveedor', true),
    ('orden_compra','linea',     'codigo_erp',      'Código interno',    11, true,  'interno',   true),
    ('orden_compra','linea',     'nombre_interno',  'Nombre interno',    12, true,  'interno',   true),
    ('orden_compra','linea',     'linea',           'Línea',             13, true,  'interno',   false),
    ('orden_compra','pie',       'total',           'Total con IVA',      1, true,  'proveedor', true),
    ('orden_compra','pie',       'flete_total',     'Flete total',        2, false, 'proveedor', true)
  ) as x(tipo, ambito, clave, etiqueta, orden, visible, destino, permite_proveedor)
$$;

-- Valida un borrador y lo completa con los valores por defecto del catálogo.
-- Devuelve la configuración normalizada (la misma forma que usa el render y la pantalla).
create or replace function public._mensaje_normalizar(p_tipo text, p_datos jsonb)
returns jsonb
language plpgsql
stable
set search_path to ''
as $$
declare
  v_def record; v_c jsonb; v_campos jsonb := '[]'::jsonb;
  v_enc text; v_intro text; v_pie text;
  v_et text; v_ord integer; v_vis boolean; v_dest text;
  v_datos jsonb := coalesce(p_datos, '{}'::jsonb);
begin
  if p_tipo not in ('solicitud_cotizacion', 'orden_compra') then
    raise exception 'Tipo de mensaje no válido';
  end if;
  if jsonb_typeof(v_datos) <> 'object' then raise exception 'Formato de configuración no válido'; end if;
  if v_datos ? 'campos' and jsonb_typeof(v_datos->'campos') <> 'array' then
    raise exception 'Formato de campos no válido';
  end if;

  v_enc := case when v_datos ? 'encabezado' then btrim(coalesce(v_datos->>'encabezado', ''))
                else case p_tipo when 'solicitud_cotizacion' then 'SOLICITUD DE COTIZACIÓN {numero}'
                                 else 'ORDEN DE COMPRA {numero}' end end;
  v_intro := case when v_datos ? 'introduccion' then btrim(coalesce(v_datos->>'introduccion', ''))
                  else case p_tipo when 'solicitud_cotizacion'
                         then 'Agradecemos cotizar (costo unitario antes de IVA, disponibilidad, tiempo de entrega y flete):'
                         else '' end end;
  v_pie := case when v_datos ? 'pie' then btrim(coalesce(v_datos->>'pie', '')) else '' end;
  if char_length(v_enc) > 600 or char_length(v_intro) > 600 or char_length(v_pie) > 600 then
    raise exception 'Cada texto libre admite hasta 600 caracteres';
  end if;

  for v_def in
    select * from public._mensaje_catalogo() c where c.tipo = p_tipo order by c.ambito, c.orden
  loop
    v_c := null;
    select e into v_c
    from jsonb_array_elements(coalesce(v_datos->'campos', '[]'::jsonb)) e
    where e->>'clave' = v_def.clave
    limit 1;

    v_et   := v_def.etiqueta;
    v_ord  := v_def.orden;
    v_vis  := v_def.visible;
    v_dest := v_def.destino;

    if v_c is not null then
      if v_c ? 'etiqueta' then v_et := btrim(coalesce(v_c->>'etiqueta', '')); end if;
      if v_c ? 'orden' and (v_c->>'orden') is not null then v_ord := (v_c->>'orden')::integer; end if;
      if v_c ? 'visible' and (v_c->>'visible') is not null then v_vis := (v_c->>'visible')::boolean; end if;
      if v_c ? 'destino' and (v_c->>'destino') is not null then v_dest := v_c->>'destino'; end if;
    end if;

    if char_length(v_et) > 60 then raise exception 'La etiqueta de "%" no puede superar 60 caracteres', v_def.clave; end if;
    if v_dest not in ('proveedor', 'interno') then raise exception 'Destino no válido para "%"', v_def.clave; end if;
    if v_dest = 'proveedor' and not v_def.permite_proveedor then
      raise exception 'El campo "%" es de uso interno y no puede enviarse al proveedor', v_def.etiqueta;
    end if;

    v_campos := v_campos || jsonb_build_array(jsonb_build_object(
      'clave', v_def.clave, 'ambito', v_def.ambito, 'etiqueta', v_et, 'etiqueta_defecto', v_def.etiqueta,
      'orden', v_ord, 'visible', v_vis, 'destino', v_dest, 'permite_proveedor', v_def.permite_proveedor));
  end loop;

  return jsonb_build_object(
    'encabezado', v_enc, 'introduccion', v_intro, 'pie', v_pie,
    'campos', (select coalesce(jsonb_agg(x order by x->>'ambito', (x->>'orden')::integer, x->>'clave'), '[]'::jsonb)
                 from jsonb_array_elements(v_campos) x));
end $$;

-- Configuración vigente de una organización (la guardada, o la de fábrica si nunca se personalizó).
create or replace function public._mensaje_config(p_org uuid, p_tipo text)
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $$
declare v_p public.mensaje_plantillas%rowtype; v_datos jsonb;
begin
  select * into v_p from public.mensaje_plantillas where organizacion_id = p_org and tipo = p_tipo;
  if not found then return public._mensaje_normalizar(p_tipo, '{}'::jsonb); end if;
  v_datos := jsonb_build_object(
    'encabezado', v_p.encabezado, 'introduccion', v_p.introduccion, 'pie', v_p.pie,
    'campos', (select coalesce(jsonb_agg(jsonb_build_object(
                 'clave', c.clave, 'etiqueta', c.etiqueta, 'orden', c.orden,
                 'visible', c.visible, 'destino', c.destino)), '[]'::jsonb)
               from public.mensaje_campos c where c.plantilla_id = v_p.id));
  return public._mensaje_normalizar(p_tipo, v_datos);
end $$;

create or replace function public._mensaje_sustituir(p_txt text, p_enc jsonb)
returns text
language sql
immutable
set search_path to ''
as $$
  select btrim(replace(replace(replace(replace(coalesce(p_txt, ''),
    '{numero}',      coalesce(p_enc->>'numero', '')),
    '{proveedor}',   coalesce(p_enc->>'proveedor', '')),
    '{fecha}',       coalesce(p_enc->>'fecha', '')),
    '{entregar_en}', coalesce(p_enc->>'entregar_en', '')))
$$;

-- Arma el texto del mensaje. p_interno = false: SOLO campos visibles con destino 'proveedor'.
-- p_interno = true: todos los campos visibles (copia interna para Compras).
-- Un campo cuyo valor está vacío no se imprime. Etiqueta vacía = se imprime solo el valor.
create or replace function public._mensaje_render(p_cfg jsonb, p_enc jsonb, p_lineas jsonb, p_interno boolean)
returns text
language plpgsql
stable
set search_path to ''
as $$
declare
  v_out text[] := array[]::text[];
  v_txt text; c jsonb; l jsonb; v_val text; v_partes text[]; v_n integer := 0;
  v_hay boolean;
begin
  v_txt := public._mensaje_sustituir(p_cfg->>'encabezado', p_enc);
  if v_txt <> '' then v_out := v_out || v_txt; end if;

  for c in
    select x from jsonb_array_elements(p_cfg->'campos') x
    where x->>'ambito' = 'encabezado' and (x->>'visible')::boolean
      and (p_interno or x->>'destino' = 'proveedor')
    order by (x->>'orden')::integer
  loop
    v_val := p_enc->>(c->>'clave');
    if coalesce(v_val, '') <> '' then
      v_out := v_out || case when coalesce(c->>'etiqueta', '') = '' then v_val
                             else (c->>'etiqueta') || ': ' || v_val end;
    end if;
  end loop;

  v_txt := public._mensaje_sustituir(p_cfg->>'introduccion', p_enc);
  if v_txt <> '' then v_out := v_out || ''::text || v_txt; end if;

  v_hay := false;
  for l in select x from jsonb_array_elements(coalesce(p_lineas, '[]'::jsonb)) with ordinality as t(x, n) order by n
  loop
    v_partes := array[]::text[];
    for c in
      select x from jsonb_array_elements(p_cfg->'campos') x
      where x->>'ambito' = 'linea' and (x->>'visible')::boolean
        and (p_interno or x->>'destino' = 'proveedor')
      order by (x->>'orden')::integer
    loop
      v_val := l->>(c->>'clave');
      if coalesce(v_val, '') <> '' then
        v_partes := v_partes || case when coalesce(c->>'etiqueta', '') = '' then v_val
                                     else (c->>'etiqueta') || ': ' || v_val end;
      end if;
    end loop;
    if cardinality(v_partes) > 0 then
      if not v_hay then v_out := v_out || ''::text; v_hay := true; end if;
      v_n := v_n + 1;
      v_out := v_out || (v_n::text || '. ' || array_to_string(v_partes, ' | '));
    end if;
  end loop;

  v_hay := false;
  for c in
    select x from jsonb_array_elements(p_cfg->'campos') x
    where x->>'ambito' = 'pie' and (x->>'visible')::boolean
      and (p_interno or x->>'destino' = 'proveedor')
    order by (x->>'orden')::integer
  loop
    v_val := p_enc->>(c->>'clave');
    if coalesce(v_val, '') <> '' then
      if not v_hay then v_out := v_out || ''::text; v_hay := true; end if;
      v_out := v_out || case when coalesce(c->>'etiqueta', '') = '' then v_val
                             else (c->>'etiqueta') || ': ' || v_val end;
    end if;
  end loop;

  v_txt := public._mensaje_sustituir(p_cfg->>'pie', p_enc);
  if v_txt <> '' then v_out := v_out || ''::text || v_txt; end if;

  return array_to_string(v_out, E'\n');
end $$;

revoke all on function public._mensaje_catalogo() from public, anon, authenticated;
revoke all on function public._mensaje_normalizar(text, jsonb) from public, anon, authenticated;
revoke all on function public._mensaje_config(uuid, text) from public, anon, authenticated;
revoke all on function public._mensaje_sustituir(text, jsonb) from public, anon, authenticated;
revoke all on function public._mensaje_render(jsonb, jsonb, jsonb, boolean) from public, anon, authenticated;
grant all on function public._mensaje_catalogo() to service_role;
grant all on function public._mensaje_normalizar(text, jsonb) to service_role;
grant all on function public._mensaje_config(uuid, text) to service_role;
grant all on function public._mensaje_sustituir(text, jsonb) to service_role;
grant all on function public._mensaje_render(jsonb, jsonb, jsonb, boolean) to service_role;

-- --- RPC del módulo Mensajes ---------------------------------------------------------

create or replace function public.mensaje_config_obtener(p_org uuid, p_tipo text)
returns jsonb
language plpgsql
stable
security definer
set search_path to ''
as $$
begin
  perform public._exigir_permiso(p_org, 'mensajes', 'ver');
  if p_tipo not in ('solicitud_cotizacion', 'orden_compra') then raise exception 'Tipo de mensaje no válido'; end if;
  return public._mensaje_config(p_org, p_tipo)
      || jsonb_build_object('personalizada',
           exists (select 1 from public.mensaje_plantillas where organizacion_id = p_org and tipo = p_tipo));
end $$;

create or replace function public.mensaje_config_guardar(p_org uuid, p_tipo text, p_datos jsonb)
returns void
language plpgsql
security definer
set search_path to ''
as $$
declare v_cfg jsonb; v_id uuid;
begin
  perform public._exigir_permiso(p_org, 'mensajes', 'editar');
  v_cfg := public._mensaje_normalizar(p_tipo, p_datos);

  insert into public.mensaje_plantillas (organizacion_id, tipo, encabezado, introduccion, pie, updated_at, updated_by)
  values (p_org, p_tipo, v_cfg->>'encabezado', v_cfg->>'introduccion', v_cfg->>'pie', now(), auth.uid())
  on conflict (organizacion_id, tipo) do update
    set encabezado = excluded.encabezado, introduccion = excluded.introduccion, pie = excluded.pie,
        updated_at = now(), updated_by = auth.uid()
  returning id into v_id;

  delete from public.mensaje_campos where plantilla_id = v_id;
  insert into public.mensaje_campos (plantilla_id, clave, etiqueta, orden, visible, destino)
  select v_id, x->>'clave', x->>'etiqueta', (x->>'orden')::integer, (x->>'visible')::boolean, x->>'destino'
  from jsonb_array_elements(v_cfg->'campos') x;

  perform public._auditar(p_org, 'mensaje_modificado',
    'modificó la estructura del mensaje "' ||
    case p_tipo when 'solicitud_cotizacion' then 'Solicitud de cotización' else 'Orden de compra' end || '"');
end $$;

create or replace function public.mensaje_config_restablecer(p_org uuid, p_tipo text)
returns void
language plpgsql
security definer
set search_path to ''
as $$
begin
  perform public._exigir_permiso(p_org, 'mensajes', 'editar');
  if p_tipo not in ('solicitud_cotizacion', 'orden_compra') then raise exception 'Tipo de mensaje no válido'; end if;
  delete from public.mensaje_plantillas where organizacion_id = p_org and tipo = p_tipo;
  perform public._auditar(p_org, 'mensaje_restablecido',
    'restableció la estructura del mensaje "' ||
    case p_tipo when 'solicitud_cotizacion' then 'Solicitud de cotización' else 'Orden de compra' end || '"');
end $$;

-- Vista previa con datos de ejemplo. p_datos = borrador sin guardar (null = la configuración vigente).
create or replace function public.mensaje_vista_previa(
  p_org uuid, p_tipo text, p_datos jsonb default null::jsonb, p_interno boolean default false)
returns text
language plpgsql
stable
security definer
set search_path to ''
as $$
declare v_cfg jsonb; v_enc jsonb; v_lineas jsonb; v_hoy text;
begin
  perform public._exigir_permiso(p_org, 'mensajes', 'ver');
  if p_tipo not in ('solicitud_cotizacion', 'orden_compra') then raise exception 'Tipo de mensaje no válido'; end if;
  v_cfg := case when p_datos is null then public._mensaje_config(p_org, p_tipo)
                else public._mensaje_normalizar(p_tipo, p_datos) end;
  v_hoy := to_char(now() at time zone 'America/Bogota', 'DD/MM/YYYY');

  if p_tipo = 'solicitud_cotizacion' then
    v_enc := jsonb_build_object('numero', 'SC-0001', 'proveedor', 'Proveedor Ejemplo S.A.S.',
                                'fecha', v_hoy, 'creado_por', 'Nombre del comprador');
    v_lineas := jsonb_build_array(
      jsonb_build_object('nombre_proveedor', 'Tubo latón 1/2" x 6 m', 'referencia', 'TL-12', 'cantidad', '40',
        'unidad', 'und', 'unidades_caja', '10', 'codigo_erp', 'A-1001', 'nombre_interno', 'TUBO LATON 1/2 6M',
        'linea', 'Latón', 'sedes', 'Principal, Norte', 'ultima_orden', 'OC-0012 · 12/09/26 · 100 und'),
      jsonb_build_object('nombre_proveedor', 'Codo latón 3/4"', 'referencia', 'CL-34', 'cantidad', '200',
        'unidad', 'und', 'unidades_caja', '50', 'codigo_erp', 'A-1002', 'nombre_interno', 'CODO LATON 3/4',
        'linea', 'Latón', 'sedes', 'Principal'));
  else
    v_enc := jsonb_build_object('numero', 'OC-0001', 'proveedor', 'Proveedor Ejemplo S.A.S. (NIT 900123456)',
                                'fecha', v_hoy, 'entregar_en', 'Principal - Cali', 'creado_por', 'Nombre del comprador',
                                'total', public._fmt_moneda(1547000), 'flete_total', public._fmt_moneda(25000));
    v_lineas := jsonb_build_array(
      jsonb_build_object('nombre_proveedor', 'Tubo latón 1/2" x 6 m', 'referencia', 'TL-12', 'cantidad', '40',
        'unidad', 'und', 'cajas', '4 caja(s) de 10', 'costo_unitario', public._fmt_moneda(18500), 'iva', '19%',
        'costo_con_iva', public._fmt_moneda(22015), 'subtotal', public._fmt_moneda(880600),
        'flete', public._fmt_moneda(25000), 'codigo_erp', 'A-1001', 'nombre_interno', 'TUBO LATON 1/2 6M', 'linea', 'Latón'),
      jsonb_build_object('nombre_proveedor', 'Codo latón 3/4"', 'referencia', 'CL-34', 'cantidad', '200',
        'unidad', 'und', 'cajas', '4 caja(s) de 50', 'costo_unitario', public._fmt_moneda(2800), 'iva', '19%',
        'costo_con_iva', public._fmt_moneda(3332), 'subtotal', public._fmt_moneda(666400),
        'codigo_erp', 'A-1002', 'nombre_interno', 'CODO LATON 3/4', 'linea', 'Latón'));
  end if;

  return public._mensaje_render(v_cfg, v_enc, v_lineas, coalesce(p_interno, false));
end $$;

-- --- Textos reales de Pedidos: salen de la estructura configurada --------------------

drop function if exists public.solicitud_texto(uuid, uuid);
create or replace function public.solicitud_texto(p_org uuid, p_solicitud uuid, p_interno boolean default false)
returns text
language plpgsql
stable
security definer
set search_path to ''
as $$
declare
  v_num integer; v_prov text; v_prov_id bigint; v_fecha timestamptz; v_creador uuid;
  v_enc jsonb; v_lineas jsonb;
begin
  perform public._pedidos_check(p_org, 'ver');
  select sc.numero, pv.nombre, sc.proveedor_id, sc.fecha_creacion, sc.creado_por
    into v_num, v_prov, v_prov_id, v_fecha, v_creador
  from public.solicitudes_cotizacion sc
  left join public.proveedores pv on pv.id = sc.proveedor_id
  where sc.id = p_solicitud and sc.organizacion_id = p_org;
  if not found then raise exception 'Solicitud no encontrada'; end if;

  v_enc := jsonb_build_object(
    'numero', 'SC-' || lpad(coalesce(v_num, 0)::text, 4, '0'),
    'proveedor', coalesce(v_prov, ''),
    'fecha', to_char(v_fecha at time zone 'America/Bogota', 'DD/MM/YYYY'),
    'creado_por', case when v_creador is null then null else public._nombre_usuario(v_creador) end);

  select coalesce(jsonb_agg(jsonb_build_object(
           'nombre_proveedor', coalesce(r.nombre, i.nombre_base),
           'referencia', r.refs,
           'cantidad', trim_scale(si.cantidad_a_cotizar)::text,
           'unidad', i.unidad_medida,
           'unidades_caja', r.upc::text,
           'codigo_erp', coalesce(i.codigo_erp, 'P' || abs(i.id_item)::text),
           'nombre_interno', i.nombre_base,
           'linea', i.linea,
           'sedes', ag.sedes,
           'ultima_orden', uo.txt)
         order by i.nombre_base, i.id_item), '[]'::jsonb)
    into v_lineas
  from public.solicitud_items si
  join public.items i on i.id_item = si.item_id
  left join lateral (
    select string_agg(distinct ip.codigo_proveedor, ' / ')
             filter (where coalesce(ip.codigo_proveedor, '') <> '') as refs,
           string_agg(distinct ip.nombre_producto_proveedor, ' / ')
             filter (where coalesce(ip.nombre_producto_proveedor, '') <> '') as nombre,
           max(ip.unidades_por_caja) as upc
    from public.item_proveedor ip
    where ip.item_id = si.item_id and ip.proveedor_id = v_prov_id
  ) r on true
  left join lateral (
    select string_agg(distinct s.nombre, ', ') as sedes
    from public.agotados a
    join public.sedes s on s.id = a.sede_id
    where a.organizacion_id = p_org and a.item_id = si.item_id
      and a.estado_comercial is not null and a.respuesta_compras is null
  ) ag on true
  left join lateral (
    select 'OC-' || lpad(coalesce(oc.numero, 0)::text, 4, '0') || ' · '
           || to_char(oc.fecha at time zone 'America/Bogota', 'DD/MM/YY') || ' · '
           || trim_scale(oi.cantidad)::text || ' und' as txt
    from public.orden_items oi
    join public.ordenes_compra oc on oc.id = oi.orden_id
    where oi.item_id = si.item_id and oc.organizacion_id = p_org
    order by oc.fecha desc
    limit 1
  ) uo on true
  where si.solicitud_id = p_solicitud and si.estado = 'activo';

  return public._mensaje_render(public._mensaje_config(p_org, 'solicitud_cotizacion'),
                                v_enc, v_lineas, coalesce(p_interno, false));
end $$;

drop function if exists public.orden_compra_texto(uuid, uuid);
create or replace function public.orden_compra_texto(p_org uuid, p_orden uuid, p_interno boolean default false)
returns text
language plpgsql
stable
security definer
set search_path to ''
as $$
declare
  v_num integer; v_prov text; v_prov_id bigint; v_doc text; v_sede text; v_ciudad text;
  v_total numeric; v_fecha timestamptz; v_creador uuid; v_flete numeric;
  v_enc jsonb; v_lineas jsonb;
begin
  perform public._pedidos_check(p_org, 'ver');
  select oc.numero, pv.nombre, pv.id, pv.tipo_documento || ' ' || pv.numero_documento,
         s.nombre, s.ciudad, oc.total, oc.fecha, oc.creado_por
    into v_num, v_prov, v_prov_id, v_doc, v_sede, v_ciudad, v_total, v_fecha, v_creador
  from public.ordenes_compra oc
  join public.proveedores pv on pv.id = oc.proveedor_id
  left join public.sedes s on s.id = oc.sede_id
  where oc.id = p_orden and oc.organizacion_id = p_org;
  if not found then raise exception 'Orden no encontrada'; end if;

  select coalesce(sum(cp.flete), 0) into v_flete
  from public.orden_items oi
  join public.cotizacion_precios cp on cp.id = oi.cotizacion_precio_id
  where oi.orden_id = p_orden;

  v_enc := jsonb_build_object(
    'numero', 'OC-' || lpad(coalesce(v_num, 0)::text, 4, '0'),
    'proveedor', v_prov || ' (' || v_doc || ')',
    'fecha', to_char(v_fecha at time zone 'America/Bogota', 'DD/MM/YYYY'),
    'entregar_en', case when v_sede is null and v_ciudad is null then null
                        else coalesce(v_sede, '-') || coalesce(' - ' || v_ciudad, '') end,
    'creado_por', case when v_creador is null then null else public._nombre_usuario(v_creador) end,
    'total', public._fmt_moneda(v_total),
    'flete_total', case when v_flete > 0 then public._fmt_moneda(v_flete) end);

  select coalesce(jsonb_agg(jsonb_build_object(
           'nombre_proveedor', coalesce(r.nombre, i.nombre_base),
           'referencia', r.refs,
           'cantidad', trim_scale(oi.cantidad)::text,
           'unidad', coalesce(i.unidad_medida, 'und'),
           'cajas', case when cp.unidades_por_caja is not null
                         then ceil(oi.cantidad / cp.unidades_por_caja)::int::text
                              || ' caja(s) de ' || cp.unidades_por_caja::text end,
           'costo_unitario', public._fmt_moneda(oi.precio_unitario_acordado),
           'iva', case when cp.iva is not null then round(cp.iva * 100)::text || '%' end,
           'costo_con_iva', case when cp.costo_con_iva is not null then public._fmt_moneda(cp.costo_con_iva) end,
           'subtotal', case when cp.costo_con_iva is not null
                            then public._fmt_moneda(oi.cantidad * cp.costo_con_iva) end,
           'flete', case when coalesce(cp.flete, 0) > 0 then public._fmt_moneda(cp.flete) end,
           'codigo_erp', coalesce(i.codigo_erp, 'P' || abs(i.id_item)::text),
           'nombre_interno', i.nombre_base,
           'linea', i.linea)
         order by i.nombre_base, i.id_item), '[]'::jsonb)
    into v_lineas
  from public.orden_items oi
  join public.items i on i.id_item = oi.item_id
  left join public.cotizacion_precios cp on cp.id = oi.cotizacion_precio_id
  left join lateral (
    select string_agg(distinct ip.codigo_proveedor, ' / ')
             filter (where coalesce(ip.codigo_proveedor, '') <> '') as refs,
           string_agg(distinct ip.nombre_producto_proveedor, ' / ')
             filter (where coalesce(ip.nombre_producto_proveedor, '') <> '') as nombre
    from public.item_proveedor ip
    where ip.item_id = oi.item_id and ip.proveedor_id = v_prov_id
  ) r on true
  where oi.orden_id = p_orden;

  return public._mensaje_render(public._mensaje_config(p_org, 'orden_compra'),
                                v_enc, v_lineas, coalesce(p_interno, false));
end $$;

-- -------------------------------------------------------------------------------------
-- 7. Permisos de ejecución de las funciones nuevas / recreadas
-- -------------------------------------------------------------------------------------
do $$
declare f text;
begin
  foreach f in array array[
    'public.cotizacion_elegir(uuid, uuid, numeric, boolean)',
    'public.cotizacion_elegir_masivo(uuid, jsonb, boolean)',
    'public.orden_compra_generar(uuid, bigint)',
    'public.ordenes_compra_generar_todas(uuid, bigint[])',
    'public.agotados_responder_masivo(uuid, bigint[], text, text)',
    'public.solicitudes_crear_multi(uuid, jsonb)',
    'public.solicitud_crear(uuid, bigint, jsonb)',
    'public.cotizacion_agregar_proveedor(uuid, bigint, bigint, text, text, text, text, integer, numeric)',
    'public.listar_items_catalogo(uuid, text, text, integer, integer, bigint[])',
    'public.listar_items_proveedor(uuid, bigint, text, text, boolean, bigint[])',
    'public.matriz_cotizaciones(uuid, text, text, integer, integer, bigint, text)',
    'public.mensaje_config_obtener(uuid, text)',
    'public.mensaje_config_guardar(uuid, text, jsonb)',
    'public.mensaje_config_restablecer(uuid, text)',
    'public.mensaje_vista_previa(uuid, text, jsonb, boolean)',
    'public.solicitud_texto(uuid, uuid, boolean)',
    'public.orden_compra_texto(uuid, uuid, boolean)'
  ] loop
    execute format('revoke all on function %s from public, anon', f);
    execute format('grant all on function %s to authenticated', f);
    execute format('grant all on function %s to service_role', f);
  end loop;
end $$;

commit;
