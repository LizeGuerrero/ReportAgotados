-- Fase 3 · IMPORTACIÓN — parte 1 de 2: módulo de permisos y tablas de carga (staging)
-- Requiere 01-10. Idempotente. Ejecutar UNA por vez.
--
-- Una carga pasa por: cargando → validada → aplicada (o descartada).
-- Las filas se guardan en importacion_filas ANTES de tocar los datos reales; así se puede previsualizar,
-- descargar los errores y aplicar solo lo válido. Nada de esto es accesible directo desde el navegador:
-- solo por las funciones importacion_* (que exigen permisos).

set lock_timeout = '5s';

insert into public.modulos (nombre, descripcion)
values ('importaciones', 'Carga masiva de datos desde Excel o CSV')
on conflict (nombre) do nothing;

insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
select r.id, mo.id, true, true, true, true
from public.roles r
cross join public.modulos mo
where r.nombre = 'admin' and r.organizacion_id is not null and mo.nombre = 'importaciones'
on conflict (rol_id, modulo_id) do nothing;

create table if not exists public.importaciones (
  id              uuid primary key default gen_random_uuid(),
  organizacion_id uuid not null references public.organizaciones(id),
  tipo            text not null check (tipo in ('proveedores', 'items', 'item_proveedor')),
  archivo         text,
  estado          text not null default 'cargando'
                  check (estado in ('cargando', 'validada', 'aplicada', 'descartada')),
  creado_por      uuid references public.profiles(id),
  creada_en       timestamptz not null default now(),
  validada_en     timestamptz,
  aplicada_en     timestamptz,
  resumen         jsonb not null default '{}'::jsonb
);
create index if not exists importaciones_org_idx on public.importaciones (organizacion_id, creada_en desc);

create table if not exists public.importacion_filas (
  id             bigint generated always as identity primary key,
  importacion_id uuid not null references public.importaciones(id) on delete cascade,
  fila           integer not null,
  datos          jsonb not null,
  estado         text not null default 'pendiente'
                 check (estado in ('pendiente', 'nueva', 'actualizar', 'sin_cambios', 'error', 'aplicada')),
  errores        text[] not null default '{}',
  cambios        jsonb not null default '{}'::jsonb,
  destino_id     bigint
);
create index if not exists importacion_filas_idx on public.importacion_filas (importacion_id, estado, fila);

alter table public.importaciones enable row level security;     -- sin políticas: solo por funciones
alter table public.importacion_filas enable row level security;
revoke all on table public.importaciones from anon, authenticated;
revoke all on table public.importacion_filas from anon, authenticated;
