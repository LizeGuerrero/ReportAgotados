-- Fase 1 · ITEMS — parte 1 de 6: Permisos: tiene_permiso, módulos y helper (no bloquea tablas de datos)
-- Ejecutar en orden (01 → 06), UNA por vez. Si falla por bloqueo, espera unos segundos y repite SOLO esta parte:
-- todas son idempotentes (se pueden re-ejecutar sin daño).

set lock_timeout = '5s';

-- 1. Permisos -----------------------------------------------------------------------
create or replace function public.tiene_permiso(p_organizacion_id uuid, p_modulo text, p_accion text)
returns boolean
language sql stable security definer
set search_path to ''
as $$
  select exists (
    select 1
    from public.membresias m
    join public.permisos_rol pr on pr.rol_id = m.rol_id
    join public.modulos mo on mo.id = pr.modulo_id
    where m.usuario_id = auth.uid()
      and m.organizacion_id = p_organizacion_id
      and m.activo = true
      and m.estado_membresia = 'activa'
      and mo.nombre = p_modulo
      and (
        (p_accion = 'ver' and pr.puede_ver) or
        (p_accion = 'crear' and pr.puede_crear) or
        (p_accion = 'editar' and pr.puede_editar) or
        (p_accion = 'eliminar' and pr.puede_eliminar)
      )
  );
$$;

-- Los módulos Items y Proveedores ya existen en las organizaciones creadas con crear_organizacion;
-- esto solo garantiza que existan y que los administradores los tengan (idempotente).
insert into public.modulos (nombre, descripcion)
values ('Items', 'Maestro de ítems'), ('Proveedores', 'Proveedores y su relación con los ítems')
on conflict (nombre) do nothing;

insert into public.permisos_rol (rol_id, modulo_id, puede_ver, puede_crear, puede_editar, puede_eliminar)
select r.id, mo.id, true, true, true, true
from public.roles r
cross join public.modulos mo
where r.nombre = 'admin' and r.organizacion_id is not null and mo.nombre in ('Items', 'Proveedores')
on conflict (rol_id, modulo_id) do nothing;

create or replace function public._exigir_permiso(p_org uuid, p_modulo text, p_accion text)
returns void
language plpgsql stable security definer
set search_path to ''
as $$
begin
  if auth.uid() is null then raise exception 'No autenticado'; end if;
  if not public.tiene_permiso(p_org, p_modulo, p_accion) then
    raise exception 'Sin permiso para % en %', p_accion, p_modulo;
  end if;
end $$;
