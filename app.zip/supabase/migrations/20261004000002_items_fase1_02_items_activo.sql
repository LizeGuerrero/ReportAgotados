-- Fase 1 · ITEMS — parte 2 de 6: items.activo
-- Ejecutar en orden (01 → 06), UNA por vez. Si falla por bloqueo, espera unos segundos y repite SOLO esta parte:
-- todas son idempotentes (se pueden re-ejecutar sin daño).

set lock_timeout = '5s';

-- 2. items.activo ------------------------------------------------------------------
alter table public.items add column if not exists activo boolean not null default true;

comment on column public.items.iva is 'IVA de VENTA (viene del ERP), fracción 0..1. No es el IVA de compra: ese depende del proveedor.';
comment on column public.items.activo is 'false = inhabilitado (no se borra; conserva su historia).';
