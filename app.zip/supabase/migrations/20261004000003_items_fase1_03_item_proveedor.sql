-- Fase 1 · ITEMS — parte 3 de 6: item_proveedor: nombre del proveedor e índices
-- Ejecutar en orden (01 → 06), UNA por vez. Si falla por bloqueo, espera unos segundos y repite SOLO esta parte:
-- todas son idempotentes (se pueden re-ejecutar sin daño).

set lock_timeout = '5s';

-- 3. item_proveedor -----------------------------------------------------------------
alter table public.item_proveedor add column if not exists nombre_producto_proveedor text;

do $$ begin
  alter table public.item_proveedor
    add constraint item_proveedor_nombre_chk
    check (nombre_producto_proveedor is null or btrim(nombre_producto_proveedor) <> '');
exception when duplicate_object then null; end $$;

comment on column public.item_proveedor.nombre_producto_proveedor is 'Cómo llama el proveedor a este producto (puede diferir del nombre interno).';

-- Antes: un solo registro por (ítem, proveedor) cuando no hay variante.
-- Ahora: un proveedor puede tener varias referencias para el mismo ítem; solo se impide repetir la MISMA.
drop index if exists public.item_proveedor_item_prov_sin_variante_uk;
create unique index if not exists item_proveedor_item_prov_ref_uk
  on public.item_proveedor (item_id, proveedor_id, coalesce(variante_id, ''), coalesce(lower(btrim(codigo_proveedor)), ''));

create index if not exists item_proveedor_prov_codigo_idx
  on public.item_proveedor (proveedor_id, lower(btrim(codigo_proveedor))) where codigo_proveedor is not null;
create index if not exists item_proveedor_prov_nombre_idx
  on public.item_proveedor (proveedor_id, lower(btrim(nombre_producto_proveedor))) where nombre_producto_proveedor is not null;
