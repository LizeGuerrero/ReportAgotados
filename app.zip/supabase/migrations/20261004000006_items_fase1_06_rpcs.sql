-- Fase 1 · ITEMS — parte 6 de 6: RPCs de ítems y de la relación ítem-proveedor
-- Ejecutar en orden (01 → 06), UNA por vez. Si falla por bloqueo, espera unos segundos y repite SOLO esta parte:
-- todas son idempotentes (se pueden re-ejecutar sin daño).

set lock_timeout = '5s';

-- 6. RPCs · ítems -----------------------------------------------------------------------
create or replace function public.items_listar(
  p_org uuid, p_busqueda text default null, p_estado text default 'activos',
  p_limit integer default 50, p_offset integer default 0)
returns table(item_id bigint, nombre_base text, linea text, unidad_medida text, iva numeric,
              activo boolean, provisional boolean, proveedores integer, referencias text, total bigint)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
declare v_q text; v_terms text[]; v_estado text := coalesce(p_estado, 'activos');
begin
  perform public._exigir_permiso(p_org, 'Items', 'ver');
  if v_estado not in ('activos', 'inhabilitados', 'todos') then
    raise exception 'Filtro de estado no válido';
  end if;

  v_q := coalesce(extensions.unaccent(lower(trim(p_busqueda))), '');
  v_q := replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_');
  v_terms := case when v_q = '' then array[]::text[] else regexp_split_to_array(v_q, '\s+') end;

  return query
  select i.id_item, i.nombre_base, i.linea, i.unidad_medida, i.iva, i.activo, i.provisional,
         coalesce(pv.n, 0)::int, pv.refs, count(*) over()
  from public.items i
  left join lateral (
    select count(distinct ip.proveedor_id) as n,
           string_agg(distinct ip.codigo_proveedor, ' / ')
             filter (where coalesce(ip.codigo_proveedor, '') <> '') as refs,
           lower(extensions.unaccent(coalesce(string_agg(ip.nombre_producto_proveedor, ' '), ''))) as nombres
    from public.item_proveedor ip
    where ip.item_id = i.id_item
  ) pv on true
  where i.organizacion_id = p_org
    and case v_estado when 'activos' then i.activo when 'inhabilitados' then not i.activo else true end
    and not exists (
      select 1 from unnest(v_terms) as t(term)
      where not (
        extensions.unaccent(lower(i.nombre_base)) like '%' || t.term || '%' escape '\'
        or i.id_item::text = t.term
        or lower(coalesce(pv.refs, '')) like '%' || t.term || '%' escape '\'
        or coalesce(pv.nombres, '') like '%' || t.term || '%' escape '\'
      )
    )
  order by i.nombre_base, i.id_item
  limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0);
end $$;

create or replace function public.item_obtener(p_org uuid, p_item bigint)
returns jsonb
language plpgsql stable security definer
set search_path to ''
as $$
declare v jsonb;
begin
  perform public._exigir_permiso(p_org, 'Items', 'ver');
  select jsonb_build_object('item', to_jsonb(i) - 'organizacion_id', 'logistica', to_jsonb(l))
    into v
  from public.items i
  left join public.item_logistica l on l.item_id = i.id_item
  where i.id_item = p_item and i.organizacion_id = p_org;
  if v is null then raise exception 'Ítem no encontrado'; end if;
  return v;
end $$;

create or replace function public.item_crear(p_org uuid, p_datos jsonb)
returns bigint
language plpgsql security definer
set search_path to ''
as $$
declare
  v_id bigint; v_nombre text; v_iva numeric; v_dueno uuid;
begin
  perform public._exigir_permiso(p_org, 'Items', 'crear');
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;

  v_id := nullif(btrim(p_datos->>'id_item'), '')::bigint;
  if v_id is null or v_id <= 0 then raise exception 'El código del ítem debe ser un número positivo'; end if;

  v_nombre := nullif(btrim(p_datos->>'nombre_base'), '');
  if v_nombre is null then raise exception 'Escribe el nombre del ítem'; end if;
  if char_length(v_nombre) > 300 then raise exception 'El nombre no puede superar 300 caracteres'; end if;

  v_iva := nullif(btrim(p_datos->>'iva'), '')::numeric;
  if v_iva is not null and (v_iva < 0 or v_iva > 1) then
    raise exception 'IVA no válido: usa una fracción entre 0 y 1 (por ejemplo 0.19)';
  end if;

  select i.organizacion_id into v_dueno from public.items i where i.id_item = v_id;
  if found then
    if v_dueno = p_org then raise exception 'Ya existe un ítem con el código %', v_id; end if;
    -- Limitación actual: el código es único en todo el sistema (se corrige al pasar a claves por organización).
    raise exception 'El código % no está disponible', v_id;
  end if;

  insert into public.items (id_item, organizacion_id, nombre_base, unidad_medida, linea, iva, provisional)
  values (v_id, p_org, v_nombre, nullif(btrim(p_datos->>'unidad_medida'), ''),
          nullif(btrim(p_datos->>'linea'), ''), v_iva, false);
  return v_id;
end $$;

create or replace function public.item_actualizar(p_org uuid, p_item bigint, p_datos jsonb)
returns void
language plpgsql security definer
set search_path to ''
as $$
declare v_iva numeric;
begin
  perform public._exigir_permiso(p_org, 'Items', 'editar');
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;
  if not exists (select 1 from public.items where id_item = p_item and organizacion_id = p_org) then
    raise exception 'Ítem no encontrado';
  end if;

  if p_datos ? 'nombre_base' and nullif(btrim(p_datos->>'nombre_base'), '') is null then
    raise exception 'El nombre del ítem no puede quedar vacío';
  end if;
  if p_datos ? 'nombre_base' and char_length(btrim(p_datos->>'nombre_base')) > 300 then
    raise exception 'El nombre no puede superar 300 caracteres';
  end if;
  if p_datos ? 'iva' then
    v_iva := nullif(btrim(p_datos->>'iva'), '')::numeric;
    if v_iva is not null and (v_iva < 0 or v_iva > 1) then
      raise exception 'IVA no válido: usa una fracción entre 0 y 1 (por ejemplo 0.19)';
    end if;
  end if;

  -- Solo cambia lo que llega en p_datos; lo vacío se guarda como NULL.
  update public.items i set
    nombre_base         = case when p_datos ? 'nombre_base'         then btrim(p_datos->>'nombre_base') else i.nombre_base end,
    descripcion_2       = case when p_datos ? 'descripcion_2'       then nullif(btrim(p_datos->>'descripcion_2'), '') else i.descripcion_2 end,
    unidad_medida       = case when p_datos ? 'unidad_medida'       then nullif(btrim(p_datos->>'unidad_medida'), '') else i.unidad_medida end,
    categoria           = case when p_datos ? 'categoria'           then nullif(btrim(p_datos->>'categoria'), '') else i.categoria end,
    grupo_contable      = case when p_datos ? 'grupo_contable'      then nullif(btrim(p_datos->>'grupo_contable'), '') else i.grupo_contable end,
    grupo               = case when p_datos ? 'grupo'               then nullif(btrim(p_datos->>'grupo'), '') else i.grupo end,
    codigo_linea        = case when p_datos ? 'codigo_linea'        then nullif(btrim(p_datos->>'codigo_linea'), '') else i.codigo_linea end,
    linea               = case when p_datos ? 'linea'               then nullif(btrim(p_datos->>'linea'), '') else i.linea end,
    marca               = case when p_datos ? 'marca'               then nullif(btrim(p_datos->>'marca'), '') else i.marca end,
    notas               = case when p_datos ? 'notas'               then nullif(btrim(p_datos->>'notas'), '') else i.notas end,
    informacion_tecnica = case when p_datos ? 'informacion_tecnica' then nullif(btrim(p_datos->>'informacion_tecnica'), '') else i.informacion_tecnica end,
    aplicacion_tecnica  = case when p_datos ? 'aplicacion_tecnica'  then nullif(btrim(p_datos->>'aplicacion_tecnica'), '') else i.aplicacion_tecnica end,
    iva                 = case when p_datos ? 'iva'                 then v_iva else i.iva end
  where i.id_item = p_item and i.organizacion_id = p_org;
end $$;

create or replace function public.item_estado(p_org uuid, p_item bigint, p_activo boolean)
returns void
language plpgsql security definer
set search_path to ''
as $$
begin
  perform public._exigir_permiso(p_org, 'Items', 'editar');
  if p_activo is null then raise exception 'Estado no válido'; end if;
  update public.items set activo = p_activo where id_item = p_item and organizacion_id = p_org;
  if not found then raise exception 'Ítem no encontrado'; end if;
end $$;

create or replace function public.item_logistica_guardar(p_org uuid, p_item bigint, p_datos jsonb)
returns void
language plpgsql security definer
set search_path to ''
as $$
declare v_peso numeric; v_alto numeric; v_ancho numeric; v_largo numeric;
begin
  perform public._exigir_permiso(p_org, 'Items', 'editar');
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;
  if not exists (select 1 from public.items where id_item = p_item and organizacion_id = p_org) then
    raise exception 'Ítem no encontrado';
  end if;
  v_peso  := nullif(btrim(p_datos->>'peso_kg'), '')::numeric;
  v_alto  := nullif(btrim(p_datos->>'alto_cm'), '')::numeric;
  v_ancho := nullif(btrim(p_datos->>'ancho_cm'), '')::numeric;
  v_largo := nullif(btrim(p_datos->>'largo_cm'), '')::numeric;
  if coalesce(v_peso, 0) < 0 or coalesce(v_alto, 0) < 0 or coalesce(v_ancho, 0) < 0 or coalesce(v_largo, 0) < 0 then
    raise exception 'Las medidas no pueden ser negativas';
  end if;

  insert into public.item_logistica (item_id, peso_kg, alto_cm, ancho_cm, largo_cm, notas)
  values (p_item, v_peso, v_alto, v_ancho, v_largo, nullif(btrim(p_datos->>'notas'), ''))
  on conflict (item_id) do update set
    peso_kg = excluded.peso_kg, alto_cm = excluded.alto_cm, ancho_cm = excluded.ancho_cm,
    largo_cm = excluded.largo_cm, notas = excluded.notas;
end $$;

create or replace function public.item_historial(p_org uuid, p_item bigint, p_limit integer default 100)
returns table(fecha timestamptz, tabla text, accion text, usuario text, antes jsonb, despues jsonb)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
begin
  perform public._exigir_permiso(p_org, 'Items', 'ver');
  return query
  select a.fecha, a.tabla, a.accion,
         nullif(btrim(coalesce(p.nombres, '') || ' ' || coalesce(p.apellidos, '')), ''),
         a.antes, a.despues
  from public.auditoria a
  left join public.profiles p on p.id = a.usuario_id
  where a.organizacion_id = p_org and a.item_id = p_item
  order by a.fecha desc
  limit least(greatest(p_limit, 1), 500);
end $$;

-- 7. RPCs · relación ítem–proveedor ---------------------------------------------------------
create or replace function public.item_proveedores_listar(p_org uuid, p_item bigint)
returns table(id uuid, proveedor_id bigint, proveedor text, variante_id text, codigo_proveedor text,
              nombre_producto_proveedor text, unidades_por_caja integer, precio_unitario numeric,
              tiempo_entrega_dias integer, proveedor_preferido boolean, notas text, repetida_en_otros integer)
language plpgsql stable security definer
set search_path to ''
as $$
#variable_conflict use_column
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'ver');
  if not exists (select 1 from public.items where id_item = p_item and organizacion_id = p_org) then
    raise exception 'Ítem no encontrado';
  end if;
  return query
  select ip.id, ip.proveedor_id, pv.nombre, ip.variante_id, ip.codigo_proveedor,
         ip.nombre_producto_proveedor, ip.unidades_por_caja, ip.precio_unitario,
         ip.tiempo_entrega_dias, ip.proveedor_preferido, ip.notas,
         (select count(distinct x.item_id)::int
            from public.item_proveedor x
            join public.items i2 on i2.id_item = x.item_id and i2.organizacion_id = p_org
           where x.proveedor_id = ip.proveedor_id and x.item_id <> ip.item_id
             and ip.codigo_proveedor is not null
             and lower(btrim(x.codigo_proveedor)) = lower(btrim(ip.codigo_proveedor)))
  from public.item_proveedor ip
  join public.proveedores pv on pv.id = ip.proveedor_id and pv.organizacion_id = p_org
  where ip.item_id = p_item
  order by pv.nombre, ip.codigo_proveedor nulls last;
end $$;

-- Devuelve {guardado:false, advertencias:[...]} si hay algo que confirmar y p_confirmar es false.
create or replace function public.item_proveedor_guardar(
  p_org uuid, p_id uuid, p_item bigint, p_proveedor bigint, p_datos jsonb, p_confirmar boolean default false)
returns jsonb
language plpgsql security definer
set search_path to ''
as $$
declare
  v_codigo text; v_nombre text; v_upc integer; v_precio numeric; v_dias integer;
  v_pref boolean; v_notas text; v_var text;
  v_fila public.item_proveedor%rowtype;
  v_adv text[] := array[]::text[];
  v_txt text; v_id uuid; v_clave_igual boolean := false;
begin
  perform public._exigir_permiso(p_org, 'Proveedores', case when p_id is null then 'crear' else 'editar' end);
  if p_datos is null or jsonb_typeof(p_datos) <> 'object' then raise exception 'Datos no válidos'; end if;
  if not exists (select 1 from public.items where id_item = p_item and organizacion_id = p_org) then
    raise exception 'Ítem no encontrado';
  end if;
  if not exists (select 1 from public.proveedores where id = p_proveedor and organizacion_id = p_org) then
    raise exception 'Proveedor no válido';
  end if;
  if p_id is not null then
    select * into v_fila from public.item_proveedor where id = p_id and item_id = p_item;
    if not found then raise exception 'La relación ya no existe'; end if;
  end if;

  v_codigo := nullif(btrim(p_datos->>'codigo_proveedor'), '');
  v_nombre := nullif(btrim(p_datos->>'nombre_producto_proveedor'), '');
  v_upc    := nullif(btrim(p_datos->>'unidades_por_caja'), '')::integer;
  v_precio := nullif(btrim(p_datos->>'precio_unitario'), '')::numeric;
  v_dias   := nullif(btrim(p_datos->>'tiempo_entrega_dias'), '')::integer;
  v_pref   := coalesce((p_datos->>'proveedor_preferido')::boolean, false);
  v_notas  := nullif(btrim(p_datos->>'notas'), '');
  v_var    := case when p_datos ? 'variante_id' then nullif(btrim(p_datos->>'variante_id'), '') else v_fila.variante_id end;

  if char_length(coalesce(v_codigo, '')) > 100 then raise exception 'La referencia no puede superar 100 caracteres'; end if;
  if char_length(coalesce(v_nombre, '')) > 300 then raise exception 'El nombre no puede superar 300 caracteres'; end if;
  if v_upc is not null and v_upc <= 0 then raise exception 'Unidades por caja no válidas'; end if;
  if v_precio is not null and v_precio < 0 then raise exception 'Costo no válido'; end if;
  if v_dias is not null and v_dias < 0 then raise exception 'Días de entrega no válidos'; end if;
  if v_var is not null and not exists (select 1 from public.variantes where id_variante = v_var and item_id = p_item) then
    raise exception 'La variante no pertenece a este ítem';
  end if;

  -- Si al editar no cambió proveedor/referencia/nombre, no se vuelve a advertir lo mismo.
  if p_id is not null then
    v_clave_igual := v_fila.proveedor_id = p_proveedor
      and lower(btrim(coalesce(v_fila.codigo_proveedor, ''))) = lower(coalesce(v_codigo, ''))
      and lower(btrim(coalesce(v_fila.nombre_producto_proveedor, ''))) = lower(coalesce(v_nombre, ''));
  end if;

  if not v_clave_igual then
    if v_codigo is null and v_nombre is null then
      v_adv := array_append(v_adv, 'Sin referencia ni nombre del proveedor: luego no podrá reconocerse en cotizaciones ni facturas.');
    end if;

    if v_codigo is not null then
      select string_agg(distinct x.item_id::text || ' - ' || i.nombre_base, '; ') into v_txt
      from public.item_proveedor x
      join public.items i on i.id_item = x.item_id and i.organizacion_id = p_org
      where x.proveedor_id = p_proveedor and x.item_id <> p_item
        and lower(btrim(x.codigo_proveedor)) = lower(v_codigo);
      if v_txt is not null then
        v_adv := array_append(v_adv, 'La referencia ' || v_codigo || ' de este proveedor ya está asignada a otro ítem: ' || v_txt);
      end if;
    end if;

    if v_nombre is not null then
      select string_agg(distinct x.item_id::text || ' - ' || i.nombre_base, '; ') into v_txt
      from public.item_proveedor x
      join public.items i on i.id_item = x.item_id and i.organizacion_id = p_org
      where x.proveedor_id = p_proveedor and x.item_id <> p_item
        and lower(btrim(x.nombre_producto_proveedor)) = lower(v_nombre);
      if v_txt is not null then
        v_adv := array_append(v_adv, 'El proveedor ya llama así a otro ítem: ' || v_txt);
      end if;
    end if;

    select string_agg(coalesce(x.codigo_proveedor, '(sin referencia)'), ', ') into v_txt
    from public.item_proveedor x
    where x.item_id = p_item and x.proveedor_id = p_proveedor and (p_id is null or x.id <> p_id);
    if v_txt is not null then
      v_adv := array_append(v_adv, 'Este ítem ya tiene a este proveedor con: ' || v_txt);
    end if;
  end if;

  if cardinality(v_adv) > 0 and not coalesce(p_confirmar, false) then
    return jsonb_build_object('guardado', false, 'advertencias', to_jsonb(v_adv));
  end if;

  begin
    if p_id is null then
      insert into public.item_proveedor
        (item_id, proveedor_id, variante_id, codigo_proveedor, nombre_producto_proveedor,
         unidades_por_caja, precio_unitario, tiempo_entrega_dias, proveedor_preferido, notas)
      values (p_item, p_proveedor, v_var, v_codigo, v_nombre, v_upc, v_precio, v_dias, v_pref, v_notas)
      returning id into v_id;
    else
      update public.item_proveedor set
        proveedor_id = p_proveedor, variante_id = v_var, codigo_proveedor = v_codigo,
        nombre_producto_proveedor = v_nombre, unidades_por_caja = v_upc, precio_unitario = v_precio,
        tiempo_entrega_dias = v_dias, proveedor_preferido = v_pref, notas = v_notas
      where id = p_id;
      v_id := p_id;
    end if;
  exception when unique_violation then
    raise exception 'Ese proveedor ya tiene esa misma referencia en este ítem';
  end;

  return jsonb_build_object('guardado', true, 'id', v_id, 'advertencias', to_jsonb(v_adv));
end $$;

create or replace function public.item_proveedor_eliminar(p_org uuid, p_id uuid)
returns void
language plpgsql security definer
set search_path to ''
as $$
begin
  perform public._exigir_permiso(p_org, 'Proveedores', 'eliminar');
  delete from public.item_proveedor ip
  using public.items i
  where ip.id = p_id and i.id_item = ip.item_id and i.organizacion_id = p_org;
  if not found then raise exception 'La relación ya no existe'; end if;
end $$;

-- 8. Permisos de ejecución (mismo criterio que el resto: nada para anon) ----------------------
revoke all on function public._exigir_permiso(uuid, text, text) from public, anon, authenticated;
grant execute on function public._exigir_permiso(uuid, text, text) to service_role;

do $$
declare f text;
begin
  foreach f in array array[
    'public.items_listar(uuid, text, text, integer, integer)',
    'public.item_obtener(uuid, bigint)',
    'public.item_crear(uuid, jsonb)',
    'public.item_actualizar(uuid, bigint, jsonb)',
    'public.item_estado(uuid, bigint, boolean)',
    'public.item_logistica_guardar(uuid, bigint, jsonb)',
    'public.item_historial(uuid, bigint, integer)',
    'public.item_proveedores_listar(uuid, bigint)',
    'public.item_proveedor_guardar(uuid, uuid, bigint, bigint, jsonb, boolean)',
    'public.item_proveedor_eliminar(uuid, uuid)'
  ] loop
    execute format('revoke all on function %s from public, anon', f);
    execute format('grant execute on function %s to authenticated, service_role', f);
  end loop;
end $$;
