-- Fase 1 · ITEMS — parte 5 de 6: Auditoría y triggers
-- Ejecutar en orden (01 → 06), UNA por vez. Si falla por bloqueo, espera unos segundos y repite SOLO esta parte:
-- todas son idempotentes (se pueden re-ejecutar sin daño).

set lock_timeout = '5s';

-- 5. Auditoría -------------------------------------------------------------------------
create table if not exists public.auditoria (
  id              uuid primary key default gen_random_uuid(),
  organizacion_id uuid not null references public.organizaciones(id),
  tabla           text not null,
  registro        text not null,
  item_id         bigint,
  accion          text not null check (accion in ('insert', 'update', 'delete')),
  antes           jsonb,
  despues         jsonb,
  usuario_id      uuid,
  fecha           timestamptz not null default now()
);
create index if not exists auditoria_item_idx on public.auditoria (organizacion_id, item_id, fecha desc);

alter table public.auditoria enable row level security;   -- sin políticas: solo se lee por RPC
revoke all on table public.auditoria from anon, authenticated;

create or replace function public.auditar_cambio()
returns trigger
language plpgsql security definer
set search_path to ''
as $$
declare
  v_old jsonb; v_new jsonb; v_row jsonb; v_org uuid; v_item bigint;
begin
  v_old := case when tg_op <> 'INSERT' then to_jsonb(old) end;
  v_new := case when tg_op <> 'DELETE' then to_jsonb(new) end;
  if tg_op = 'UPDATE' and (v_old - 'updated_at') = (v_new - 'updated_at') then
    return null;
  end if;
  v_row := coalesce(v_new, v_old);
  v_item := coalesce(v_row->>'item_id', v_row->>'id_item')::bigint;
  v_org := (v_row->>'organizacion_id')::uuid;
  if v_org is null then
    select i.organizacion_id into v_org from public.items i where i.id_item = v_item;
  end if;
  if v_org is null then return null; end if;   -- p. ej. borrado en cascada de un ítem ya eliminado

  insert into public.auditoria (organizacion_id, tabla, registro, item_id, accion, antes, despues, usuario_id)
  values (v_org, tg_table_name, coalesce(v_row->>'id', v_row->>'id_item', v_row->>'item_id'),
          v_item, lower(tg_op), v_old, v_new, auth.uid());
  return null;
end $$;

revoke all on function public.auditar_cambio() from public, anon, authenticated;

drop trigger if exists trg_auditar_items on public.items;
create trigger trg_auditar_items after insert or update or delete on public.items
  for each row execute function public.auditar_cambio();
drop trigger if exists trg_auditar_item_logistica on public.item_logistica;
create trigger trg_auditar_item_logistica after insert or update or delete on public.item_logistica
  for each row execute function public.auditar_cambio();
drop trigger if exists trg_auditar_item_proveedor on public.item_proveedor;
create trigger trg_auditar_item_proveedor after insert or update or delete on public.item_proveedor
  for each row execute function public.auditar_cambio();
