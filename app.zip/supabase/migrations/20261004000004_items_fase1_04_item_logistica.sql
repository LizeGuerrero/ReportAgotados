-- Fase 1 · ITEMS — parte 4 de 6: Tabla item_logistica
-- Ejecutar en orden (01 → 06), UNA por vez. Si falla por bloqueo, espera unos segundos y repite SOLO esta parte:
-- todas son idempotentes (se pueden re-ejecutar sin daño).

set lock_timeout = '5s';

-- 4. Logística (1:1) --------------------------------------------------------------------
create table if not exists public.item_logistica (
  item_id    bigint primary key references public.items(id_item) on delete cascade,
  peso_kg    numeric(12,3),
  alto_cm    numeric(10,2),
  ancho_cm   numeric(10,2),
  largo_cm   numeric(10,2),
  notas      text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint item_logistica_valores_chk check (
    (peso_kg is null or peso_kg >= 0) and (alto_cm is null or alto_cm >= 0)
    and (ancho_cm is null or ancho_cm >= 0) and (largo_cm is null or largo_cm >= 0))
);

alter table public.item_logistica enable row level security;

drop policy if exists item_logistica_select on public.item_logistica;
create policy item_logistica_select on public.item_logistica for select
  using (public.tiene_permiso((select i.organizacion_id from public.items i where i.id_item = item_logistica.item_id), 'Items', 'ver'));
drop policy if exists item_logistica_insert on public.item_logistica;
create policy item_logistica_insert on public.item_logistica for insert
  with check (public.tiene_permiso((select i.organizacion_id from public.items i where i.id_item = item_logistica.item_id), 'Items', 'editar'));
drop policy if exists item_logistica_update on public.item_logistica;
create policy item_logistica_update on public.item_logistica for update
  using (public.tiene_permiso((select i.organizacion_id from public.items i where i.id_item = item_logistica.item_id), 'Items', 'editar'));
drop policy if exists item_logistica_delete on public.item_logistica;
create policy item_logistica_delete on public.item_logistica for delete
  using (public.tiene_permiso((select i.organizacion_id from public.items i where i.id_item = item_logistica.item_id), 'Items', 'eliminar'));

drop trigger if exists trg_item_logistica_updated_at on public.item_logistica;
create trigger trg_item_logistica_updated_at before update on public.item_logistica
  for each row execute function public.set_updated_at();
