import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import EstructurasMensajes from '@/components/mensajes/EstructurasMensajes';

export const metadata = { title: 'Mensajes' };

// El acceso al módulo lo valida proxy.ts (permiso "ver" de mensajes) y cada RPC lo vuelve a exigir en la BD.
export default async function MensajesPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: organizacion } = await supabase
    .from('organizaciones')
    .select('id, nombre')
    .eq('slug', slug)
    .maybeSingle();

  if (!organizacion) notFound();

  const { data: puedeEditar } = await supabase.rpc('tiene_permiso', {
    p_organizacion_id: organizacion.id,
    p_modulo: 'mensajes',
    p_accion: 'editar',
  });

  return (
    <main className="mod-page">
      <div className="mod-head">
        <h1 className="mod-title">Mensajes</h1>
      </div>
      <EstructurasMensajes organizacionId={organizacion.id} puedeEditar={puedeEditar === true} />
    </main>
  );
}
