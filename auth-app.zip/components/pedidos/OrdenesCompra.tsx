'use client';

import { useCallback, useEffect, useState } from 'react';
import type { SupabaseClient } from '@supabase/supabase-js';
import { useTiempoReal } from '@/components/useTiempoReal';
import type { PermisosPedidos } from '@/components/pedidos/usePermisosPedidos';
import PanelMensaje from '@/components/pedidos/PanelMensaje';
import { fecha, pesos, TABLAS_PEDIDOS, textoCajas } from '@/components/pedidos/comun';

interface LineaPorGenerar {
  cotizacion_id: string;
  item_id: number;
  codigo: string | null;
  nombre_base: string;
  linea: string | null;
  referencia: string | null;
  cantidad: number;
  unidades_por_caja: number | null;
  cajas: number | null;
  costo_unitario: number;
  costo_con_iva: number;
  flete: number | null;
}

interface PorGenerar {
  proveedor_id: number;
  proveedor: string;
  documento: string;
  items: number;
  total_con_iva: number;
  lineas: LineaPorGenerar[];
}

interface LineaOrden {
  item_id: number;
  codigo: string | null;
  nombre_base: string;
  linea: string | null;
  cantidad: number;
  unidades_por_caja: number | null;
  costo_unitario: number;
  costo_con_iva: number | null;
}

interface Orden {
  id: string;
  numero_texto: string;
  proveedor_id: number;
  proveedor: string;
  documento: string;
  sede: string | null;
  fecha: string;
  total_oc: number | null;
  creado_por: string | null;
  items: LineaOrden[];
}

interface MensajeOrden {
  id: string;
  titulo: string;
  texto: string;
  interno: string;
}

/**
 * Paso 4 — Órdenes de compra. Lo elegido en el Comparativo llega aquí agrupado por proveedor. Se puede
 * generar una orden o todas de una vez (una por proveedor); cada orden produce su mensaje, armado con la
 * estructura configurada en el módulo Mensajes (lo que ve el proveedor) y una copia interna.
 */
export default function OrdenesCompra({
  supabase,
  organizacionId,
  permisos,
}: {
  supabase: SupabaseClient;
  organizacionId: string;
  permisos: PermisosPedidos;
}) {
  const [porGenerar, setPorGenerar] = useState<PorGenerar[]>([]);
  const [ordenes, setOrdenes] = useState<Orden[]>([]);
  const [error, setError] = useState('');
  const [generando, setGenerando] = useState<number | null>(null);
  const [mensajes, setMensajes] = useState<MensajeOrden[]>([]);
  const [confirmaTodas, setConfirmaTodas] = useState(false);
  const [generandoTodas, setGenerandoTodas] = useState(false);
  const [resumen, setResumen] = useState('');

  const cargar = useCallback(async () => {
    const [a, b] = await Promise.all([
      supabase.rpc('listar_ordenes_por_generar', { p_org: organizacionId }),
      supabase.rpc('listar_ordenes_compra', { p_org: organizacionId, p_limit: 100, p_offset: 0 }),
    ]);
    if (a.error) setError(a.error.message);
    else if (b.error) setError(b.error.message);
    else {
      setError('');
      setPorGenerar((a.data ?? []) as PorGenerar[]);
      setOrdenes((b.data ?? []) as Orden[]);
    }
  }, [supabase, organizacionId]);

  useEffect(() => {
    cargar();
  }, [cargar]);

  // Lo que falta por pedir a cada proveedor cambia cuando alguien elige un ganador o genera una orden:
  // dos compradores a la vez ven lo mismo sin recargar (y la base impide generar dos veces la misma orden).
  useTiempoReal(supabase, organizacionId, TABLAS_PEDIDOS, cargar);

  async function armarMensaje(id: string, titulo: string): Promise<MensajeOrden> {
    const [a, b] = await Promise.all([
      supabase.rpc('orden_compra_texto', { p_org: organizacionId, p_orden: id }),
      supabase.rpc('orden_compra_texto', { p_org: organizacionId, p_orden: id, p_interno: true }),
    ]);
    return {
      id,
      titulo,
      texto: a.error ? `Error al generar el texto: ${a.error.message}` : (a.data as string),
      interno: b.error ? `Error al generar el texto: ${b.error.message}` : (b.data as string),
    };
  }

  async function verTexto(id: string, numero: string, proveedor: string) {
    const m = await armarMensaje(id, `Orden ${numero} — ${proveedor}`);
    setMensajes([m]);
  }

  async function generar(p: PorGenerar) {
    if (!window.confirm(`¿Generar la orden de compra para ${p.proveedor} con ${p.items} ítem(s)?`)) return;
    setGenerando(p.proveedor_id);
    const { data, error } = await supabase.rpc('orden_compra_generar', {
      p_org: organizacionId,
      p_proveedor: p.proveedor_id,
    });
    setGenerando(null);
    if (error) {
      setError(error.message);
      return;
    }
    setError('');
    setResumen('');
    await cargar();
    const id = data as string;
    const o = await supabase.rpc('listar_ordenes_compra', { p_org: organizacionId, p_proveedor: p.proveedor_id, p_limit: 1, p_offset: 0 });
    const numero = ((o.data ?? []) as Orden[])[0]?.numero_texto ?? '';
    await verTexto(id, numero, p.proveedor);
  }

  async function generarTodas() {
    setGenerandoTodas(true);
    setError('');
    setResumen('');
    const { data, error } = await supabase.rpc('ordenes_compra_generar_todas', { p_org: organizacionId });
    setGenerandoTodas(false);
    setConfirmaTodas(false);
    if (error) {
      setError(error.message);
      return;
    }
    const generadas = (data?.generadas ?? []) as { proveedor_id: number; orden_id: string }[];
    const fallidas = (data?.fallidas ?? []) as { proveedor_id: number; error: string }[];
    const nombre = (id: number) => porGenerar.find((x) => x.proveedor_id === id)?.proveedor ?? String(id);
    await cargar();
    const lista: MensajeOrden[] = [];
    for (const g of generadas) {
      lista.push(await armarMensaje(g.orden_id, `Orden — ${nombre(g.proveedor_id)}`));
    }
    setMensajes(lista);
    setResumen(
      `Se generaron ${generadas.length} orden(es).` +
        (fallidas.length > 0
          ? ` No se pudo generar para: ${fallidas.map((f) => `${nombre(f.proveedor_id)} (${f.error})`).join('; ')}.`
          : ''),
    );
  }

  return (
    <div>
      {error && <p className="mod-text">Error: {error}</p>}

      {resumen && <p className="mod-notice mod-text">{resumen}</p>}

      {mensajes.map((m) => (
        <PanelMensaje
          key={m.id}
          titulo={m.titulo}
          texto={m.texto}
          textoInterno={m.interno}
          onCerrar={() => setMensajes((l) => l.filter((x) => x.id !== m.id))}
        />
      ))}

      <h3 className="mod-h3 mod-mt-0 mod-mb-2">Por generar (ganadores elegidos, agrupados por proveedor)</h3>
      {porGenerar.length === 0 && (
        <p className="mod-text">No hay ítems ganadores pendientes. Elige el ganador en el paso 3 (Comparativo).</p>
      )}
      {porGenerar.length > 0 && permisos.ganadorCrear && (
        <div className="mod-bulkbar">
          {!confirmaTodas ? (
            <>
              <button type="button" className="ui-btn ui-btn--sm ui-btn--primary" disabled={generandoTodas}
                onClick={() => setConfirmaTodas(true)}>
                Generar las {porGenerar.length} órdenes de compra
              </button>
              <span className="mod-sub">
                Una orden por proveedor · {porGenerar.reduce((n, p) => n + p.items, 0)} ítem(s) ·{' '}
                {pesos(porGenerar.reduce((n, p) => n + Number(p.total_con_iva ?? 0), 0))} con IVA
              </span>
            </>
          ) : (
            <>
              <span className="mod-text">
                Se generarán {porGenerar.length} orden(es) ({porGenerar.map((p) => p.proveedor).join(', ')}). Los ítems quedan
                como “Pedido solicitado” y sus cotizaciones se cierran.
              </span>
              <button type="button" className="ui-btn ui-btn--sm ui-btn--primary" disabled={generandoTodas} onClick={generarTodas}>
                {generandoTodas ? 'Generando…' : 'Confirmar'}
              </button>
              <button type="button" className="ui-btn ui-btn--sm" disabled={generandoTodas} onClick={() => setConfirmaTodas(false)}>
                Cancelar
              </button>
            </>
          )}
        </div>
      )}
      {porGenerar.map((p) => (
        <div key={p.proveedor_id} className="mod-mb-4">
          <div className="mod-flex mod-gap-3 mod-center mod-mb-1">
            <strong className="mod-md">{p.proveedor} ({p.documento})</strong>
            <span className="mod-text">{p.items} ítem(s) · Total con IVA {pesos(p.total_con_iva)}</span>
            <button
              type="button"
              className="ui-btn ui-btn--sm mod-semibold"
              disabled={generando === p.proveedor_id || !permisos.ganadorCrear}
              title={!permisos.ganadorCrear ? 'No tienes permiso para generar órdenes de compra' : undefined}
              onClick={() => generar(p)}
            >
              Generar orden de compra
            </button>
          </div>
          <div className="mod-scroll">
            <table className="mod-table">
              <thead>
                <tr>
                  {['Item', 'Nombre Base', 'Línea', 'Referencia', 'Cantidad', 'Cajas', 'Costo unit.', 'Costo con IVA', 'Flete'].map((h) => (
                    <th key={h}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {p.lineas.map((l) => (
                  <tr key={l.cotizacion_id}>
                    <td>{l.codigo ?? l.item_id}</td>
                    <td>{l.nombre_base}</td>
                    <td>{l.linea ?? ''}</td>
                    <td>{l.referencia ?? ''}</td>
                    <td>{l.cantidad}</td>
                    <td>{textoCajas(l.cantidad, l.unidades_por_caja)}</td>
                    <td>{pesos(l.costo_unitario)}</td>
                    <td>{pesos(l.costo_con_iva)}</td>
                    <td>{pesos(l.flete)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      <h3 className="mod-h3 mod-mt-5 mod-mb-2">Historial de órdenes</h3>
      <div className="mod-scroll">
        <table className="mod-table">
          <thead>
            <tr>
              {['N°', 'Proveedor', 'Sede', 'Fecha', 'Total con IVA', 'Creó', 'Ítems', 'Acción'].map((h) => (
                <th key={h}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ordenes.map((o) => (
              <tr key={o.id}>
                <td>{o.numero_texto}</td>
                <td>{o.proveedor}</td>
                <td>{o.sede ?? ''}</td>
                <td>{fecha(o.fecha)}</td>
                <td>{pesos(o.total_oc)}</td>
                <td>{o.creado_por ?? ''}</td>
                <td>
                  <details>
                    <summary className="mod-pointer">{o.items.length} ítem(s)</summary>
                    {o.items.map((l) => (
                      <div key={l.item_id} className="mod-sub">
                        {l.codigo ?? l.item_id} · {l.nombre_base} · {l.cantidad}
                        {l.unidades_por_caja ? ` (${textoCajas(l.cantidad, l.unidades_por_caja)})` : ''} · {pesos(l.costo_unitario)}
                      </div>
                    ))}
                  </details>
                </td>
                <td>
                  <button type="button" className="ui-btn ui-btn--sm ui-btn--soft" onClick={() => verTexto(o.id, o.numero_texto, o.proveedor)}>
                    Ver / copiar
                  </button>
                </td>
              </tr>
            ))}
            {ordenes.length === 0 && (
              <tr><td colSpan={8}>Aún no hay órdenes de compra</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
