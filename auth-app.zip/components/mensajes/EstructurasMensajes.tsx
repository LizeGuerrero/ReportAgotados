'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/client';

type Tipo = 'solicitud_cotizacion' | 'orden_compra';

const TIPOS: { valor: Tipo; texto: string; ayuda: string }[] = [
  {
    valor: 'solicitud_cotizacion',
    texto: 'Solicitud de cotización',
    ayuda: 'Lo que se envía al proveedor para pedirle precio y disponibilidad.',
  },
  {
    valor: 'orden_compra',
    texto: 'Orden de compra',
    ayuda: 'Lo que se envía al proveedor para confirmarle lo que se le compra.',
  },
];

const AMBITOS: { valor: string; texto: string; ayuda: string }[] = [
  { valor: 'encabezado', texto: 'Encabezado del mensaje', ayuda: 'Datos generales, una línea por campo, debajo del título.' },
  { valor: 'linea', texto: 'Datos de cada producto', ayuda: 'Se arma una línea por producto con los campos que dejes visibles, en este orden.' },
  { valor: 'pie', texto: 'Pie del mensaje', ayuda: 'Totales al final del mensaje.' },
];

interface Campo {
  clave: string;
  ambito: string;
  etiqueta: string;
  etiqueta_defecto: string;
  orden: number;
  visible: boolean;
  destino: 'proveedor' | 'interno';
  permite_proveedor: boolean;
}

interface Config {
  encabezado: string;
  introduccion: string;
  pie: string;
  campos: Campo[];
  personalizada: boolean;
}

const DESTINOS = [
  { valor: 'proveedor', texto: 'Proveedor y copia interna' },
  { valor: 'interno', texto: 'Solo copia interna' },
];

/**
 * Estructuras de los mensajes que Pedidos genera. Por cada tipo de mensaje la organización decide qué
 * campos aparecen, en qué orden, con qué título y, sobre todo, cuáles ve el proveedor y cuáles son solo
 * para uso interno. No es un ocultamiento visual: el texto que sale de Pedidos se arma en la base de
 * datos con esta configuración, y los datos que son estrictamente internos no se pueden enviar al proveedor.
 */
export default function EstructurasMensajes({
  organizacionId,
  puedeEditar,
}: {
  organizacionId: string;
  puedeEditar: boolean;
}) {
  const [supabase] = useState(() => createClient());
  const [tipo, setTipo] = useState<Tipo>('solicitud_cotizacion');
  const [cargada, setCargada] = useState<Config | null>(null);
  const [borrador, setBorrador] = useState<Config | null>(null);
  const [error, setError] = useState('');
  const [aviso, setAviso] = useState('');
  const [guardando, setGuardando] = useState(false);
  const [previa, setPrevia] = useState({ proveedor: '', interno: '' });

  const cargar = useCallback(async () => {
    setError('');
    const { data, error } = await supabase.rpc('mensaje_config_obtener', { p_org: organizacionId, p_tipo: tipo });
    if (error) {
      setError(error.message);
      return;
    }
    const cfg = data as Config;
    setCargada(cfg);
    setBorrador(cfg);
  }, [supabase, organizacionId, tipo]);

  useEffect(() => {
    setCargada(null);
    setBorrador(null);
    setAviso('');
    cargar();
  }, [cargar]);

  const payload = useMemo(
    () =>
      borrador && {
        encabezado: borrador.encabezado,
        introduccion: borrador.introduccion,
        pie: borrador.pie,
        campos: borrador.campos.map((c) => ({
          clave: c.clave, etiqueta: c.etiqueta, orden: c.orden, visible: c.visible, destino: c.destino,
        })),
      },
    [borrador],
  );
  const sucio = useMemo(() => {
    if (!borrador || !cargada) return false;
    const a = JSON.stringify({ e: borrador.encabezado, i: borrador.introduccion, p: borrador.pie, c: borrador.campos });
    const b = JSON.stringify({ e: cargada.encabezado, i: cargada.introduccion, p: cargada.pie, c: cargada.campos });
    return a !== b;
  }, [borrador, cargada]);

  // La vista previa se arma en el servidor con el borrador (sin guardarlo)
  useEffect(() => {
    if (!payload) return;
    let vigente = true;
    const t = setTimeout(async () => {
      const [a, b] = await Promise.all([
        supabase.rpc('mensaje_vista_previa', { p_org: organizacionId, p_tipo: tipo, p_datos: payload, p_interno: false }),
        supabase.rpc('mensaje_vista_previa', { p_org: organizacionId, p_tipo: tipo, p_datos: payload, p_interno: true }),
      ]);
      if (!vigente) return;
      setPrevia({
        proveedor: a.error ? `Error: ${a.error.message}` : (a.data as string),
        interno: b.error ? `Error: ${b.error.message}` : (b.data as string),
      });
    }, 350);
    return () => {
      vigente = false;
      clearTimeout(t);
    };
  }, [supabase, organizacionId, tipo, payload]);

  function cambiarCampo(clave: string, cambio: Partial<Campo>) {
    setBorrador((b) => b && { ...b, campos: b.campos.map((c) => (c.clave === clave ? { ...c, ...cambio } : c)) });
  }

  function mover(clave: string, delta: -1 | 1) {
    setBorrador((b) => {
      if (!b) return b;
      const campo = b.campos.find((c) => c.clave === clave);
      if (!campo) return b;
      const grupo = b.campos.filter((c) => c.ambito === campo.ambito).sort((x, y) => x.orden - y.orden);
      const i = grupo.findIndex((c) => c.clave === clave);
      const j = i + delta;
      if (j < 0 || j >= grupo.length) return b;
      [grupo[i], grupo[j]] = [grupo[j], grupo[i]];
      const nuevoOrden = new Map(grupo.map((c, k) => [c.clave, k + 1]));
      return { ...b, campos: b.campos.map((c) => (nuevoOrden.has(c.clave) ? { ...c, orden: nuevoOrden.get(c.clave) as number } : c)) };
    });
  }

  async function guardar() {
    if (!payload) return;
    setGuardando(true);
    setError('');
    setAviso('');
    const { error } = await supabase.rpc('mensaje_config_guardar', { p_org: organizacionId, p_tipo: tipo, p_datos: payload });
    setGuardando(false);
    if (error) {
      setError(error.message);
      return;
    }
    setAviso('Estructura guardada. Los próximos mensajes de Pedidos usarán esta configuración.');
    await cargar();
  }

  async function restablecer() {
    if (!window.confirm('¿Volver a la estructura de fábrica de este mensaje? Se pierde la personalización.')) return;
    setGuardando(true);
    setError('');
    const { error } = await supabase.rpc('mensaje_config_restablecer', { p_org: organizacionId, p_tipo: tipo });
    setGuardando(false);
    if (error) {
      setError(error.message);
      return;
    }
    setAviso('Se restableció la estructura de fábrica.');
    await cargar();
  }

  const infoTipo = TIPOS.find((t) => t.valor === tipo)!;

  return (
    <div>
      <div className="mod-tabs">
        {TIPOS.map((t) => (
          <button
            key={t.valor}
            type="button"
            onClick={() => {
              if (sucio && !window.confirm('Tienes cambios sin guardar. ¿Descartarlos?')) return;
              setTipo(t.valor);
            }}
            aria-current={tipo === t.valor}
            className={tipo === t.valor ? 'mod-tab is-active' : 'mod-tab'}
          >
            {t.texto}
          </button>
        ))}
      </div>

      <p className="mod-text mod-mt-0 mod-mb-2">
        {infoTipo.ayuda} Elige qué campos aparecen, en qué orden y con qué título. “Solo copia interna” deja el dato en la
        copia de Compras pero <strong>nunca</strong> sale en el mensaje al proveedor; los datos marcados como internos
        (línea, sedes, quién creó…) no se pueden enviar al proveedor.
      </p>

      {error && <p className="mod-text">Error: {error}</p>}
      {aviso && <p className="mod-notice mod-text">{aviso}</p>}
      {!puedeEditar && <p className="mod-sub">Solo puedes ver esta configuración: no tienes permiso para editarla.</p>}

      {!borrador && !error && <p className="mod-text">Cargando…</p>}

      {borrador && (
        <>
          <div className="mod-card mod-mb-3">
            <div className="mod-semibold mod-mb-2">Textos del mensaje</div>
            <p className="mod-sub mod-mt-0 mod-mb-2">
              Puedes usar {'{numero}'}, {'{proveedor}'}, {'{fecha}'} y {'{entregar_en}'}: se reemplazan por los datos reales.
            </p>
            <label className="mod-label">Título (primera línea)</label>
            <input
              className="ui-input ui-input--sm" style={{ width: '100%', maxWidth: 520 }}
              value={borrador.encabezado}
              disabled={!puedeEditar}
              maxLength={600}
              onChange={(e) => setBorrador({ ...borrador, encabezado: e.target.value })}
            />
            <label className="mod-label mod-mt-2">Texto antes de los productos (opcional)</label>
            <textarea
              className="ui-input" rows={2} style={{ width: '100%', maxWidth: 520 }}
              value={borrador.introduccion}
              disabled={!puedeEditar}
              maxLength={600}
              onChange={(e) => setBorrador({ ...borrador, introduccion: e.target.value })}
            />
            <label className="mod-label mod-mt-2">Texto final (opcional, p. ej. condiciones de pago o despedida)</label>
            <textarea
              className="ui-input" rows={2} style={{ width: '100%', maxWidth: 520 }}
              value={borrador.pie}
              disabled={!puedeEditar}
              maxLength={600}
              onChange={(e) => setBorrador({ ...borrador, pie: e.target.value })}
            />
          </div>

          {AMBITOS.map((a) => {
            const grupo = borrador.campos.filter((c) => c.ambito === a.valor).sort((x, y) => x.orden - y.orden);
            if (grupo.length === 0) return null;
            return (
              <div key={a.valor} className="mod-mb-3">
                <h3 className="mod-h3 mod-mt-0 mod-mb-1">{a.texto}</h3>
                <p className="mod-sub mod-mt-0 mod-mb-1">{a.ayuda}</p>
                <div className="mod-scroll">
                  <table className="mod-table">
                    <thead>
                      <tr>
                        {['Orden', 'Mostrar', 'Título del campo', 'Quién lo ve'].map((h) => <th key={h}>{h}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {grupo.map((c, k) => (
                        <tr key={c.clave} className={c.visible ? undefined : 'is-faded'}>
                          <td>
                            <div className="mod-flex mod-gap-1">
                              <button type="button" className="ui-btn ui-btn--sm" disabled={!puedeEditar || k === 0}
                                onClick={() => mover(c.clave, -1)} aria-label={`Subir ${c.etiqueta_defecto}`}>↑</button>
                              <button type="button" className="ui-btn ui-btn--sm" disabled={!puedeEditar || k === grupo.length - 1}
                                onClick={() => mover(c.clave, 1)} aria-label={`Bajar ${c.etiqueta_defecto}`}>↓</button>
                            </div>
                          </td>
                          <td>
                            <input
                              type="checkbox"
                              checked={c.visible}
                              disabled={!puedeEditar}
                              onChange={(e) => cambiarCampo(c.clave, { visible: e.target.checked })}
                              aria-label={`Mostrar ${c.etiqueta_defecto}`}
                            />
                          </td>
                          <td>
                            <input
                              className="ui-input ui-input--sm" style={{ width: 220 }}
                              value={c.etiqueta}
                              disabled={!puedeEditar}
                              maxLength={60}
                              placeholder={c.etiqueta_defecto}
                              onChange={(e) => cambiarCampo(c.clave, { etiqueta: e.target.value })}
                              aria-label={`Título de ${c.etiqueta_defecto}`}
                            />
                            <div className="mod-sub">
                              {c.etiqueta === '' ? 'Sin título: se imprime solo el valor. ' : ''}
                              Dato: {c.etiqueta_defecto}
                            </div>
                          </td>
                          <td>
                            <select
                              className="ui-input ui-input--sm mod-auto"
                              value={c.destino}
                              disabled={!puedeEditar || !c.permite_proveedor}
                              onChange={(e) => cambiarCampo(c.clave, { destino: e.target.value as Campo['destino'] })}
                              aria-label={`Quién ve ${c.etiqueta_defecto}`}
                            >
                              {DESTINOS.map((d) => <option key={d.valor} value={d.valor}>{d.texto}</option>)}
                            </select>
                            {!c.permite_proveedor && <div className="mod-sub">Dato interno: nunca se envía al proveedor</div>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}

          {puedeEditar && (
            <div className="mod-flex mod-gap-2 mod-mb-3 mod-center mod-wrap">
              <button type="button" className="ui-btn ui-btn--sm ui-btn--primary" disabled={!sucio || guardando} onClick={guardar}>
                {guardando ? 'Guardando…' : 'Guardar estructura'}
              </button>
              {sucio && (
                <button type="button" className="ui-btn ui-btn--sm" disabled={guardando} onClick={() => setBorrador(cargada)}>
                  Descartar cambios
                </button>
              )}
              {borrador.personalizada && (
                <button type="button" className="ui-btn ui-btn--sm ui-btn--ghost" disabled={guardando} onClick={restablecer}>
                  Restablecer estructura de fábrica
                </button>
              )}
              {sucio && <span className="mod-sub">Hay cambios sin guardar; la vista previa ya los refleja.</span>}
            </div>
          )}

          <h3 className="mod-h3 mod-mt-4 mod-mb-1">Vista previa (con datos de ejemplo)</h3>
          <div className="mod-flex mod-gap-3 mod-wrap mod-start">
            <div style={{ flex: '1 1 340px' }}>
              <div className="mod-semibold mod-mb-1">Lo que recibe el proveedor</div>
              <textarea readOnly className="ui-input mod-mono" rows={Math.min(24, previa.proveedor.split('\n').length + 1)} value={previa.proveedor} />
            </div>
            <div style={{ flex: '1 1 340px' }}>
              <div className="mod-semibold mod-mb-1">Copia interna (solo Compras)</div>
              <textarea readOnly className="ui-input mod-mono" rows={Math.min(24, previa.interno.split('\n').length + 1)} value={previa.interno} />
            </div>
          </div>
        </>
      )}
    </div>
  );
}
