'use client';

import { useCallback, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import Bandeja from '@/components/pedidos/Bandeja';
import Cotizar from '@/components/pedidos/Cotizar';
import Comparativo from '@/components/pedidos/Comparativo';
import OrdenesCompra from '@/components/pedidos/OrdenesCompra';
import Enviadas from '@/components/pedidos/Enviadas';
import ItemsProvisionales from '@/components/pedidos/ItemsProvisionales';
import { usePermisosPedidos } from '@/components/pedidos/usePermisosPedidos';

type Pestana = 'solicitudes' | 'cotizar' | 'comparativo' | 'ordenes' | 'enviadas' | 'provisionales';

/**
 * El módulo Pedidos es un flujo de cuatro pasos; las pestañas lo cuentan en orden:
 *   1. Solicitudes  — lo que Comercial notificó (agotados) y lo que Compras inició; se marca y se actúa en bloque.
 *   2. Cotizar      — a qué proveedores se les pide cotización (por ítem o por proveedor).
 *   3. Comparativo  — se registran los costos, se comparan y se elige el ganador (también en bloque).
 *   4. Órdenes      — se generan las órdenes de compra, una por proveedor, y sus mensajes.
 * Aparte: "Enviadas" (solicitudes de cotización ya creadas) e "Ítems provisionales".
 */
const PESTANAS: { valor: Pestana; texto: string }[] = [
  { valor: 'solicitudes', texto: '1. Solicitudes' },
  { valor: 'cotizar', texto: '2. Cotizar' },
  { valor: 'comparativo', texto: '3. Comparativo' },
  { valor: 'ordenes', texto: '4. Órdenes de compra' },
  { valor: 'enviadas', texto: 'Enviadas' },
  { valor: 'provisionales', texto: 'Ítems provisionales' },
];

export default function PedidosCompras({ organizacionId }: { organizacionId: string }) {
  const [supabase] = useState(() => createClient());
  const permisos = usePermisosPedidos(supabase, organizacionId);
  const [pestana, setPestana] = useState<Pestana>('solicitudes');
  // Ítems marcados en Solicitudes que viajan al paso Cotizar (cada envío es un arreglo nuevo)
  const [preseleccion, setPreseleccion] = useState<number[]>([]);

  const cotizarSeleccion = useCallback((ids: number[]) => {
    setPreseleccion(ids);
    setPestana('cotizar');
  }, []);

  return (
    <div>
      <div className="mod-tabs">
        {PESTANAS.map((p) => (
          <button
            key={p.valor}
            type="button"
            onClick={() => setPestana(p.valor)}
            aria-current={pestana === p.valor}
            className={pestana === p.valor ? 'mod-tab is-active' : 'mod-tab'}
          >
            {p.texto}
          </button>
        ))}
      </div>

      {pestana === 'solicitudes' && (
        <Bandeja supabase={supabase} organizacionId={organizacionId} permisos={permisos} onCotizar={cotizarSeleccion} />
      )}
      {pestana === 'cotizar' && (
        <Cotizar
          supabase={supabase}
          organizacionId={organizacionId}
          permisos={permisos}
          preseleccion={preseleccion}
          onIrAComparativo={() => setPestana('comparativo')}
        />
      )}
      {pestana === 'comparativo' && (
        <Comparativo
          supabase={supabase}
          organizacionId={organizacionId}
          permisos={permisos}
          onIrAOrdenes={() => setPestana('ordenes')}
        />
      )}
      {pestana === 'ordenes' && (
        <OrdenesCompra supabase={supabase} organizacionId={organizacionId} permisos={permisos} />
      )}
      {pestana === 'enviadas' && (
        <Enviadas
          supabase={supabase}
          organizacionId={organizacionId}
          puedeCrear={permisos.crear}
          onNueva={() => setPestana('cotizar')}
        />
      )}
      {pestana === 'provisionales' && <ItemsProvisionales supabase={supabase} organizacionId={organizacionId} />}
    </div>
  );
}
